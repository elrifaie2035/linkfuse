package proto

import (
	"sync"
	"time"
)

// PathStats يحمل القياسات الحيّة لمسار (كرت) واحد ويشتقّ منها وزناً للموزّع.
// آمن للتوازي.
type PathStats struct {
	mu sync.Mutex

	BaseKbps int // سعة الكرت الاسمية (مثلاً 2000 لكرت 2Mbps) — مدخل من الإعداد

	srtt        time.Duration // RTT مُنعَّم (EWMA)
	reliability float64       // نسبة وصول النبضات (EWMA)، 1 = ممتاز

	// Congestion: minRTT is the path's own idle RTT (follows new lows at once,
	// creeps up very slowly). When srtt rises well above it, the path's queue
	// is filling (it gets more than it can carry), so its share is reduced.
	minRTT     time.Duration
	congestion float64 // 1 = no queue; smaller = path is overloaded
	owdMode    bool    // congestion comes from one-way delay (peer supports it)

	LastSeen time.Time // آخر datagram وصل من هذا المسار

	// عدّادات تراكمية للعرض والمحاسبة
	TxPkts, TxBytes uint64
	RxPkts, RxBytes uint64
	KaSent, KaAcked uint64
}

// NewPathStats يبدأ المسار بافتراض ممتاز حتى تُثبت القياسات العكس.
func NewPathStats(baseKbps int) *PathStats {
	return &PathStats{BaseKbps: baseKbps, reliability: 1.0, srtt: 50 * time.Millisecond, congestion: 1}
}

// OnRTT يُحدّث SRTT بعيّنة جديدة (من KeepaliveAck) بخوارزمية EWMA (α=1/8).
func (p *PathStats) OnRTT(sample time.Duration) {
	p.mu.Lock()
	if p.srtt == 0 {
		p.srtt = sample
	} else {
		p.srtt += (sample - p.srtt) / 8
	}
	p.reliability += (1.0 - p.reliability) / 8 // نبضة وصلت → موثوقية أعلى
	if p.reliability > 1 {
		p.reliability = 1
	}
	if p.owdMode {
		p.mu.Unlock()
		return // per-direction delay drives congestion; RTT mixes both directions
	}
	if p.minRTT == 0 || sample < p.minRTT {
		p.minRTT = sample
	} else {
		p.minRTT += (sample - p.minRTT) / 2000 // ~30 min to follow a real route change
	}
	target := float64(p.minRTT+QueueAllowance) / float64(p.srtt)
	if target > 1 {
		target = 1
	}
	if target < minCongestion {
		target = minCongestion
	}
	p.congestion += (target - p.congestion) / 4
	p.mu.Unlock()
}

// QueueAllowance is how much queueing delay a path may build before its share
// is reduced. minCongestion keeps a slow path in use instead of starving it.
const (
	QueueAllowance = 15 * time.Millisecond
	minCongestion  = 0.2
)

// Congestion returns 1 when the path carries its share without a queue, less
// when its delay grows above its own idle RTT.
func (p *PathStats) Congestion() float64 {
	p.mu.Lock()
	defer p.mu.Unlock()
	return p.congestion
}

// EffectiveKbps is what the path is really carrying well right now: nominal
// capacity x reliability x congestion. Shapers size the total from this, so
// the limit follows the real capacity when a line is weaker than written.
func (p *PathStats) EffectiveKbps() float64 {
	p.mu.Lock()
	defer p.mu.Unlock()
	rel := p.reliability
	if rel > 1 {
		rel = 1
	}
	return float64(p.BaseKbps) * rel * p.congestion
}

// OnKeepaliveLost يُسجّل نبضة لم يصل ردّها ضمن المهلة (يخفض الموثوقية).
func (p *PathStats) OnKeepaliveLost() {
	p.mu.Lock()
	p.reliability += (0.0 - p.reliability) / 8
	p.mu.Unlock()
}

// Touch يسجّل أن بايتات وصلت على هذا المسار الآن (علامة حياة).
func (p *PathStats) Touch(now time.Time, nbytes int) {
	p.mu.Lock()
	p.LastSeen = now
	p.RxPkts++
	p.RxBytes += uint64(nbytes)
	p.mu.Unlock()
}

// AddTx يسجّل بايتات صادرة.
func (p *PathStats) AddTx(nbytes int) {
	p.mu.Lock()
	p.TxPkts++
	p.TxBytes += uint64(nbytes)
	p.mu.Unlock()
}

// SetBaseKbps updates the nominal capacity (the server learns it from the
// client's keepalives, so a 8 Mbps line and a 2 Mbps card get fair shares).
func (p *PathStats) SetBaseKbps(kbps int) {
	p.mu.Lock()
	p.BaseKbps = kbps
	p.mu.Unlock()
}

// Base reads the nominal capacity safely.
func (p *PathStats) Base() int {
	p.mu.Lock()
	defer p.mu.Unlock()
	return p.BaseKbps
}

// SRTT, Reliability قراءات آمنة.
func (p *PathStats) SRTT() time.Duration {
	p.mu.Lock()
	defer p.mu.Unlock()
	return p.srtt
}
func (p *PathStats) Reliability() float64 {
	p.mu.Lock()
	defer p.mu.Unlock()
	return p.reliability
}

// Weight is the path's share for the scheduler: nominal capacity, punished
// by loss (squared, so a lossy path drops out fast) and by its own queueing
// delay (congestion). A path with a lower base RTT is NOT favoured: shares
// must follow capacity, otherwise faster paths get overloaded and their
// packets arrive too late for the reorder buffer. Minimum 1 for a live path.
func (p *PathStats) Weight() int {
	p.mu.Lock()
	defer p.mu.Unlock()
	rel := p.reliability
	w := float64(p.BaseKbps) * rel * rel * p.congestion
	if w < 1 {
		w = 1
	}
	return int(w)
}

// IsStale: هل انقطع المسار (لا datagram منذ مدة)؟
func (p *PathStats) IsStale(now time.Time, timeout time.Duration) bool {
	p.mu.Lock()
	defer p.mu.Unlock()
	if p.LastSeen.IsZero() {
		return false // لم يبدأ بعد
	}
	return now.Sub(p.LastSeen) > timeout
}
