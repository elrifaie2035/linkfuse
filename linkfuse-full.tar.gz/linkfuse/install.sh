#!/usr/bin/env bash
# سكربت تثبيت LinkFuse التلقائي — يبني البرامج ويجهّز كل شيء على العقدة.
# التشغيل:  sudo bash install.sh
# يفترض وجود Go في /usr/local/go/bin أو في PATH، وNode 18+.
set -e

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
say() { echo -e "${GREEN}[+]${NC} $1"; }
warn() { echo -e "${YELLOW}[!]${NC} $1"; }
die() { echo -e "${RED}[x]${NC} $1"; exit 1; }

HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"

# --- التحقق من الأدوات ---
export PATH=$PATH:/usr/local/go/bin
command -v go >/dev/null || die "Go غير موجود. ثبّته أولاً."
command -v node >/dev/null || die "Node غير موجود. ثبّته أولاً."
say "Go: $(go version | awk '{print $3}') | Node: $(node --version)"

# --- بناء برامج Go (ثابتة، بلا اعتماديات) ---
say "بناء lf-node..."
cd "$HERE/node"
CGO_ENABLED=0 go build -ldflags='-s -w' -o /usr/local/bin/lf-node ./cmd/lf-node
say "بناء lf-server (للنقل إلى الـ VPS)..."
cd "$HERE/tunnel"
CGO_ENABLED=0 go build -ldflags='-s -w' -o "$HERE/lf-server" ./cmd/lf-server
say "تمّ بناء برامج Go ✔"

# --- بناء اللوحة ---
say "تثبيت اعتماديات اللوحة وبناؤها (قد يأخذ دقائق)..."
cd "$HERE/panel"
npm ci 2>/dev/null || npm install
npm run build
say "تمّ بناء اللوحة ✔"

# --- تجهيز الإعدادات ---
mkdir -p /etc/linkfuse /opt/linkfuse-panel
cp -r "$HERE/panel/.next" "$HERE/panel/package.json" "$HERE/panel/public" /opt/linkfuse-panel/ 2>/dev/null || true
cp -r "$HERE/panel/node_modules" /opt/linkfuse-panel/ 2>/dev/null || true

[ -f /etc/linkfuse/node.json ] || cp "$HERE/deploy/node.json" /etc/linkfuse/node.json
[ -f /etc/linkfuse/panel.env ] || cp "$HERE/deploy/panel.env" /etc/linkfuse/panel.env

# --- وحدات systemd ---
cp "$HERE/deploy/lf-node.service" /etc/systemd/system/
cp "$HERE/deploy/lf-panel.service" /etc/systemd/system/
systemctl daemon-reload

say "اكتمل التثبيت ✔"
echo
warn "الخطوات المتبقية يدوياً:"
echo "  1) عدّل الإعداد:        sudo nano /etc/linkfuse/node.json"
echo "       - server: عنوان الـ VPS"
echo "       - parent_iface: ens19   (خط المزوّد)"
echo "       - login.login_url: صفحة دخول مزوّدك"
echo "       - cards: يوزر/باسورد كل كرت"
echo "  2) فعّل كرتَي المزوّد والداخلية (ens19, ens20) في netplan."
echo "  3) انقل lf-server إلى الـ VPS وشغّله هناك."
echo "  4) شغّل:               sudo systemctl enable --now lf-node lf-panel"
echo "  5) افتح اللوحة:         http://10.10.10.100:3000"
