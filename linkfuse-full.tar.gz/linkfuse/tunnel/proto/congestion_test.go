package proto

import (
	"testing"
	"time"
)

func feed(p *PathStats, rtt time.Duration, n int) {
	for i := 0; i < n; i++ {
		p.OnRTT(rtt)
	}
}

// Shares follow capacity, not base RTT: a 8 Mbps line with a shorter RTT than
// a 2 Mbps card gets exactly 4x, not more.
func TestWeightFollowsCapacityNotRTT(t *testing.T) {
	line, card := NewPathStats(8000), NewPathStats(2000)
	feed(line, 25*time.Millisecond, 60)
	feed(card, 60*time.Millisecond, 60)
	r := float64(line.Weight()) / float64(card.Weight())
	if r < 3.9 || r > 4.1 {
		t.Fatalf("share ratio %.2f, want 4", r)
	}
}

// A path whose delay grows above its own idle RTT (its queue fills) loses
// share and effective capacity; it recovers when the queue drains.
func TestCongestionReducesShareAndRecovers(t *testing.T) {
	p := NewPathStats(8000)
	feed(p, 30*time.Millisecond, 60)
	idle := p.EffectiveKbps()
	feed(p, 150*time.Millisecond, 40) // queue building up
	loaded := p.EffectiveKbps()
	if loaded > idle*0.5 {
		t.Fatalf("congested path keeps too much: idle %.0f loaded %.0f", idle, loaded)
	}
	feed(p, 32*time.Millisecond, 80) // queue drained
	if rec := p.EffectiveKbps(); rec < idle*0.95 {
		t.Fatalf("did not recover: %.0f vs %.0f", rec, idle)
	}
	// small jitter inside the allowance changes nothing
	q := NewPathStats(2000)
	feed(q, 60*time.Millisecond, 30)
	feed(q, 70*time.Millisecond, 30)
	if q.Congestion() < 0.99 {
		t.Fatalf("jitter within allowance reduced share: %.2f", q.Congestion())
	}
}
