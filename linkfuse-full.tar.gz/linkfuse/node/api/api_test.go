package api

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/linkfuse/node/manager"
)

func testServer(token string) *httptest.Server {
	cfg := &manager.NodeConfig{
		Server: "1.2.3.4:51820", PSK: "x", Login: manager.LoginCfg{LoginURL: "http://10.3.0.1/login"},
		Cards: []manager.CardCfg{{ID: 1, Username: "u1", BaseKbps: 2000}},
	}
	mgr := manager.New(cfg, "/tmp/nonexistent.json")
	return httptest.NewServer(New(mgr, token).Handler())
}

func TestAuthRequired(t *testing.T) {
	ts := testServer("secret")
	defer ts.Close()
	resp, _ := http.Get(ts.URL + "/api/stats")
	if resp.StatusCode != 401 {
		t.Fatalf("بلا رمز توقّعنا 401، حصلنا %d", resp.StatusCode)
	}
}

func TestStatsWithToken(t *testing.T) {
	ts := testServer("secret")
	defer ts.Close()
	req, _ := http.NewRequest("GET", ts.URL+"/api/stats", nil)
	req.Header.Set("Authorization", "Bearer secret")
	resp, err := http.DefaultClient.Do(req)
	if err != nil || resp.StatusCode != 200 {
		t.Fatalf("مع الرمز توقّعنا 200: %v %d", err, resp.StatusCode)
	}
	var snap manager.Snapshot
	if err := json.NewDecoder(resp.Body).Decode(&snap); err != nil {
		t.Fatalf("فكّ JSON: %v", err)
	}
}

func TestCardsList(t *testing.T) {
	ts := testServer("")
	defer ts.Close()
	resp, _ := http.Get(ts.URL + "/api/cards")
	if resp.StatusCode != 200 {
		t.Fatalf("توقّعنا 200، حصلنا %d", resp.StatusCode)
	}
	var cards []manager.CardCfg
	if err := json.NewDecoder(resp.Body).Decode(&cards); err != nil {
		t.Fatalf("فكّ JSON: %v", err)
	}
	if len(cards) != 1 || cards[0].Username != "u1" {
		t.Fatalf("قائمة الكروت خاطئة: %+v", cards)
	}
}
