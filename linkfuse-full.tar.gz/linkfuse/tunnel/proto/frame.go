// Package proto defines the LinkFuse bonding-tunnel wire format.
//
// كل datagram على السلك = nonce ثم صندوق AES-256-GCM مُغلق يحتوي الترويسة + الحمولة.
// الترويسة مشفّرة أيضاً، فلا يرى المزوّد ولا أي وسيط إلا nonce عشوائي + نص مُعمّى.
// إعادة الترتيب والقياس تتمّان بعد فكّ التشفير اعتماداً على الحقول في الترويسة.
package proto

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/sha256"
	"encoding/binary"
	"errors"
	"io"
)

const (
	// Version هو إصدار البروتوكول؛ يُرفض أي frame بإصدار مختلف.
	Version = 1

	// HeaderSize = version(1)+type(1)+pathID(2)+flags(1)+seq(8)+ts(8).
	HeaderSize = 21

	nonceSize = 12 // AES-GCM standard nonce
	tagSize   = 16 // AES-GCM tag

	// Overhead هو ما يضيفه النفق فوق كل حزمة IP داخلية.
	Overhead = nonceSize + HeaderSize + tagSize // = 49 بايت

	// MaxPayload هو أكبر حمولة IP داخلية ندعمها (يحدّد MTU الداخلي).
	MaxPayload = 1400
)

// TUN واجهة جهاز الطبقة 3. تُحقّقها tundev.Device في الإنتاج، وبديلٌ في الذاكرة
// أثناء الاختبار، فيصبح النفق كله قابلاً للاختبار من طرف لطرف دون صلاحيات أو أجهزة.
type TUN interface {
	Read(p []byte) (int, error)
	Write(p []byte) (int, error)
	Close() error
}

// FrameType يميّز نوع المحتوى.
type FrameType uint8

const (
	TypeData         FrameType = 1 // حزمة IP من/إلى جهاز TUN
	TypeKeepalive    FrameType = 2 // نبضة قياس على مسار واحد
	TypeKeepaliveAck FrameType = 3 // ردّ النبضة (يحمل الطابع الزمني الأصلي)
	TypeHello        FrameType = 4 // مصافحة أولى تُعرّف العميل والمسار للخادم
	TypeBye          FrameType = 5 // إشعار بإزالة المسار فوراً (توقّف عن استخدامه)
)

// Flags بتات إضافية (محجوزة للتوسّع: FEC، أولوية، نهاية تدفّق…).
const (
	FlagNone uint8 = 0
)

// Header الترويسة الثابتة داخل الصندوق المشفّر.
type Header struct {
	Version uint8
	Type    FrameType
	PathID  uint16 // أي كرت/مسار خرجت منه (باتجاه الخادم) أو عاد عبره
	Flags   uint8
	Seq     uint64 // تسلسل عام لكل اتجاه، لإعادة الترتيب على الطرف الآخر
	TS      int64  // unix-nano وقت الإرسال؛ يُستخدم لقياس RTT عبر KeepaliveAck
}

var (
	ErrShort      = errors.New("proto: datagram أقصر من الحد الأدنى")
	ErrVersion    = errors.New("proto: إصدار بروتوكول غير مدعوم")
	ErrOversize   = errors.New("proto: الحمولة أكبر من MaxPayload")
	ErrAuthFailed = errors.New("proto: فشل التحقق/فكّ التشفير")
)

// Codec يغلّف ويفكّ الحزم بمفتاح مشترك واحد (PSK).
// آمن للاستخدام من عدّة goroutines (GCM من stdlib للقراءة آمن للتوازي).
type Codec struct {
	aead cipher.AEAD
}

// NewCodec يشتقّ مفتاح AES-256 من كلمة السر المشتركة عبر SHA-256.
// الطرفان (العميل والخادم) يجب أن يستخدما نفس الـ psk بالضبط.
func NewCodec(psk string) (*Codec, error) {
	if len(psk) < 16 {
		return nil, errors.New("proto: PSK يجب ألّا تقلّ عن 16 محرفاً")
	}
	sum := sha256.Sum256([]byte(psk)) // 32 بايت = AES-256
	block, err := aes.NewCipher(sum[:])
	if err != nil {
		return nil, err
	}
	aead, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	return &Codec{aead: aead}, nil
}

func putHeader(dst []byte, h Header) {
	_ = dst[HeaderSize-1] // bounds hint
	dst[0] = h.Version
	dst[1] = byte(h.Type)
	binary.BigEndian.PutUint16(dst[2:4], h.PathID)
	dst[4] = h.Flags
	binary.BigEndian.PutUint64(dst[5:13], h.Seq)
	binary.BigEndian.PutUint64(dst[13:21], uint64(h.TS))
}

func getHeader(src []byte) Header {
	return Header{
		Version: src[0],
		Type:    FrameType(src[1]),
		PathID:  binary.BigEndian.Uint16(src[2:4]),
		Flags:   src[4],
		Seq:     binary.BigEndian.Uint64(src[5:13]),
		TS:      int64(binary.BigEndian.Uint64(src[13:21])),
	}
}

// Seal يبني datagram جاهزاً للإرسال داخل dst (يُعاد تخصيصه إن لزم) ويُعيد الشريحة.
// الشكل الناتج: [nonce(12)][ciphertext( header(21) + payload )][tag(16)].
func (c *Codec) Seal(dst []byte, h Header, payload []byte) ([]byte, error) {
	if len(payload) > MaxPayload {
		return nil, ErrOversize
	}
	h.Version = Version
	plainLen := HeaderSize + len(payload)
	need := nonceSize + plainLen + tagSize
	if cap(dst) < need {
		dst = make([]byte, need)
	}
	dst = dst[:nonceSize]

	// nonce عشوائي لكل حزمة (آمن تماماً مع GCM ما دام عشوائياً فريداً عملياً).
	if _, err := io.ReadFull(rand.Reader, dst[:nonceSize]); err != nil {
		return nil, err
	}

	// نبني النص الصريح (الترويسة + الحمولة) في مخزن مؤقت متجاور.
	plain := make([]byte, plainLen)
	putHeader(plain, h)
	copy(plain[HeaderSize:], payload)

	// Seal يُلحق الـ ciphertext+tag بعد الـ nonce مباشرة.
	out := c.aead.Seal(dst, dst[:nonceSize], plain, nil)
	return out, nil
}

// Open يفكّ datagram ويُعيد الترويسة وشريحة تشير إلى الحمولة داخل scratch.
// scratch مخزن مؤقت قابل لإعادة الاستخدام (يتجنّب التخصيص في المسار الساخن).
// الحمولة المُعادة صالحة حتى استدعاء Open التالي بنفس scratch.
func (c *Codec) Open(scratch, pkt []byte) (Header, []byte, error) {
	if len(pkt) < nonceSize+HeaderSize+tagSize {
		return Header{}, nil, ErrShort
	}
	nonce := pkt[:nonceSize]
	box := pkt[nonceSize:]
	plain, err := c.aead.Open(scratch[:0], nonce, box, nil)
	if err != nil {
		return Header{}, nil, ErrAuthFailed
	}
	if len(plain) < HeaderSize {
		return Header{}, nil, ErrShort
	}
	h := getHeader(plain)
	if h.Version != Version {
		return Header{}, nil, ErrVersion
	}
	return h, plain[HeaderSize:], nil
}
