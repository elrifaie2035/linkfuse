package proto

import (
	"log"
	"time"
)

// ReorderLogger prints, every 30 s while traffic flows, how many packets the
// reorder buffer delivered, how many arrived out of order, how many gaps were
// given up as lost and how many arrived too late (after their gap was given
// up). Lost/late show whether the paths' delay spread exceeds the hold time.
// Call it only from the goroutine that owns the buffer.
type ReorderLogger struct {
	Name string
	at   time.Time
	last [4]uint64
}

func (l *ReorderLogger) Maybe(r *ReorderBuffer, now time.Time) {
	if l.at.IsZero() {
		l.at = now
		l.last = [4]uint64{r.Delivered, r.Reordered, r.Lost, r.Late}
		return
	}
	if now.Sub(l.at) < 30*time.Second {
		return
	}
	cur := [4]uint64{r.Delivered, r.Reordered, r.Lost, r.Late}
	d := [4]uint64{cur[0] - l.last[0], cur[1] - l.last[1], cur[2] - l.last[2], cur[3] - l.last[3]}
	l.at, l.last = now, cur
	if d[0] < 1000 {
		return // idle: nothing worth reporting
	}
	pct := func(x uint64) float64 { return float64(x) * 100 / float64(d[0]) }
	log.Printf("[reorder] %s: %d packets, out of order %.1f%%, lost %d (%.2f%%), late %d (%.2f%%)",
		l.Name, d[0], pct(d[1]), d[2], pct(d[2]), d[3], pct(d[3]))
}
