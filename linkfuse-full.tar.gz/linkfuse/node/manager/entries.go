package manager

import (
	"fmt"
	"log"
	"net/url"
	"sort"
	"strings"
	"sync"
	"time"

	"github.com/linkfuse/node/hotspot"
)

// Provider entries ("مداخل"): the provider reaches the node on several
// interfaces (Proxmox bridges), e.g. 10.5.0.1 on ens19, 10.4.0.1 on ens21.
// Every card / broadband line works on any entry, so each one is started on
// the entry that carries the least capacity right now, and moves to another
// entry when its entry fails. Each entry has its own capacity at the provider,
// so spreading the cards raises the total speed.

// EntryCfg is one provider entry.
type EntryCfg struct {
	Name     string `json:"name"`                // label shown in the panel, e.g. "10.4"
	Iface    string `json:"iface"`               // node interface, e.g. "ens21"
	LoginURL string `json:"login_url,omitempty"` // default: login.login_url with the DHCP gateway as host
	TestURL  string `json:"test_url,omitempty"`
	Disabled bool   `json:"disabled,omitempty"` // keep it configured but start no new cards on it
}

// placement: where a card runs now.
type placement struct {
	entry string
	iface string
	gw    string
}

type entryState struct {
	mu       sync.Mutex
	placed   map[uint16]placement
	failedAt map[string]time.Time // last DHCP/setup failure per entry
}

const entryCooldown = 2 * time.Minute

func (m *Manager) es() *entryState {
	m.entryOnce.Do(func() {
		m.entrySt = &entryState{placed: map[uint16]placement{}, failedAt: map[string]time.Time{}}
	})
	return m.entrySt
}

// Entries returns the configured entries; without an "entries" list the
// single parent_iface is the only entry (old configs keep working).
func (m *Manager) Entries() []EntryCfg {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.entriesLocked()
}

func (m *Manager) entriesLocked() []EntryCfg {
	if len(m.cfg.Entries) == 0 {
		return []EntryCfg{{Name: m.cfg.ParentIface, Iface: m.cfg.ParentIface}}
	}
	out := make([]EntryCfg, 0, len(m.cfg.Entries))
	for _, e := range m.cfg.Entries {
		if e.Name == "" {
			e.Name = e.Iface
		}
		out = append(out, e)
	}
	return out
}

// entryOrder: enabled entries, least loaded first (live capacity placed on
// it), entries that failed in the last 2 minutes last.
func (m *Manager) entryOrder() []EntryCfg {
	m.mu.Lock()
	all := m.entriesLocked()
	load := map[string]int{}
	es := m.es()
	es.mu.Lock()
	for id, cs := range m.cards {
		if p, ok := es.placed[id]; ok {
			load[p.entry] += cs.cfg.BaseKbps
		}
	}
	failed := map[string]bool{}
	for name, t := range es.failedAt {
		if time.Since(t) < entryCooldown {
			failed[name] = true
		}
	}
	es.mu.Unlock()
	m.mu.Unlock()
	var out []EntryCfg
	for _, e := range all {
		if !e.Disabled {
			out = append(out, e)
		}
	}
	sort.SliceStable(out, func(i, j int) bool {
		a, b := out[i], out[j]
		if failed[a.Name] != failed[b.Name] {
			return !failed[a.Name]
		}
		return load[a.Name] < load[b.Name]
	})
	return out
}

func (m *Manager) entryFailed(name string) {
	es := m.es()
	es.mu.Lock()
	es.failedAt[name] = time.Now()
	es.mu.Unlock()
}

func (m *Manager) setPlacement(id uint16, p placement) {
	es := m.es()
	es.mu.Lock()
	es.placed[id] = p
	es.mu.Unlock()
}

func (m *Manager) placementOf(id uint16) (placement, bool) {
	es := m.es()
	es.mu.Lock()
	defer es.mu.Unlock()
	p, ok := es.placed[id]
	return p, ok
}

// ifaceFor: the interface the card runs on now (parent_iface if unknown).
func (m *Manager) ifaceFor(id uint16) string {
	if p, ok := m.placementOf(id); ok && p.iface != "" {
		return p.iface
	}
	return m.cfg.ParentIface
}

// loginCfgFor is the hotspot config for the entry the card runs on: the
// entry's own URLs, or the main login URL pointed at this entry's gateway.
func (m *Manager) loginCfgFor(id uint16) hotspot.Config {
	c := m.loginCfg()
	p, ok := m.placementOf(id)
	if !ok {
		return c
	}
	var e *EntryCfg
	for _, x := range m.Entries() {
		if x.Name == p.entry {
			x := x
			e = &x
		}
	}
	if e != nil && e.LoginURL != "" {
		c.LoginURL = e.LoginURL
		if e.TestURL != "" {
			c.TestURL = e.TestURL
		}
		return c
	}
	if p.gw != "" && len(m.cfg.Entries) > 0 {
		c.LoginURL = withHost(c.LoginURL, p.gw)
		c.TestURL = withHost(c.TestURL, p.gw)
	}
	return c
}

// withHost replaces the host of u (keeps scheme, port and path).
func withHost(u, host string) string {
	pu, err := url.Parse(u)
	if err != nil || pu.Host == "" {
		return u
	}
	if port := pu.Port(); port != "" {
		host += ":" + port
	}
	pu.Host = host
	return pu.String()
}

// entryError: the failure belongs to the entry (no DHCP lease, interface
// problem), so the card is tried on another entry and never blamed.
func entryError(err error) bool {
	if err == nil {
		return false
	}
	s := err.Error()
	return strings.HasPrefix(s, "namespace:") || strings.HasPrefix(s, "dhcp:")
}

// EntryStat is one entry in the panel.
type EntryStat struct {
	Name     string `json:"name"`
	Iface    string `json:"iface"`
	Cards    int    `json:"cards"`
	Kbps     int    `json:"kbps"` // nominal capacity of the live cards on it
	Disabled bool   `json:"disabled,omitempty"`
	Failing  bool   `json:"failing,omitempty"` // DHCP failed in the last 2 minutes
}

func (m *Manager) entryStats(up map[uint16]bool) []EntryStat {
	es := m.es()
	m.mu.Lock()
	all := m.entriesLocked()
	idx := map[string]int{}
	out := make([]EntryStat, len(all))
	for i, e := range all {
		out[i] = EntryStat{Name: e.Name, Iface: e.Iface, Disabled: e.Disabled}
		idx[e.Name] = i
	}
	es.mu.Lock()
	for id, cs := range m.cards {
		p, ok := es.placed[id]
		if !ok {
			continue
		}
		if i, ok := idx[p.entry]; ok {
			out[i].Cards++
			if up[id] {
				out[i].Kbps += cs.cfg.BaseKbps
			}
		}
	}
	for i := range out {
		if t, ok := es.failedAt[out[i].Name]; ok && time.Since(t) < entryCooldown {
			out[i].Failing = true
		}
	}
	es.mu.Unlock()
	m.mu.Unlock()
	return out
}

// sameEntryHealthy: another card on the same entry passed its last check, so
// the entry works and a failing card is the card's own problem.
func (m *Manager) sameEntryHealthy(id uint16) bool {
	p, ok := m.placementOf(id)
	if !ok {
		return m.othersHealthy(id)
	}
	es := m.es()
	es.mu.Lock()
	peers := []uint16{}
	for k, q := range es.placed {
		if k != id && q.entry == p.entry {
			peers = append(peers, k)
		}
	}
	es.mu.Unlock()
	m.healthMu.Lock()
	defer m.healthMu.Unlock()
	for _, k := range peers {
		if m.healthy[k] {
			return true
		}
	}
	return false
}

func LogEntries(es []EntryCfg) {
	if len(es) < 2 {
		return
	}
	names := make([]string, 0, len(es))
	for _, e := range es {
		names = append(names, fmt.Sprintf("%s (%s)", e.Name, e.Iface))
	}
	log.Printf("[node] provider entries: %s - cards are spread over them", strings.Join(names, ", "))
}
