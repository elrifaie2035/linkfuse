package manager

import (
	"context"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestNormalizeDomains(t *testing.T) {
	got := normalizeDomains([]string{" https://JawwalPay.ps/login ", "ewallet.jawwalpay.ps", "jawwalpay.ps", "", "*.palpay.ps", "pibmobile.islamicbank.ps:443"})
	want := "jawwalpay.ps,ewallet.jawwalpay.ps,palpay.ps,pibmobile.islamicbank.ps"
	if strings.Join(got, ",") != want {
		t.Fatalf("got %v", got)
	}
}

func TestSyncDirectRules(t *testing.T) {
	m := New(&NodeConfig{}, filepath.Join(t.TempDir(), "node.json"))
	d := m.direct()
	var cmds []string
	d.runFn = func(args ...string) error { cmds = append(cmds, strings.Join(args, " ")); return nil }
	answers := map[string][]string{"jawwalpay.ps": {"1.2.3.4", "1.2.3.5"}, "palpay.ps": {"5.6.7.8"}}
	d.lookupFn = func(_ context.Context, h string) []string { return answers[h] }

	m.cfg.DirectDomains = []string{"jawwalpay.ps", "palpay.ps"}
	t0 := time.Now()
	m.syncDirect(t0)
	if len(d.applied) != 3 {
		t.Fatalf("want 3 rules, got %v", d.applied)
	}
	if !strings.Contains(strings.Join(cmds, "\n"), "ip rule add to 1.2.3.4/32 lookup main pref 90") {
		t.Fatalf("rule not added: %v", cmds)
	}
	// DNS rotates: old address kept for an hour, then dropped
	answers["jawwalpay.ps"] = []string{"1.2.3.9"}
	m.syncDirect(t0.Add(10 * time.Minute))
	if !d.applied["1.2.3.4"] || !d.applied["1.2.3.9"] {
		t.Fatalf("rotation: %v", d.applied)
	}
	m.syncDirect(t0.Add(2 * time.Hour))
	if d.applied["1.2.3.4"] || !d.applied["1.2.3.9"] {
		t.Fatalf("stale address not removed: %v", d.applied)
	}
	// list emptied: everything removed
	m.cfg.DirectDomains = nil
	m.syncDirect(t0.Add(2*time.Hour + time.Minute))
	if len(d.applied) != 0 {
		t.Fatalf("rules left: %v", d.applied)
	}
}
