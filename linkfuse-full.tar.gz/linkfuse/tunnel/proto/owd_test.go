package proto

import (
	"testing"
	"time"
)

func TestOWDTrackerOffsetAndRestart(t *testing.T) {
	var o OWDTracker
	off := int64(-987654321000) // unrelated clocks: any constant offset
	if q := o.Observe(off + int64(30*time.Millisecond)); q != 0 {
		t.Fatalf("first sample is the baseline, got %v", q)
	}
	if q := o.Observe(off + int64(80*time.Millisecond)); q < 49*time.Millisecond || q > 51*time.Millisecond {
		t.Fatalf("queue 50ms expected, got %v", q)
	}
	// peer restarted: new clock origin far away -> start over, no fake queue
	if q := o.Observe(off + int64(time.Hour)); q != 0 {
		t.Fatalf("restart not detected: %v", q)
	}
}

// Download congestion (a full queue toward the client) must not reduce the
// client's upload share: RTT rises, but the upload one-way delay stays low.
func TestDirectionsAreIndependent(t *testing.T) {
	p := NewPathStats(8000)
	for i := 0; i < 40; i++ {
		p.OnQueueDelay(2 * time.Millisecond)              // upload queue empty
		p.OnRTT(time.Duration(60+i*5) * time.Millisecond) // RTT grows from download load
	}
	if c := p.Congestion(); c < 0.99 {
		t.Fatalf("upload share cut by download load: %.2f", c)
	}
	for i := 0; i < 30; i++ {
		p.OnQueueDelay(120 * time.Millisecond) // real upload queue
	}
	if c := p.Congestion(); c > 0.4 {
		t.Fatalf("upload congestion not detected: %.2f", c)
	}
}
