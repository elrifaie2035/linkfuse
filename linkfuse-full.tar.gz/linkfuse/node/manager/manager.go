// Package manager يدير دورة حياة الكروت فوق عميل النفق: يهيّئ الكرت (namespace +
// هوية وهمية + DHCP + دخول هوتسبوت + سوكيت)، ويضيفه/يزيله حيّاً، ويجمع الإحصاءات،
// ويحفظ قائمة الكروت في ملف الإعداد. تستهلكه واجهة API وبرنامج lf-node.
package manager

import (
	"encoding/json"
	"fmt"
	"log"
	"os"
	"strconv"
	"sync"
	"time"

	"github.com/linkfuse/node/hotspot"
	"github.com/linkfuse/node/identity"
	"github.com/linkfuse/node/netns"
	"github.com/linkfuse/tunnel/client"
)

// CardCfg إعداد كرت كما يُحفَظ في ملف الإعداد.
type CardCfg struct {
	ID       uint16 `json:"id"`
	Username string `json:"username"`
	Password string `json:"password"`
	BaseKbps int    `json:"base_kbps"`
	Kind     string `json:"kind,omitempty"` // "" = hotspot card, "pppoe" = broadband line
}

// KindPPPoE marks a broadband line dialled with PPPoE.
const KindPPPoE = "pppoe"

func (cc CardCfg) isPPPoE() bool { return cc.Kind == KindPPPoE }

// nsCard is the namespace description of a card or line.
func nsCard(id uint16) netns.Card {
	return netns.Card{NS: "lfcard-" + strconv.Itoa(int(id)), MVName: "lfm" + strconv.Itoa(int(id))}
}

// LoginCfg قالب صفحة دخول المزوّد.
type LoginCfg struct {
	LoginURL      string            `json:"login_url"`
	TestURL       string            `json:"test_url"`
	UsernameField string            `json:"username_field"`
	PasswordField string            `json:"password_field"`
	Extra         map[string]string `json:"extra"`
}

// NodeConfig كامل إعداد العقدة.
type NodeConfig struct {
	Server         string     `json:"server"`
	PSK            string     `json:"psk"`
	TunName        string     `json:"tun"`
	TunAddr        string     `json:"tun_addr"`
	MTU            int        `json:"mtu"`
	ParentIface    string     `json:"parent_iface"`
	Entries        []EntryCfg `json:"entries,omitempty"` // provider entries; empty = parent_iface only
	LANIface       string     `json:"lan_iface"`         // e.g. "ens20": users' network routed into the tunnel
	LANSubnet      string     `json:"lan_subnet"`        // e.g. "172.18.0.0/24"; empty = no LAN routing
	ReorderHold    int        `json:"reorder_hold_ms"`
	ReorderCap     int        `json:"reorder_cap"`
	KeepaliveInt   int        `json:"keepalive_ms"`
	PathTimeout    int        `json:"path_timeout_ms"`
	DHCPRetries    int        `json:"dhcp_retries"`
	APIListen      string     `json:"api_listen"` // ":8088"
	APIToken       string     `json:"api_token"`
	Login          LoginCfg   `json:"login"`
	DirectDomains  []string   `json:"direct_domains"`   // sites that bypass the tunnel (local internet)
	DirectIface    string     `json:"direct_iface"`     // interface for direct sites (default: the node's default route)
	ShapeUpPercent int        `json:"shape_up_percent"` // CAKE upload limit as % of live cards; 0 = off
	ShapeRTTms     int        `json:"shape_rtt_ms"`
	TargetActive   int        `json:"target_active"`    // stock cards to keep running (0 = stock off)
	ReplaceLeadMin int        `json:"replace_lead_min"` // start a replacement this many minutes before expiry
	Cards          []CardCfg  `json:"cards"`
}

// cardState حالة كرت في الذاكرة (الإعداد + الهوية).
type cardState struct {
	cfg    CardCfg
	device string // اسم الجهاز الوهمي
	mac    string
}

// Manager المدير.
type Manager struct {
	mu      sync.Mutex
	cfg     *NodeConfig
	cfgPath string
	cl      *client.Client
	cards   map[uint16]*cardState

	stock     *stockStore
	stockOnce sync.Once

	entrySt   *entryState
	entryOnce sync.Once

	directSt   *directState
	directOnce sync.Once

	// upFn brings a card up; defaults to bringUp (tests replace it).
	upFn func(CardCfg) (client.PathConn, identity.Identity, error)
	// upOnFn starts a card on one entry; defaults to bringUpOn (tests replace it).
	upOnFn func(CardCfg, EntryCfg) (client.PathConn, identity.Identity, error)
	// onlineFn / reloginFn default to the real hotspot checks (tests replace them).
	onlineFn  func(nsPath string) bool
	reloginFn func(nsPath string, cc CardCfg) error

	allDownRounds int // watcher rounds in a row where no running card worked

	manualFails map[uint16]int

	healthMu sync.Mutex
	healthy  map[uint16]bool // result of the last watcher check per live card
}

// New ينشئ مديراً من إعداد محمّل.
func New(cfg *NodeConfig, cfgPath string) *Manager {
	m := &Manager{cfg: cfg, cfgPath: cfgPath, cards: map[uint16]*cardState{}}
	m.upFn = m.bringUp
	m.upOnFn = m.bringUpOn
	m.onlineFn = hotspot.Online
	m.reloginFn = func(ns string, cc CardCfg) error {
		if cc.isPPPoE() {
			c := nsCard(cc.ID)
			c.Parent = m.ifaceFor(cc.ID)
			return c.PPPoE(cc.Username, cc.Password, 30*time.Second)
		}
		return hotspot.Login(ns, m.loginCfgFor(cc.ID), cc.Username, cc.Password)
	}
	m.healthy = map[uint16]bool{}
	return m
}

func (m *Manager) loginCfg() hotspot.Config {
	return hotspot.Config{
		LoginURL: m.cfg.Login.LoginURL, TestURL: m.cfg.Login.TestURL,
		UsernameField: m.cfg.Login.UsernameField, PasswordField: m.cfg.Login.PasswordField,
		Extra: m.cfg.Login.Extra,
	}
}

// bringUp starts a card on the least loaded provider entry; when the entry
// itself fails (no DHCP lease, interface problem) it tries the next entry.
func (m *Manager) bringUp(cc CardCfg) (client.PathConn, identity.Identity, error) {
	var lastErr error
	var id identity.Identity
	for _, e := range m.entryOrder() {
		pc, idn, err := m.upOnFn(cc, e)
		id = idn
		if err == nil {
			return pc, id, nil
		}
		lastErr = err
		if !entryError(err) {
			return pc, id, err // the card's own problem: another entry won't help
		}
		m.entryFailed(e.Name)
		log.Printf("[node] card #%d: entry %s failed (%v), trying the next entry", cc.ID, e.Name, err)
	}
	if lastErr == nil {
		lastErr = fmt.Errorf("namespace: no enabled provider entry")
	}
	return client.PathConn{}, id, lastErr
}

// bringUpOn يهيّئ كرتاً كاملاً على مدخل واحد ويُعيد مساره الجاهز للنفق وهويته.
func (m *Manager) bringUpOn(cc CardCfg, e EntryCfg) (client.PathConn, identity.Identity, error) {
	what := "card"
	id := identity.GenerateFor(uint64(cc.ID))
	if cc.isPPPoE() {
		what = "line"
		id = identity.GenerateRouterFor(uint64(cc.ID))
	}
	card := nsCard(cc.ID)
	card.Parent = e.Iface
	card.MAC = id.MAC
	card.HostName = id.DHCPHostName()
	if id.IsAndroid() {
		card.VendorClass = "android-dhcp-13"
	}
	card.Teardown()
	if cc.isPPPoE() {
		log.Printf("[node] %s #%d: identity %q (%s), entry %s", what, cc.ID, id.DeviceName, id.MAC, e.Name)
	} else {
		log.Printf("[node] %s #%d: identity %q (%s), DHCP host name %q, entry %s", what, cc.ID, id.DeviceName, id.MAC, card.HostName, e.Name)
	}
	if err := card.Setup(); err != nil {
		card.Teardown()
		return client.PathConn{}, id, fmt.Errorf("namespace: %w", err)
	}
	if cc.isPPPoE() {
		m.setPlacement(cc.ID, placement{entry: e.Name, iface: e.Iface})
		if err := card.PPPoE(cc.Username, cc.Password, 30*time.Second); err != nil {
			card.Teardown()
			return client.PathConn{}, id, fmt.Errorf("pppoe: %w", err)
		}
		log.Printf("[node] line #%d: PPPoE up, IP %s", cc.ID, card.PPPoEIPv4())
	} else {
		if err := card.DHCP(m.cfg.DHCPRetries, 3*time.Second); err != nil {
			card.Teardown()
			return client.PathConn{}, id, fmt.Errorf("dhcp: %w", err)
		}
		ip, _ := card.IPv4()
		m.setPlacement(cc.ID, placement{entry: e.Name, iface: e.Iface, gw: card.Gateway()})
		log.Printf("[node] card #%d: got IP %s, logging in...", cc.ID, ip)
		if err := hotspot.Login(netns.Path(card.NS), m.loginCfgFor(cc.ID), cc.Username, cc.Password); err != nil {
			card.Teardown()
			return client.PathConn{}, id, fmt.Errorf("hotspot login: %w", err)
		}
	}
	conn, err := netns.DialUDP(netns.Path(card.NS), m.cfg.Server)
	if err != nil {
		card.Teardown()
		return client.PathConn{}, id, fmt.Errorf("tunnel socket: %w", err)
	}
	log.Printf("[node] %s #%d: ready", what, cc.ID)
	return client.PathConn{ID: cc.ID, Conn: conn, BaseKbps: cc.BaseKbps}, id, nil
}

// BringUpInitial يهيّئ كروت الإعداد **بالتتابع** (واحداً تلو الآخر) ويُعيد
// المسارات الناجحة. التتابع ضروري لأن تشغيل عدّة DHCP معاً على نفس خط المزوّد
// يتعارض (أثبتته التجربة: بالتتابع ينجح، بالتوازي يفشل). concurrency يُتجاهَل.
func (m *Manager) BringUpInitial(concurrency int) int {
	n := 0
	m.mu.Lock()
	cards := append([]CardCfg(nil), m.cfg.Cards...)
	m.mu.Unlock()
	for _, cc := range cards {
		pc, id, err := m.upFn(cc)
		if err != nil {
			log.Printf("[node] card #%d FAILED: %v", cc.ID, err)
			continue
		}
		if m.cl != nil {
			m.cl.AddPath(pc) // joins the running tunnel right away
		}
		m.mu.Lock()
		m.cards[cc.ID] = &cardState{cfg: cc, device: id.DeviceName, mac: id.MAC}
		m.mu.Unlock()
		n++
		if n == 1 {
			log.Printf("[node] first card ready - traffic is flowing")
		}
		time.Sleep(1500 * time.Millisecond) // small gap between cards (DHCP)
	}
	return n
}

// Watch runs forever: every interval it checks each live card and logs it in
// again if the hotspot dropped its session, and retries cards that failed
// (e.g. the provider still held the old session for a minute or two).
func (m *Manager) Watch(interval time.Duration) {
	for {
		time.Sleep(interval)
		m.watchRound()
	}
}

// watchRound is one watcher pass (separate so tests can drive it).
func (m *Manager) watchRound() {
	{
		m.mu.Lock()
		live := make([]CardCfg, 0, len(m.cards))
		for _, cs := range m.cards {
			live = append(live, cs.cfg)
		}
		var missing []CardCfg
		for _, cc := range m.cfg.Cards {
			if _, ok := m.cards[cc.ID]; !ok {
				missing = append(missing, cc)
			}
		}
		m.mu.Unlock()

		// Check live cards in parallel (25+ cards x a few seconds each would
		// otherwise take minutes).
		var wg sync.WaitGroup
		sem := make(chan struct{}, 8)
		for _, cc := range live {
			wg.Add(1)
			sem <- struct{}{}
			go func(cc CardCfg) {
				defer wg.Done()
				defer func() { <-sem }()
				ns := netns.Path("lfcard-" + strconv.Itoa(int(cc.ID)))
				if m.onlineFn(ns) {
					m.setHealthy(cc.ID, true)
					m.cardOK(cc.ID)
					return
				}
				log.Printf("[node] card #%d: hotspot session lost, logging in again", cc.ID)
				if err := m.reloginFn(ns, cc); err != nil {
					log.Printf("[node] card #%d: re-login failed: %v", cc.ID, err)
					m.setHealthy(cc.ID, false)
				} else {
					log.Printf("[node] card #%d: back online", cc.ID)
					m.setHealthy(cc.ID, true)
					m.cardOK(cc.ID)
				}
			}(cc)
		}
		wg.Wait()
		for _, cc := range live {
			if !m.isHealthy(cc.ID) {
				m.cardFailed(cc.ID, fmt.Errorf("re-login failed"))
			}
		}
		m.probeWhenAllFail(live)
		for _, cc := range missing {
			if m.cl == nil {
				break
			}
			log.Printf("[node] card #%d: retrying...", cc.ID)
			pc, id, err := m.upFn(cc)
			if err != nil {
				log.Printf("[node] card #%d: still failing: %v", cc.ID, err)
				m.cardFailed(cc.ID, err) // stock card: retired after 2 failures
				m.manualFailed(cc.ID)
				continue
			}
			m.cl.AddPath(pc)
			m.mu.Lock()
			m.cards[cc.ID] = &cardState{cfg: cc, device: id.DeviceName, mac: id.MAC}
			m.mu.Unlock()
			m.healthMu.Lock()
			delete(m.manualFails, cc.ID)
			m.healthMu.Unlock()
		}
		m.maintainStock()
	}
}

// Shutdown logs every card out of the hotspot (in parallel) and removes its
// namespace, so a restart can log the same cards in again right away.
func (m *Manager) Shutdown() {
	m.mu.Lock()
	ids := make([]uint16, 0, len(m.cards))
	for id := range m.cards {
		ids = append(ids, id)
	}
	m.mu.Unlock()
	var wg sync.WaitGroup
	for _, id := range ids {
		wg.Add(1)
		go func(id uint16) {
			defer wg.Done()
			m.mu.Lock()
			cs := m.cards[id]
			m.mu.Unlock()
			c := nsCard(id)
			if cs == nil || !cs.cfg.isPPPoE() {
				hotspot.Logout(netns.Path(c.NS), m.loginCfgFor(id))
			}
			c.Teardown() // also ends PPPoE sessions
		}(id)
	}
	wg.Wait()
	log.Printf("[node] %d cards logged out", len(ids))
}

func (m *Manager) setHealthy(id uint16, ok bool) {
	m.healthMu.Lock()
	m.healthy[id] = ok
	m.healthMu.Unlock()
}

func (m *Manager) isHealthy(id uint16) bool {
	m.healthMu.Lock()
	defer m.healthMu.Unlock()
	ok, seen := m.healthy[id]
	return ok || !seen
}

// othersHealthy: at least one other live card passed its last check, i.e. the
// line works and a failing card is the card's own problem.
func (m *Manager) othersHealthy(id uint16) bool {
	m.healthMu.Lock()
	defer m.healthMu.Unlock()
	for k, ok := range m.healthy {
		if k != id && ok {
			return true
		}
	}
	return false
}

// lineWorks: is the hotspot line usable, judged by the other cards? Before the
// first watcher round there is no health data yet; then any live card counts.
func (m *Manager) lineWorks(except uint16) bool {
	m.healthMu.Lock()
	n := len(m.healthy)
	m.healthMu.Unlock()
	if n == 0 {
		m.mu.Lock()
		defer m.mu.Unlock()
		for id := range m.cards {
			if id != except {
				return true
			}
		}
		return false
	}
	return m.othersHealthy(except)
}

// manualFailed drops a manually added hotspot card (not from the stock) from
// the config after 10 failed rounds (~5 minutes), so an expired card is not
// retried forever. Broadband lines are never dropped.
func (m *Manager) manualFailed(id uint16) {
	m.mu.Lock()
	for _, c := range m.cfg.Cards {
		if c.ID == id && c.isPPPoE() {
			m.mu.Unlock()
			return // broadband lines are permanent: keep redialling
		}
	}
	m.mu.Unlock()
	st := m.stockStore()
	st.mu.Lock()
	inStock := m.stockCard(id) != nil
	st.mu.Unlock()
	if inStock {
		return
	}
	m.healthMu.Lock()
	if m.manualFails == nil {
		m.manualFails = map[uint16]int{}
	}
	m.manualFails[id]++
	n := m.manualFails[id]
	m.healthMu.Unlock()
	if n >= 10 {
		log.Printf("[node] card #%d failed %d times in a row, removed from the config", id, n)
		_ = m.Remove(id)
	}
}

// SetOnlineFuncs replaces the hotspot checks (tests and dev harnesses only).
func (m *Manager) SetOnlineFuncs(online func(string) bool, relogin func(string, CardCfg) error) {
	m.onlineFn, m.reloginFn = online, relogin
}

// SetUpFunc replaces how a card is brought up (tests and dev harnesses only).
func (m *Manager) SetUpFunc(f func(CardCfg) (client.PathConn, identity.Identity, error)) {
	m.upFn = f
}

// AttachClient يربط المدير بعميل النفق بعد إنشائه.
func (m *Manager) AttachClient(cl *client.Client) { m.cl = cl }

// Add يضيف كرتاً جديداً أثناء التشغيل.
func (m *Manager) Add(cc CardCfg) error {
	m.mu.Lock()
	if _, exists := m.cards[cc.ID]; exists {
		m.mu.Unlock()
		return fmt.Errorf("card #%d already exists", cc.ID)
	}
	m.mu.Unlock()

	pc, id, err := m.upFn(cc)
	if err != nil {
		return err
	}
	m.cl.AddPath(pc)
	m.mu.Lock()
	m.cards[cc.ID] = &cardState{cfg: cc, device: id.DeviceName, mac: id.MAC}
	replaced := false
	for i := range m.cfg.Cards {
		if m.cfg.Cards[i].ID == cc.ID { // card already in config (e.g. failed at startup): update, don't duplicate
			m.cfg.Cards[i] = cc
			replaced = true
		}
	}
	if !replaced {
		m.cfg.Cards = append(m.cfg.Cards, cc)
	}
	m.mu.Unlock()
	m.persist()
	return nil
}

// Remove يزيل كرتاً أثناء التشغيل.
func (m *Manager) Remove(id uint16) error {
	m.mu.Lock()
	_, live := m.cards[id]
	inCfg := false
	out := m.cfg.Cards[:0]
	for _, c := range m.cfg.Cards {
		if c.ID == id {
			inCfg = true
			continue
		}
		out = append(out, c)
	}
	m.cfg.Cards = out
	delete(m.cards, id)
	m.mu.Unlock()
	if !live && !inCfg {
		return fmt.Errorf("card #%d not found", id)
	}
	m.healthMu.Lock()
	delete(m.healthy, id)
	m.healthMu.Unlock()
	if live && m.cl != nil {
		m.cl.RemovePath(id)
	}
	netns.Card{NS: "lfcard-" + strconv.Itoa(int(id)), MVName: "lfm" + strconv.Itoa(int(id))}.Teardown()
	es := m.es()
	es.mu.Lock()
	delete(es.placed, id)
	es.mu.Unlock()
	m.persist()
	return nil
}

// CardStat سطر إحصاء كرت للّوحة.
type CardStat struct {
	ID          uint16    `json:"id"`
	Device      string    `json:"device"`
	MAC         string    `json:"mac"`
	Username    string    `json:"username"`
	SRTTms      float64   `json:"srtt_ms"`
	Reliability float64   `json:"reliability"`
	Congestion  float64   `json:"congestion"`
	Weight      int       `json:"weight"`
	TxBytes     uint64    `json:"tx_bytes"`
	RxBytes     uint64    `json:"rx_bytes"`
	Up          bool      `json:"up"`
	Kind        string    `json:"kind,omitempty"`
	Package     string    `json:"package,omitempty"`
	ExpiresAt   time.Time `json:"expires_at,omitempty"`
	Entry       string    `json:"entry,omitempty"`
}

// Snapshot الحالة الكاملة للّوحة.
type Snapshot struct {
	Cards      []CardStat  `json:"cards"`
	TotalTx    uint64      `json:"total_tx"`
	TotalRx    uint64      `json:"total_rx"`
	ActiveUp   int         `json:"active_up"`
	CardCount  int         `json:"card_count"`
	BondedKbps int         `json:"bonded_kbps"` // مجموع سعة الكروت الحيّة
	Entries    []EntryStat `json:"entries"`
}

// Snapshot يجمع إحصاءات النفق مع هويات الكروت.
func (m *Manager) Snapshot() Snapshot {
	var snap Snapshot
	if m.cl == nil {
		return snap
	}
	stats := m.cl.Stats()
	// stock info first (lock order is stock -> manager, never the reverse)
	type stInfo struct {
		pkg string
		exp time.Time
	}
	info := map[uint16]stInfo{}
	sk := m.stockStore()
	sk.mu.Lock()
	for _, c := range sk.Cards {
		if c.Status == StActive {
			info[c.ID] = stInfo{c.Package, c.ExpiresAt}
		}
	}
	sk.mu.Unlock()
	up := map[uint16]bool{}
	for _, st := range stats {
		up[st.ID] = st.Weight > 0
	}
	snap.Entries = m.entryStats(up)
	m.mu.Lock()
	defer m.mu.Unlock()
	snap.TotalTx = m.cl.TxBytes.Load()
	snap.TotalRx = m.cl.RxBytes.Load()
	for _, st := range stats {
		cs := CardStat{
			ID: st.ID, SRTTms: st.SRTTms, Reliability: st.Reliability, Congestion: st.Congestion,
			Weight: st.Weight, TxBytes: st.TxBytes, RxBytes: st.RxBytes,
			Up: st.Weight > 0,
		}
		if si, ok := info[st.ID]; ok {
			cs.Package, cs.ExpiresAt = si.pkg, si.exp
		}
		if p, ok := m.placementOf(st.ID); ok {
			cs.Entry = p.entry
		}
		if info, ok := m.cards[st.ID]; ok {
			cs.Kind = info.cfg.Kind
			cs.Device = info.device
			cs.MAC = info.mac
			cs.Username = info.cfg.Username
			if cs.Up {
				snap.BondedKbps += info.cfg.BaseKbps
			}
		}
		if cs.Up {
			snap.ActiveUp++
		}
		snap.Cards = append(snap.Cards, cs)
	}
	snap.CardCount = len(m.cards)
	return snap
}

// Config يُعيد إعداد العقدة (للـ API: الخادم، منفذ الاستماع…).
func (m *Manager) Config() *NodeConfig { return m.cfg }

func (m *Manager) persist() {
	m.mu.Lock()
	b, err := json.MarshalIndent(m.cfg, "", "  ")
	m.mu.Unlock()
	if err != nil {
		return
	}
	tmp := m.cfgPath + ".tmp"
	if os.WriteFile(tmp, b, 0600) == nil {
		_ = os.Rename(tmp, m.cfgPath)
	}
}

// Load يقرأ إعداد العقدة من ملف.
func Load(path string) (*NodeConfig, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	cfg := &NodeConfig{
		TunName: "lf0", TunAddr: "10.9.0.2/24", MTU: 1400, ParentIface: "ens19",
		ReorderHold: 40, ReorderCap: 4096, KeepaliveInt: 1000, PathTimeout: 5000,
		DHCPRetries: 4, APIListen: ":8088", ShapeUpPercent: 92, ShapeRTTms: 100,
	}
	if err := json.Unmarshal(b, cfg); err != nil {
		return nil, err
	}
	if cfg.PSK == "" || cfg.Server == "" || cfg.Login.LoginURL == "" {
		return nil, fmt.Errorf("psk, server and login.login_url are required")
	}
	return cfg, nil
}
