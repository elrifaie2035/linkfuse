// lf-node: منسّق العقدة المحلية (بصلاحية root).
//
// التشغيل:  lf-node -config /etc/linkfuse/node.json
//
// يهيّئ كروت الإعداد (namespace + هوية وهمية + DHCP + دخول هوتسبوت)، يشغّل عميل
// النفق، ثم يفتح واجهة HTTP للّوحة (إحصاءات حية + إضافة/إزالة كرت أثناء التشغيل).
package main

import (
	"flag"
	"log"
	"os"
	"os/exec"
	"os/signal"
	"strconv"
	"syscall"
	"time"

	"github.com/linkfuse/node/api"
	"github.com/linkfuse/node/manager"
	"github.com/linkfuse/tunnel/client"
)

func main() {
	cfgPath := flag.String("config", "/etc/linkfuse/node.json", "path to JSON config file")
	flag.Parse()

	cfg, err := manager.Load(*cfgPath)
	if err != nil {
		log.Fatalf("[node] config: %v", err)
	}

	// إعدادات النواة في المجال الرئيسي (كما يفعل Octopus) — ضرورية لعبور الإنترنت.
	// Bring the provider line up (it is down after a VM reboot -> DHCP would hang).
	run("sysctl", "-w", "net.ipv4.ip_forward=1")
	run("sysctl", "-w", "net.ipv4.conf.all.rp_filter=0")
	run("sysctl", "-w", "net.ipv4.conf.default.rp_filter=0")
	parents := []string{cfg.ParentIface}
	for _, e := range cfg.Entries {
		parents = append(parents, e.Iface)
	}
	for _, ifc := range parents {
		if ifc == "" {
			continue
		}
		run("ip", "link", "set", ifc, "up")
		run("sysctl", "-w", "net.ipv4.conf."+ifc+".rp_filter=0")
	}
	run("sysctl", "-w", "net.ipv4.conf.all.src_valid_mark=1")

	mgr := manager.New(cfg, *cfgPath)
	manager.LogEntries(mgr.Entries())

	// systemctl stop/restart sends SIGTERM: log the cards out first so the
	// provider does not hold their sessions for 1-2 minutes.
	sig := make(chan os.Signal, 1)
	signal.Notify(sig, syscall.SIGTERM, syscall.SIGINT)
	go func() {
		<-sig
		log.Println("[node] stopping: logging cards out...")
		mgr.Shutdown()
		os.Exit(0)
	}()
	// Tunnel first (with no cards yet), then the cards join one by one while it
	// runs: traffic flows as soon as the first card is ready, and the node (and
	// its API, so the panel can import new cards) stays up even if no card works.
	cl, err := client.New(client.Config{
		TunName:      cfg.TunName,
		PSK:          cfg.PSK,
		ReorderHold:  time.Duration(cfg.ReorderHold) * time.Millisecond,
		ReorderCap:   cfg.ReorderCap,
		KeepaliveInt: time.Duration(cfg.KeepaliveInt) * time.Millisecond,
		PathTimeout:  time.Duration(cfg.PathTimeout) * time.Millisecond,
	}, nil)
	if err != nil {
		log.Fatalf("[node] tunnel client: %v", err)
	}
	mgr.AttachClient(cl)
	setupTun(cfg.TunName, cfg.TunAddr, cfg.MTU)
	setupLAN(cfg.LANIface, cfg.LANSubnet, cfg.TunName)
	go cl.Run()
	go mgr.UploadShapeLoop(cfg.TunName, cfg.ShapeUpPercent, cfg.ShapeRTTms)
	go mgr.DirectLoop(cfg.LANIface, cfg.LANSubnet, 5*time.Minute) // sites that bypass the tunnel

	go func() {
		log.Printf("[node] bringing up %d cards...", len(cfg.Cards))
		n := mgr.BringUpInitial(8)
		if n == 0 {
			log.Println("[node] no card is working yet - waiting for cards (import new ones from the panel)")
		} else {
			log.Printf("[node] %d/%d cards ready", n, len(cfg.Cards))
		}
		mgr.Watch(30 * time.Second) // re-login dropped cards, retry failed ones, run the stock
	}()
	log.Println("[node] tunnel running")

	// واجهة اللوحة (تحجز الـ main).
	if err := api.New(mgr, cfg.APIToken).Run(cfg.APIListen); err != nil {
		log.Fatalf("[node] API: %v", err)
	}
}

func setupTun(name, addr string, mtu int) {
	run("ip", "addr", "add", addr, "dev", name)
	run("ip", "link", "set", "dev", name, "mtu", strconv.Itoa(mtu))
	run("ip", "link", "set", "dev", name, "up")
}

// setupLAN sends all traffic coming from the users' network through the tunnel,
// while the box itself keeps its normal internet (management) route.
// Uses a separate routing table (100) selected by source subnet.
func setupLAN(lanIf, subnet, tun string) {
	if lanIf == "" || subnet == "" {
		log.Println("[node] lan_iface/lan_subnet not set - LAN routing skipped")
		return
	}
	run("ip", "link", "set", lanIf, "up")
	runQuiet("ip", "rule", "del", "from", subnet, "table", "100")
	runQuiet("ip", "rule", "del", "to", subnet, "table", "main")
	// LAN-to-LAN and replies to LAN clients stay local (priority 99 wins over 100).
	run("ip", "rule", "add", "to", subnet, "table", "main", "priority", "99")
	run("ip", "rule", "add", "from", subnet, "table", "100", "priority", "100")
	run("ip", "route", "replace", "default", "dev", tun, "table", "100")
	ensure("-t", "nat", "POSTROUTING", "-s", subnet, "-o", tun, "-j", "MASQUERADE")
	ensure("FORWARD", "-i", lanIf, "-o", tun, "-j", "ACCEPT")
	ensure("FORWARD", "-i", tun, "-o", lanIf, "-m", "conntrack", "--ctstate", "RELATED,ESTABLISHED", "-j", "ACCEPT")
	ensure("-t", "mangle", "FORWARD", "-o", tun, "-p", "tcp", "--tcp-flags", "SYN,RST", "SYN", "-j", "TCPMSS", "--clamp-mss-to-pmtu")
	log.Printf("[node] LAN %s (%s) routed through %s", lanIf, subnet, tun)
}

// ensure adds an iptables rule only if it is not already present.
// args: [-t table] CHAIN rule...
func ensure(args ...string) {
	var table []string
	if args[0] == "-t" {
		table, args = args[:2], args[2:]
	}
	chain, rule := args[0], args[1:]
	check := append(append(append([]string{}, table...), "-C", chain), rule...)
	if exec.Command("iptables", check...).Run() == nil {
		return
	}
	run(append(append(append([]string{"iptables"}, table...), "-A", chain), rule...)...)
}

func runQuiet(args ...string) { _ = exec.Command(args[0], args[1:]...).Run() }

func run(args ...string) {
	if out, err := exec.Command(args[0], args[1:]...).CombinedOutput(); err != nil {
		log.Printf("[setup] %v: %v (%s)", args, err, string(out))
	}
}
