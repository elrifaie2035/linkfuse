import { vpsFetch, QUOTA_GB } from "@/lib/api";
export const dynamic = "force-dynamic";
export async function GET() {
  try {
    const r = await vpsFetch("/api/usage");
    const data = await r.json();
    return Response.json({ ...data, quota_gb: QUOTA_GB });
  } catch (e: any) {
    return Response.json({ error: `تعذّر الوصول للـ VPS: ${e.message}`, quota_gb: QUOTA_GB }, { status: 502 });
  }
}
