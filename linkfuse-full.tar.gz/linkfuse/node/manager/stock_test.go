package manager

import (
	"errors"
	"fmt"
	"net"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/linkfuse/node/identity"
	"github.com/linkfuse/tunnel/client"
)

type nopTUN struct{ ch chan struct{} }

func (t nopTUN) Read(p []byte) (int, error)  { <-t.ch; return 0, errors.New("closed") }
func (t nopTUN) Write(p []byte) (int, error) { return len(p), nil }
func (t nopTUN) Close() error                { return nil }

func testManager(t *testing.T, bad map[string]bool) *Manager {
	dir := t.TempDir()
	cfg := &NodeConfig{PSK: "k", Server: "127.0.0.1:9", TargetActive: 3}
	m := New(cfg, filepath.Join(dir, "node.json"))
	cl, err := client.NewWithTUN(client.Config{PSK: "test-psk-test-psk-test-psk-12345"}, nopTUN{make(chan struct{})}, nil)
	if err != nil {
		t.Fatal(err)
	}
	m.AttachClient(cl)
	m.upFn = func(cc CardCfg) (client.PathConn, identity.Identity, error) {
		if bad[cc.Username] {
			return client.PathConn{}, identity.Identity{}, errors.New("hotspot login: login not confirmed")
		}
		c, err := net.DialUDP("udp", nil, &net.UDPAddr{IP: net.IPv4(127, 0, 0, 1), Port: 9})
		if err != nil {
			return client.PathConn{}, identity.Identity{}, err
		}
		return client.PathConn{ID: cc.ID, Conn: c, BaseKbps: cc.BaseKbps}, identity.GenerateFor(uint64(cc.ID)), nil
	}
	return m
}

func statuses(m *Manager) map[string]int { return m.StockView().Counts }

func TestStockFillReplaceAndBad(t *testing.T) {
	m := testManager(t, map[string]bool{"200000000002": true})
	lines := "Username Password Package\n"
	for _, u := range []string{"100000000001", "200000000002", "300000000003", "400000000004", "500000000005", "600000000006"} {
		lines += u + " 123456 اشتراك يومي 8 ساعات 2 ميجا\n"
	}
	lines += "700000000007 123456 اشتراك شهري\n"
	res, err := m.ImportStock([]byte(lines), 2000)
	if err != nil || res.Added != 7 {
		t.Fatalf("import: %+v %v", res, err)
	}
	// duplicate import is ignored
	if res2, _ := m.ImportStock([]byte(lines), 2000); res2.Added != 0 || res2.Duplicates != 7 {
		t.Fatalf("dup import: %+v", res2)
	}

	m.maintainStock()
	c := statuses(m)
	if c[StActive] != 3 {
		t.Fatalf("want 3 active, got %+v", c)
	}
	// monthly card is preferred first
	if sc := m.stockCard(7); sc == nil || sc.Status != StActive || !sc.ExpiresAt.After(time.Now().Add(700*time.Hour)) {
		t.Fatalf("monthly card should be active with ~30 days: %+v", sc)
	}
	// the bad card (tried while others are live) ends up "bad" after 2 failures
	m.maintainStock()
	if sc := m.stockCard(2); sc == nil || sc.Status == StActive {
		t.Fatalf("bad card state: %+v", sc)
	}

	// a daily card about to expire is replaced with no gap
	var daily *StockCard
	for _, sc := range m.stockStore().Cards {
		if sc.Status == StActive && sc.DurationH == 8 {
			daily = sc
			break
		}
	}
	daily.ExpiresAt = time.Now().Add(1 * time.Minute)
	m.maintainStock()
	if daily.Status != StExpired {
		t.Fatalf("expiring card not retired: %+v", daily)
	}
	if got := statuses(m)[StActive]; got != 3 {
		t.Fatalf("after replace want 3 active, got %d (%+v)", got, statuses(m))
	}
	if len(m.Config().Cards) != 3 || len(m.cards) != 3 {
		t.Fatalf("config/live mismatch: cfg=%d live=%d", len(m.Config().Cards), len(m.cards))
	}

	// lower the target: extra cards stop
	m.mu.Lock()
	m.cfg.TargetActive = 1
	m.mu.Unlock()
	m.maintainStock()
	if got := statuses(m)[StActive]; got != 1 {
		t.Fatalf("after lowering target want 1 active, got %d", got)
	}
	// parked cards keep their clock and are picked first when the target rises
	m.mu.Lock()
	m.cfg.TargetActive = 2
	m.mu.Unlock()
	m.maintainStock()
	for _, sc := range m.stockStore().Cards {
		if sc.Status == StActive && sc.FirstLogin.IsZero() {
			t.Fatalf("a fresh card was started while a parked one was available: %+v", sc)
		}
	}

	// stock persists across restarts
	m2 := New(&NodeConfig{}, m.cfgPath)
	if len(m2.StockView().Cards) != 7 {
		t.Fatalf("stock not persisted")
	}
	if _, err := os.Stat(m.stockPath()); err != nil {
		t.Fatal(err)
	}
	if v := m.StockView(); v.Cards[0].Password != "" {
		t.Fatal("password leaked in view")
	}
	t.Logf("final counts: %+v", statuses(m))
}

func TestLineOutageDoesNotBurnStock(t *testing.T) {
	m := testManager(t, nil)
	lines := "100000000001 1 اشتراك يومي 8 ساعات\n200000000002 1 اشتراك يومي 8 ساعات\n300000000003 1 اشتراك يومي 8 ساعات\n400000000004 1 اشتراك يومي 8 ساعات\n"
	if _, err := m.ImportStock([]byte(lines), 2000); err != nil {
		t.Fatal(err)
	}
	m.maintainStock()
	if statuses(m)[StActive] != 3 {
		t.Fatalf("want 3 active: %+v", statuses(m))
	}
	// whole line down: every check, re-login and fresh login fails, many rounds
	m.SetOnlineFuncs(func(string) bool { return false }, func(string, CardCfg) error { return errors.New("timeout") })
	goodUp := m.upFn
	m.upFn = func(CardCfg) (client.PathConn, identity.Identity, error) {
		return client.PathConn{}, identity.Identity{}, errors.New("dhcp: timeout")
	}
	for i := 0; i < 6; i++ {
		m.watchRound()
	}
	m.upFn = goodUp
	if c := statuses(m); c[StActive] != 3 || c[StExpired]+c[StBad] != 0 {
		t.Fatalf("line outage burned cards: %+v", c)
	}
	if sc := m.stockCard(4); sc.Status != StUnused {
		t.Fatalf("probe card must stay usable after an outage: %+v", sc)
	}
	// only card #1 fails while the others work: parked after 2 rounds,
	// a fresh card takes its place
	m.SetOnlineFuncs(func(ns string) bool { return !strings.HasSuffix(ns, "lfcard-1") },
		func(string, CardCfg) error { return errors.New("login refused: uptime limit") })
	// rounds 1-2: refused twice -> parked, and (clock running) tried again first;
	// rounds 3-4: still refused -> marked bad, a fresh card fills the slot
	for i := 0; i < 4; i++ {
		m.watchRound()
	}
	if sc := m.stockCard(1); sc.Status != StBad {
		t.Fatalf("card 1 should be bad after 4 refusals: %+v", sc)
	}
	if c := statuses(m); c[StActive] != 3 || c[StUnused] != 0 {
		t.Fatalf("slot not refilled: %+v", c)
	}
}

// A batch of cards started together runs out together: every check fails, but
// a fresh card logs in. The probe must detect it and the batch gets replaced.
func TestWholeBatchExpires(t *testing.T) {
	m := testManager(t, nil)
	var lines string
	for i := 1; i <= 6; i++ {
		lines += fmt.Sprintf("%012d 1 اشتراك يومي 8 ساعات\n", i)
	}
	if _, err := m.ImportStock([]byte(lines), 2000); err != nil {
		t.Fatal(err)
	}
	m.maintainStock() // cards 1-3 run
	old := map[string]bool{"lfcard-1": true, "lfcard-2": true, "lfcard-3": true}
	m.SetOnlineFuncs(func(ns string) bool { return !old[filepath.Base(ns)] },
		func(string, CardCfg) error { return errors.New("login refused: uptime limit reached") })
	for i := 0; i < 8; i++ {
		m.watchRound()
	}
	for id := uint16(1); id <= 3; id++ {
		if sc := m.stockCard(id); sc.Status == StActive {
			t.Fatalf("expired card #%d still active: %+v", id, sc)
		}
	}
	if c := statuses(m); c[StActive] != 3 {
		t.Fatalf("batch not replaced: %+v", c)
	}
}
