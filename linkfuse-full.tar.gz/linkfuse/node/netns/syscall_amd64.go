//go:build linux && amd64

package netns

const sysSetns = 308
