import { nodeFetch } from "@/lib/api";
export const dynamic = "force-dynamic";
export async function GET() {
  try {
    const r = await nodeFetch("/api/direct");
    return new Response(await r.text(), { status: r.status, headers: { "Content-Type": "application/json" } });
  } catch (e: any) {
    return Response.json({ error: `تعذّر الوصول للعقدة: ${e.message}` }, { status: 502 });
  }
}
export async function POST(req: Request) {
  const r = await nodeFetch("/api/direct", { method: "POST", body: await req.text() });
  return new Response(await r.text(), { status: r.status, headers: { "Content-Type": "application/json" } });
}
