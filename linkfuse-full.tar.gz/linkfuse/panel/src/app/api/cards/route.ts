import { nodeFetch } from "@/lib/api";
export const dynamic = "force-dynamic";
export async function GET() {
  const r = await nodeFetch("/api/cards");
  return new Response(await r.text(), { status: r.status, headers: { "Content-Type": "application/json" } });
}
export async function POST(req: Request) {
  const body = await req.text();
  const r = await nodeFetch("/api/cards", { method: "POST", body });
  return new Response(await r.text(), { status: r.status, headers: { "Content-Type": "application/json" } });
}
