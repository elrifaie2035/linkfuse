package manager

import (
	"fmt"
	"testing"

	"github.com/linkfuse/node/identity"
	"github.com/linkfuse/tunnel/client"
)

func entryMgr(t *testing.T, down map[string]bool) *Manager {
	cfg := &NodeConfig{ParentIface: "ens19", Entries: []EntryCfg{
		{Name: "10.5", Iface: "ens19"}, {Name: "10.4", Iface: "ens21"}, {Name: "10.3", Iface: "ens22"},
	}}
	m := New(cfg, t.TempDir()+"/node.json")
	m.upOnFn = func(cc CardCfg, e EntryCfg) (client.PathConn, identity.Identity, error) {
		if down[e.Name] {
			return client.PathConn{}, identity.Identity{}, fmt.Errorf("dhcp: no lease")
		}
		m.setPlacement(cc.ID, placement{entry: e.Name, iface: e.Iface})
		return client.PathConn{ID: cc.ID}, identity.Identity{}, nil
	}
	return m
}

func start(t *testing.T, m *Manager, id uint16, kbps int) {
	cc := CardCfg{ID: id, BaseKbps: kbps}
	if _, _, err := m.bringUp(cc); err != nil {
		t.Fatalf("card %d: %v", id, err)
	}
	m.mu.Lock()
	m.cards[id] = &cardState{cfg: cc}
	m.mu.Unlock()
}

func TestCardsSpreadOverEntries(t *testing.T) {
	m := entryMgr(t, nil)
	start(t, m, 1, 8000) // broadband line
	for id := uint16(2); id <= 9; id++ {
		start(t, m, id, 2000)
	}
	got := map[string]int{}
	for _, e := range m.entryStats(map[uint16]bool{1: true, 2: true, 3: true, 4: true, 5: true, 6: true, 7: true, 8: true, 9: true}) {
		got[e.Name] = e.Kbps
	}
	// 24000 kbit in total: 8000 on each entry
	for name, k := range got {
		if k != 8000 {
			t.Fatalf("uneven spread: %v (entry %s)", got, name)
		}
	}
}

func TestDeadEntryIsSkipped(t *testing.T) {
	m := entryMgr(t, map[string]bool{"10.5": true})
	start(t, m, 1, 2000)
	p, _ := m.placementOf(1)
	if p.entry == "10.5" {
		t.Fatal("card placed on the dead entry")
	}
	// the dead entry is now in cooldown: the next card does not even try it first
	order := m.entryOrder()
	if order[len(order)-1].Name != "10.5" {
		t.Fatalf("failed entry not moved last: %+v", order)
	}
}

func TestLoginURLFollowsEntryGateway(t *testing.T) {
	m := entryMgr(t, nil)
	m.cfg.Login = LoginCfg{LoginURL: "http://10.5.0.1/login", TestURL: "http://10.5.0.1"}
	m.setPlacement(7, placement{entry: "10.4", iface: "ens21", gw: "10.4.0.1"})
	c := m.loginCfgFor(7)
	if c.LoginURL != "http://10.4.0.1/login" || c.TestURL != "http://10.4.0.1" {
		t.Fatalf("login not pointed at the entry gateway: %+v", c)
	}
}
