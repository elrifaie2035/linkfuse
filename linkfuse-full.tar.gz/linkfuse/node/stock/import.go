// Package stock parses card lists (Excel .xlsx or plain text) for import into
// the card stock. Standard library only.
package stock

import (
	"archive/zip"
	"bytes"
	"encoding/xml"
	"fmt"
	"io"
	"math"
	"regexp"
	"strconv"
	"strings"
)

// Entry is one card read from a file.
type Entry struct {
	Username  string  `json:"username"`
	Password  string  `json:"password"`
	Package   string  `json:"package"`
	DurationH float64 `json:"duration_h"` // 0 = unknown (no clock expiry)
}

// Report summarises a parse.
type Report struct {
	Entries         []Entry  `json:"-"`
	MissingPassword []string `json:"missing_password"` // usernames without a password (skipped)
	Rows            int      `json:"rows"`
}

// Parse accepts an .xlsx file (zip, starts with "PK") or text with one card per
// line: "username password [package]" separated by spaces, tabs, ':' , ',' or ';'.
func Parse(data []byte) (Report, error) {
	if bytes.HasPrefix(data, []byte("PK")) {
		rows, err := xlsxRows(data)
		if err != nil {
			return Report{}, err
		}
		return fromRows(rows), nil
	}
	var rows [][]string
	for _, line := range strings.Split(string(data), "\n") {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		f := regexp.MustCompile(`[\s:,;]+`).Split(line, 3)
		rows = append(rows, f)
	}
	return fromRows(rows), nil
}

// fromRows finds the Username/Password/Package columns from header rows
// (headers may repeat, as in the provider's export) and reads every data row.
func fromRows(rows [][]string) Report {
	ui, pi, ki := 0, 1, 2
	var rep Report
	seen := map[string]bool{}
	for _, r := range rows {
		cell := func(i int) string {
			if i < len(r) {
				return strings.TrimSpace(r[i])
			}
			return ""
		}
		if isHeader(r) {
			for i, c := range r {
				switch strings.ToLower(strings.TrimSpace(c)) {
				case "username", "user", "اسم المستخدم":
					ui = i
				case "password", "pass", "كلمة المرور":
					pi = i
				case "package", "profile", "الباقة":
					ki = i
				}
			}
			continue
		}
		u := cell(ui)
		if u == "" || !regexp.MustCompile(`^[0-9A-Za-z._@-]{3,}$`).MatchString(u) {
			continue
		}
		rep.Rows++
		if seen[u] {
			continue
		}
		seen[u] = true
		p := cell(pi)
		if p == "" {
			rep.MissingPassword = append(rep.MissingPassword, u)
			continue
		}
		pkg := cell(ki)
		rep.Entries = append(rep.Entries, Entry{Username: u, Password: p, Package: pkg, DurationH: DurationHours(pkg)})
	}
	return rep
}

func isHeader(r []string) bool {
	for _, c := range r {
		switch strings.ToLower(strings.TrimSpace(c)) {
		case "username", "user", "اسم المستخدم":
			return true
		}
	}
	return false
}

var reHours = regexp.MustCompile(`(\d+(?:\.\d+)?)\s*(ساعات|ساعة|ساعه|hours?|h\b)`)
var reDays = regexp.MustCompile(`(\d+)\s*(أيام|ايام|يوم|days?)`)

// DurationHours reads the validity from the provider's package name, e.g.
// "اشتراك يومي 8 ساعات 2 ميجا" -> 8, "شهري" -> 720. 0 = unknown.
func DurationHours(pkg string) float64 {
	if m := reHours.FindStringSubmatch(pkg); m != nil {
		v, _ := strconv.ParseFloat(m[1], 64)
		return v
	}
	if m := reDays.FindStringSubmatch(pkg); m != nil {
		v, _ := strconv.ParseFloat(m[1], 64)
		return v * 24
	}
	switch {
	case strings.Contains(pkg, "شهر") || strings.Contains(strings.ToLower(pkg), "month"):
		return 30 * 24
	case strings.Contains(pkg, "أسبوع") || strings.Contains(pkg, "اسبوع") || strings.Contains(strings.ToLower(pkg), "week"):
		return 7 * 24
	case strings.Contains(pkg, "يوم") || strings.Contains(strings.ToLower(pkg), "day"):
		return 24
	}
	return 0
}

// ---- minimal .xlsx reader (first worksheet) ----

type xSST struct {
	SI []struct {
		T string `xml:"t"`
		R []struct {
			T string `xml:"t"`
		} `xml:"r"`
	} `xml:"si"`
}

type xSheet struct {
	Rows []struct {
		C []struct {
			R  string `xml:"r,attr"`
			T  string `xml:"t,attr"`
			V  string `xml:"v"`
			IS struct {
				T string `xml:"t"`
			} `xml:"is"`
		} `xml:"c"`
	} `xml:"sheetData>row"`
}

func xlsxRows(data []byte) ([][]string, error) {
	zr, err := zip.NewReader(bytes.NewReader(data), int64(len(data)))
	if err != nil {
		return nil, fmt.Errorf("not a valid .xlsx file: %w", err)
	}
	read := func(name string) ([]byte, error) {
		for _, f := range zr.File {
			if f.Name == name {
				rc, err := f.Open()
				if err != nil {
					return nil, err
				}
				defer rc.Close()
				return io.ReadAll(io.LimitReader(rc, 64<<20))
			}
		}
		return nil, nil
	}
	var shared []string
	if b, err := read("xl/sharedStrings.xml"); err != nil {
		return nil, err
	} else if b != nil {
		var sst xSST
		if err := xml.Unmarshal(b, &sst); err != nil {
			return nil, fmt.Errorf("sharedStrings: %w", err)
		}
		for _, si := range sst.SI {
			s := si.T
			for _, r := range si.R {
				s += r.T
			}
			shared = append(shared, s)
		}
	}
	sheetName := "xl/worksheets/sheet1.xml"
	b, err := read(sheetName)
	if err != nil {
		return nil, err
	}
	if b == nil { // fall back to the first worksheet present
		for _, f := range zr.File {
			if strings.HasPrefix(f.Name, "xl/worksheets/") && strings.HasSuffix(f.Name, ".xml") {
				if b, err = read(f.Name); err != nil {
					return nil, err
				}
				break
			}
		}
	}
	if b == nil {
		return nil, fmt.Errorf("no worksheet found in the .xlsx file")
	}
	var sh xSheet
	if err := xml.Unmarshal(b, &sh); err != nil {
		return nil, fmt.Errorf("worksheet: %w", err)
	}
	var out [][]string
	for _, row := range sh.Rows {
		var cells []string
		for _, c := range row.C {
			col := colIndex(c.R)
			for len(cells) < col {
				cells = append(cells, "")
			}
			var v string
			switch c.T {
			case "s":
				if i, err := strconv.Atoi(c.V); err == nil && i >= 0 && i < len(shared) {
					v = shared[i]
				}
			case "inlineStr":
				v = c.IS.T
			case "str", "b", "e":
				v = c.V
			default: // number: Excel may write 1.2E+11 for long IDs
				v = numberText(c.V)
			}
			cells = append(cells, v)
		}
		out = append(out, cells)
	}
	return out, nil
}

// colIndex turns "C12" into 2 (0-based). Missing reference -> append position.
func colIndex(ref string) int {
	n := 0
	for _, ch := range ref {
		if ch >= 'A' && ch <= 'Z' {
			n = n*26 + int(ch-'A'+1)
		} else {
			break
		}
	}
	if n == 0 {
		return -1
	}
	return n - 1
}

func numberText(v string) string {
	if v == "" {
		return ""
	}
	f, err := strconv.ParseFloat(v, 64)
	if err != nil {
		return v
	}
	if f == math.Trunc(f) && math.Abs(f) < 1e15 {
		return strconv.FormatFloat(f, 'f', 0, 64)
	}
	return v
}
