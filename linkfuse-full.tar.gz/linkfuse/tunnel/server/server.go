// Package server هو طرف الدمج على الـ VPS (فرانكفورت).
// يستمع على منفذ UDP واحد تصله حزم الكروت الخمسين (كلٌّ بعنوان مصدر مختلف بعد
// NAT المزوّد). يميّز المسار من pathID داخل الترويسة المشفّرة، يعيد الترتيب،
// ويكتب حركة المستخدم على جهاز TUN يخرج منه إلى الإنترنت عبر NAT الـ VPS.
// الاتجاه العكسي (ردّ الإنترنت) يُوزَّع على المسارات بنفس موزّع الأوزان.
package server

import (
	"encoding/binary"
	"encoding/json"
	"log"
	"net"
	"net/http"
	"sync"
	"sync/atomic"
	"time"

	"github.com/linkfuse/tunnel/proto"
	"github.com/linkfuse/tunnel/tundev"
)

// Config إعداد الخادم.
type Config struct {
	Listen       string        // عنوان الاستماع، مثلاً ":51820"
	TunName      string        // اسم جهاز TUN، مثلاً "lf0"
	PSK          string        // المفتاح المشترك مع العميل
	BaseKbps     int           // سعة الكرت الاسمية الافتراضية (للوزن الابتدائي)
	ReorderHold  time.Duration // مهلة انتظار الحزمة الناقصة (مثلاً 40ms)
	ReorderCap   int           // سعة مخزن إعادة الترتيب (مثلاً 4096)
	KeepaliveInt time.Duration // فترة النبضات (مثلاً 1s)
	PathTimeout  time.Duration // بعدها يُعدّ المسار ساقطاً (مثلاً 5s)
}

// clientPath حالة مسار (كرت) كما يراها الخادم.
type clientPath struct {
	id       uint16
	addr     atomic.Pointer[net.UDPAddr] // آخر عنوان مصدر رأيناه لهذا الكرت
	stats    *proto.PathStats
	awaiting atomic.Bool // أُرسلت نبضة ولم يصل ردّها بعد (لتقدير الفقدان)
}

// Server الحالة الكاملة.
type Server struct {
	cfg   Config
	codec *proto.Codec
	conn  *net.UDPConn
	tun   proto.TUN
	sched *proto.Scheduler

	mu    sync.RWMutex
	paths map[uint16]*clientPath

	reorder *proto.ReorderBuffer
	txSeq   uint64 // تسلسل الاتجاه العكسي (خادم→عميل)

	RxBytes atomic.Uint64 // إجمالي الوارد (محاسبة حصة الـ VPS)
	TxBytes atomic.Uint64 // إجمالي الصادر
	started time.Time
}

// New يجهّز الخادم بفتح جهاز TUN حقيقي (للإنتاج).
func New(cfg Config) (*Server, error) {
	tun, err := tundev.Open(cfg.TunName)
	if err != nil {
		return nil, err
	}
	return NewWithTUN(cfg, tun)
}

// NewWithTUN يجهّز الخادم بجهاز TUN مُعطى (يتيح الحقن في الاختبار).
func NewWithTUN(cfg Config, tun proto.TUN) (*Server, error) {
	codec, err := proto.NewCodec(cfg.PSK)
	if err != nil {
		return nil, err
	}
	udpAddr, err := net.ResolveUDPAddr("udp4", cfg.Listen)
	if err != nil {
		return nil, err
	}
	conn, err := net.ListenUDP("udp4", udpAddr)
	if err != nil {
		return nil, err
	}
	_ = conn.SetReadBuffer(4 << 20)
	_ = conn.SetWriteBuffer(4 << 20)

	s := &Server{
		cfg:     cfg,
		codec:   codec,
		conn:    conn,
		tun:     tun,
		sched:   proto.NewScheduler(),
		paths:   make(map[uint16]*clientPath),
		started: time.Now(),
	}
	// يكتب reorderه حزم العميل على TUN مباشرة.
	s.reorder = proto.NewReorderBuffer(cfg.ReorderHold, cfg.ReorderCap, func(pkt []byte) {
		_, _ = s.tun.Write(pkt)
	})
	log.Printf("[server] listening on %s, device %s ready", conn.LocalAddr(), cfg.TunName)
	return s, nil
}

// Addr يُعيد عنوان الاستماع الفعلي (مفيد عند استخدام منفذ عشوائي ":0").
func (s *Server) Addr() string { return s.conn.LocalAddr().String() }

// Usage لقطة استهلاك لعدّاد حصة الـ VPS.
type Usage struct {
	RxBytes   uint64  `json:"rx_bytes"`    // وارد من الكروت
	TxBytes   uint64  `json:"tx_bytes"`    // صادر إلى الكروت
	TotalByte uint64  `json:"total_bytes"` // المجموع (ما يُحسب على حصة الـ VPS)
	UptimeSec float64 `json:"uptime_sec"`
	Paths     int     `json:"paths"`
}

// ServeAPI يفتح واجهة HTTP تعرض الاستهلاك (لعدّاد الحصة في اللوحة).
func (s *Server) ServeAPI(listen, token string) error {
	mux := http.NewServeMux()
	mux.HandleFunc("/api/usage", func(w http.ResponseWriter, r *http.Request) {
		if token != "" && r.Header.Get("Authorization") != "Bearer "+token {
			w.WriteHeader(401)
			return
		}
		s.mu.RLock()
		np := len(s.paths)
		s.mu.RUnlock()
		rx, tx := s.RxBytes.Load(), s.TxBytes.Load()
		u := Usage{
			RxBytes: rx, TxBytes: tx, TotalByte: rx + tx,
			UptimeSec: time.Since(s.started).Seconds(), Paths: np,
		}
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(u)
	})
	log.Printf("[server] usage API on %s", listen)
	return http.ListenAndServe(listen, mux)
}

// Run يشغّل كل الحلقات حتى يُغلَق الاتصال.
func (s *Server) Run() {
	go s.tunToPaths() // الاتجاه العكسي: الإنترنت → الكروت
	go s.keepaliveLoop()
	go s.healthLoop()
	s.pathsToTun() // الاتجاه الأمامي: الكروت → الإنترنت (يحجز الـ goroutine الرئيسية)
}

// learnBase reads the path capacity the client puts in keepalive/hello frames.
func (s *Server) learnBase(p *clientPath, payload []byte) {
	if len(payload) < 4 {
		return // older client: keep the configured default
	}
	kb := int(binary.BigEndian.Uint32(payload))
	if kb > 0 && kb < 10_000_000 && kb != p.stats.Base() {
		p.stats.SetBaseKbps(kb)
		log.Printf("[server] path #%d capacity %d kbps", p.id, kb)
	}
}

// getOrCreatePath يجلب مسار كرت أو ينشئه عند أول ظهور.
func (s *Server) getOrCreatePath(id uint16) *clientPath {
	s.mu.RLock()
	p := s.paths[id]
	s.mu.RUnlock()
	if p != nil {
		return p
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if p = s.paths[id]; p != nil {
		return p
	}
	p = &clientPath{id: id, stats: proto.NewPathStats(s.cfg.BaseKbps)}
	s.paths[id] = p
	s.sched.Upsert(id, s.cfg.BaseKbps, true)
	log.Printf("[server] new path #%d appeared", id)
	return p
}

// pathsToTun: حلقة الاستقبال. تقرأ من UDP، تفكّ، وتوجّه حسب النوع.
func (s *Server) pathsToTun() {
	buf := make([]byte, proto.Overhead+proto.MaxPayload+64)
	scratch := make([]byte, proto.MaxPayload+proto.HeaderSize+64)
	for {
		// مهلة قصيرة كي تعود ReadFrom دورياً فنُشغّل Tick لإعادة الترتيب.
		_ = s.conn.SetReadDeadline(time.Now().Add(20 * time.Millisecond))
		n, src, err := s.conn.ReadFromUDP(buf)
		now := time.Now()
		if err != nil {
			if ne, ok := err.(net.Error); ok && ne.Timeout() {
				s.reorder.Tick(now)
				continue
			}
			log.Printf("[server] UDP read error: %v", err)
			return
		}
		h, payload, err := s.codec.Open(scratch, buf[:n])
		if err != nil {
			continue // حزمة تالفة/مزيّفة — تُتجاهَل بصمت
		}
		p := s.getOrCreatePath(h.PathID)
		p.addr.Store(src) // نتعلّم/نحدّث عنوان الكرت (يتغيّر مع تغيّر NAT المزوّد)
		p.stats.Touch(now, n)
		s.RxBytes.Add(uint64(n))

		switch h.Type {
		case proto.TypeData:
			s.reorder.Push(h.Seq, payload, now)
		case proto.TypeKeepalive:
			s.sendCtrl(p, proto.TypeKeepaliveAck, h.TS) // نردّ فوراً بنفس الطابع الزمني
			s.learnBase(p, payload)
		case proto.TypeKeepaliveAck:
			rtt := now.Sub(time.Unix(0, h.TS))
			if rtt > 0 && rtt < 10*time.Second {
				p.stats.OnRTT(rtt)
			}
			p.awaiting.Store(false)
			s.sched.SetUp(p.id, true)
		case proto.TypeHello:
			s.sched.SetUp(p.id, true)
			s.learnBase(p, payload)
		case proto.TypeBye:
			s.sched.Remove(p.id) // نتوقّف فوراً عن الإرسال على هذا الكرت
			s.mu.Lock()
			delete(s.paths, p.id)
			s.mu.Unlock()
			log.Printf("[server] path #%d removed (bye from client)", p.id)
		}
		s.reorder.Tick(now)
	}
}

// tunToPaths: الاتجاه العكسي. يقرأ ردّ الإنترنت من TUN ويوزّعه على الكروت.
func (s *Server) tunToPaths() {
	pkt := make([]byte, proto.MaxPayload+64)
	out := make([]byte, proto.Overhead+proto.MaxPayload+64)
	for {
		n, err := s.tun.Read(pkt)
		if err != nil {
			log.Printf("[server] TUN read error: %v", err)
			return
		}
		if n == 0 || n > proto.MaxPayload {
			continue
		}
		id, ok := s.sched.Pick()
		if !ok {
			continue // لا مسار حيّ — تُسقَط (ستُعاد إرسالها من TCP)
		}
		s.mu.RLock()
		p := s.paths[id]
		s.mu.RUnlock()
		if p == nil {
			continue
		}
		addr := p.addr.Load()
		if addr == nil {
			continue
		}
		seq := atomic.AddUint64(&s.txSeq, 1) - 1
		h := proto.Header{Type: proto.TypeData, PathID: id, Seq: seq}
		sealed, err := s.codec.Seal(out, h, pkt[:n])
		if err != nil {
			continue
		}
		if _, err := s.conn.WriteToUDP(sealed, addr); err == nil {
			p.stats.AddTx(len(sealed))
			s.TxBytes.Add(uint64(len(sealed)))
		}
	}
}

// sendCtrl يرسل إطار تحكّم (نبضة/ردّ) على مسار محدّد.
func (s *Server) sendCtrl(p *clientPath, t proto.FrameType, ts int64) {
	addr := p.addr.Load()
	if addr == nil {
		return
	}
	out := make([]byte, proto.Overhead+16)
	h := proto.Header{Type: t, PathID: p.id, TS: ts}
	sealed, err := s.codec.Seal(out, h, nil)
	if err != nil {
		return
	}
	_, _ = s.conn.WriteToUDP(sealed, addr)
}

// keepaliveLoop يرسل نبضة قياس على كل مسار دورياً ويقدّر الفقدان.
func (s *Server) keepaliveLoop() {
	t := time.NewTicker(s.cfg.KeepaliveInt)
	defer t.Stop()
	for range t.C {
		s.mu.RLock()
		list := make([]*clientPath, 0, len(s.paths))
		for _, p := range s.paths {
			list = append(list, p)
		}
		s.mu.RUnlock()
		for _, p := range list {
			if p.awaiting.Swap(true) {
				p.stats.OnKeepaliveLost() // النبضة السابقة لم تُردّ → فقدان
			}
			s.sendCtrl(p, proto.TypeKeepalive, time.Now().UnixNano())
			s.sched.Upsert(p.id, p.stats.Weight(), !p.stats.IsStale(time.Now(), s.cfg.PathTimeout))
		}
	}
}

// healthLoop يحدّث حالة المسارات (ساقط/حيّ) وأوزانها في الموزّع.
func (s *Server) healthLoop() {
	t := time.NewTicker(time.Second)
	defer t.Stop()
	for range t.C {
		now := time.Now()
		s.mu.RLock()
		for _, p := range s.paths {
			up := !p.stats.IsStale(now, s.cfg.PathTimeout)
			s.sched.Upsert(p.id, p.stats.Weight(), up)
		}
		s.mu.RUnlock()
	}
}
