package proto

import (
	"sync"
	"time"
)

// One-way queueing delay, per direction.
//
// Each side stamps its keepalives with its own monotonic clock (MonoNow). The
// receiver computes recv - sent: that includes an unknown constant offset (the
// two clocks are unrelated), so only its change matters. The lowest value seen
// is the empty-queue baseline; anything above it is queueing delay in THAT
// direction. The receiver sends this back in its keepalive-ack, so the sender
// learns how full the queue is on the path it sends on, without download
// traffic making the upload look congested (and the reverse).
//
// Monotonic clocks are immune to wall-clock steps (date -s, NTP).

var procStart = time.Now()

// MonoNow is nanoseconds since this process started (monotonic).
func MonoNow() int64 { return int64(time.Since(procStart)) }

// OWDTracker turns raw one-way samples into queueing delay.
//
// The baseline is the lowest sample of the last OWDWindow (kept as per-bucket
// minima), not of all time: the node has no NTP, so its clock runs at a
// slightly different rate than the VPS. Over hours that drift (tens of ms per
// hour) looked like a growing queue in one direction and pushed the download
// limit down to ~25%. A 2-minute window absorbs the drift (a few ms) while a
// real queue that builds during a transfer is still seen.
type OWDTracker struct {
	mu      sync.Mutex
	buckets [owdBuckets]owdBucket
	have    bool
}

type owdBucket struct {
	idx int64 // bucket number (local time / bucket length)
	min int64
	ok  bool
}

const (
	OWDWindow  = 2 * time.Minute
	owdBuckets = 12
	owdBucketD = int64(OWDWindow / owdBuckets)
)

// Observe takes recv-minus-sent (ns) and returns the queueing delay.
func (o *OWDTracker) Observe(owd int64) time.Duration { return o.ObserveAt(owd, MonoNow()) }

// ObserveAt is Observe with an explicit local time (ns), for tests.
func (o *OWDTracker) ObserveAt(owd, now int64) time.Duration {
	o.mu.Lock()
	defer o.mu.Unlock()
	idx := now / owdBucketD
	if o.have {
		if base, ok := o.baseline(idx); ok && owd-base > int64(10*time.Second) {
			o.buckets = [owdBuckets]owdBucket{} // the peer restarted (new clock origin)
		}
	}
	b := &o.buckets[idx%owdBuckets]
	if !b.ok || b.idx != idx {
		*b = owdBucket{idx: idx, min: owd, ok: true}
	} else if owd < b.min {
		b.min = owd
	}
	o.have = true
	base, _ := o.baseline(idx)
	return time.Duration(owd - base)
}

func (o *OWDTracker) baseline(idx int64) (int64, bool) {
	var base int64
	found := false
	for _, b := range o.buckets {
		if !b.ok || idx-b.idx >= owdBuckets {
			continue // older than the window
		}
		if !found || b.min < base {
			base, found = b.min, true
		}
	}
	return base, found
}

// OnQueueDelay updates the path's congestion from the one-way queueing delay
// the peer measured on the direction this side sends on. From then on RTT no
// longer drives congestion for this path.
func (p *PathStats) OnQueueDelay(q time.Duration) {
	const k = 20 * time.Millisecond
	target := float64(QueueAllowance+k) / float64(q+k)
	if target > 1 {
		target = 1
	}
	if target < minCongestion {
		target = minCongestion
	}
	p.mu.Lock()
	p.owdMode = true
	p.congestion += (target - p.congestion) / 4
	p.mu.Unlock()
}
