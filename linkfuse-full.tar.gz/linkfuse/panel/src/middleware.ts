// Password protection for the whole panel (pages and API routes).
// Set PANEL_USER / PANEL_PASSWORD in /etc/linkfuse/panel.env.
// If PANEL_PASSWORD is empty the panel stays open (not recommended).
import { NextRequest, NextResponse } from "next/server";

export function middleware(req: NextRequest) {
  const pass = process.env.PANEL_PASSWORD || "";
  if (!pass) return NextResponse.next();
  const user = process.env.PANEL_USER || "admin";

  const h = req.headers.get("authorization") || "";
  if (h.startsWith("Basic ")) {
    try {
      const [u, ...rest] = atob(h.slice(6)).split(":");
      if (u === user && rest.join(":") === pass) return NextResponse.next();
    } catch {
      /* bad header -> ask again */
    }
  }
  return new NextResponse("Authentication required", {
    status: 401,
    headers: { "WWW-Authenticate": 'Basic realm="LinkFuse"' },
  });
}

export const config = { matcher: "/:path*" };
