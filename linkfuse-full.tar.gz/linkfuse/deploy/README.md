# نشر LinkFuse — خطوة بخطوة

ثلاثة أجزاء: **خادم الدمج** على الـ VPS، **العقدة** على جهازك (مكان 103)، و**اللوحة**.
ملفات الإعداد في هذا المجلد مولّدة بـ PSK ورموز متطابقة جاهزة — غيّرها قبل الإنتاج الفعلي.

## 0) البناء (مرّة واحدة، على أي لينكس فيه Go 1.24+)

```bash
cd tunnel && go build -o lf-server ./cmd/lf-server && go build -o lf-client ./cmd/lf-client
cd ../node && go build -o lf-node ./cmd/lf-node
```

ثلاثة ملفات ثنائية: `lf-server` (للـ VPS)، `lf-node` (للعقدة). `lf-client` بديل يدوي
بلا إدارة namespaces (للاختبار).

---

## 1) خادم الدمج على الـ VPS (Vultr فرانكفورت)

```bash
scp tunnel/lf-server root@140.82.39.22:/usr/local/bin/
ssh root@140.82.39.22
mkdir -p /etc/linkfuse && nano /etc/linkfuse/server.json   # الصق deploy/server.json
bash vps-setup.sh eth0 51820        # eth0 = واجهة خروج الـ VPS
cp deploy/lf-server.service /etc/systemd/system/
systemctl enable --now lf-server
journalctl -u lf-server -f
```

تأكّد أن منفذ UDP 51820 مفتوح في جدار Vultr السحابي أيضاً.

> **حصة البيانات:** كل الحركة تمرّ عبر الـ VPS مرّتين. راقب العدّاد في اللوحة،
> وارفع `QUOTA_GB` إلى حصّة خطتك. 90Mbps متواصلة ≈ 1TB يومياً تقريباً.

---

## 2) العقدة المحلية (مكان 103)

تحتاج: صلاحية root، موديول `tun`، وعميل DHCP (`udhcpc` أو `dhclient`).

```bash
apt install -y udhcpc            # أو isc-dhcp-client
modprobe tun
scp node/lf-node root@NODE:/usr/local/bin/
mkdir -p /etc/linkfuse && nano /etc/linkfuse/node.json   # الصق deploy/node.json المعدّل
```

في `node.json` اضبط:
- `server`: IP الـ VPS.
- `parent_iface`: واجهة خط المزوّد (من تحليل 103 كانت `ens19` على VLAN 1111).
- `login.login_url`: صفحة دخول مزوّدك (`http://10.3.0.1/login` كما في Octopus).
- `cards`: رقم ويوزر وباسورد كل كرت.

```bash
cp deploy/lf-node.service /etc/systemd/system/
systemctl enable --now lf-node
journalctl -u lf-node -f        # تابع تهيئة الكروت وتسجيل دخولها
bash deploy/node-setup.sh ens20 172.18.0.0/24   # توجيه شبكتك الداخلية داخل النفق
```

كل كرت يصبح namespace مستقلاً (`lfcard-N`) بهوية هاتف وهمية ثابتة، يسجّل الدخول،
ثم ينضمّ للنفق. الكروت الفاشلة تُتخطّى ويُكمَل بالباقي.

---

## 3) اللوحة (Next.js)

```bash
scp -r panel root@NODE:/opt/linkfuse-panel
ssh root@NODE
cd /opt/linkfuse-panel && npm ci && npm run build
cp /root/panel.env /etc/linkfuse/panel.env   # NODE_TOKEN/VPS_TOKEN مطابقة
cp deploy/lf-panel.service /etc/systemd/system/
systemctl enable --now lf-panel
```

افتح `http://NODE_IP:3000`. اللوحة تعرض السرعة المدموجة اللحظية، كل كرت وسرعته
وتأخيره وموثوقيته وحصّته، عدّاد حصة الـ VPS مع تنبيه، وإضافة/إزالة كرت أثناء التشغيل.

> اللوحة تتصل بالعقدة على `127.0.0.1:8088` (نفس الجهاز). إن شغّلتها على جهاز آخر،
> غيّر `NODE_API` وافتح منفذ 8088، ويُفضّل خلف Nginx مع SSL.

---

## التحقق السريع

- **النفق قائم؟** على الخادم: `journalctl -u lf-server` يُظهر "مسار جديد #N ظهر".
- **السرعة تُدمج؟** نزّل ملفاً كبيراً من داخل شبكتك وراقب "التحميل الآن" في اللوحة
  يتجاوز سرعة كرت واحد.
- **كرت سقط؟** افصل كرتاً؛ خلال ثوانٍ تتحوّل حالته إلى "ساقط" وتُعاد الحصة توزيعها،
  دون انقطاع التصفّح.
