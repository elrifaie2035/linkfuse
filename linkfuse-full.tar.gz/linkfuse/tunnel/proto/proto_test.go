package proto

import (
	"bytes"
	"testing"
	"time"
)

func TestCodecRoundTrip(t *testing.T) {
	c, err := NewCodec("test-key-at-least-16-chars")
	if err != nil {
		t.Fatal(err)
	}
	payload := []byte("hello bonded internet عربي")
	h := Header{Type: TypeData, PathID: 7, Seq: 123456, TS: time.Now().UnixNano()}
	sealed, err := c.Seal(nil, h, payload)
	if err != nil {
		t.Fatal(err)
	}
	if len(sealed) != Overhead+len(payload) {
		t.Fatalf("حجم غير متوقّع: %d", len(sealed))
	}
	scratch := make([]byte, 2048)
	gotH, gotP, err := c.Open(scratch, sealed)
	if err != nil {
		t.Fatal(err)
	}
	if gotH.PathID != 7 || gotH.Seq != 123456 || gotH.Type != TypeData {
		t.Fatalf("ترويسة خاطئة: %+v", gotH)
	}
	if !bytes.Equal(gotP, payload) {
		t.Fatalf("حمولة خاطئة: %q", gotP)
	}
}

func TestCodecRejectsTamper(t *testing.T) {
	c, _ := NewCodec("test-key-at-least-16-chars")
	sealed, _ := c.Seal(nil, Header{Type: TypeData, Seq: 1}, []byte("data"))
	sealed[len(sealed)-1] ^= 0xFF // عبث بالـ tag
	if _, _, err := c.Open(make([]byte, 2048), sealed); err != ErrAuthFailed {
		t.Fatalf("كان يجب رفض الحزمة المعبوث بها، بدل: %v", err)
	}
}

func TestCodecWrongKey(t *testing.T) {
	a, _ := NewCodec("key-aaaaaaaaaaaaaaaa")
	b, _ := NewCodec("key-bbbbbbbbbbbbbbbb")
	sealed, _ := a.Seal(nil, Header{Type: TypeData}, []byte("secret"))
	if _, _, err := b.Open(make([]byte, 2048), sealed); err == nil {
		t.Fatal("مفتاح مختلف يجب أن يفشل الفك")
	}
}

// يجمع ما يُسلَّم من مخزن إعادة الترتيب بالترتيب.
func collect(delivered *[]uint64) func([]byte) {
	return func(p []byte) {
		var v uint64
		for _, b := range p {
			v = v<<8 | uint64(b)
		}
		*delivered = append(*delivered, v)
	}
}

func seqBytes(v uint64) []byte {
	return []byte{byte(v >> 56), byte(v >> 48), byte(v >> 40), byte(v >> 32),
		byte(v >> 24), byte(v >> 16), byte(v >> 8), byte(v)}
}

func TestReorderInOrder(t *testing.T) {
	var got []uint64
	r := NewReorderBuffer(40*time.Millisecond, 1024, collect(&got))
	now := time.Now()
	for i := uint64(0); i < 10; i++ {
		r.Push(i, seqBytes(i), now)
	}
	if len(got) != 10 {
		t.Fatalf("سُلّم %d بدل 10", len(got))
	}
	for i, v := range got {
		if v != uint64(i) {
			t.Fatalf("ترتيب خاطئ عند %d: %d", i, v)
		}
	}
}

func TestReorderOutOfOrder(t *testing.T) {
	var got []uint64
	r := NewReorderBuffer(40*time.Millisecond, 1024, collect(&got))
	now := time.Now()
	order := []uint64{0, 2, 1, 4, 3, 5} // مبعثرة لكن بلا فقدان
	for _, s := range order {
		r.Push(s, seqBytes(s), now)
	}
	want := []uint64{0, 1, 2, 3, 4, 5}
	if len(got) != len(want) {
		t.Fatalf("سُلّم %d بدل %d", len(got), len(want))
	}
	for i := range want {
		if got[i] != want[i] {
			t.Fatalf("أُعيد الترتيب خطأ: %v", got)
		}
	}
	if r.Reordered == 0 {
		t.Fatal("كان يجب احتساب إعادة ترتيب")
	}
}

func TestReorderLossTimeout(t *testing.T) {
	var got []uint64
	r := NewReorderBuffer(40*time.Millisecond, 1024, collect(&got))
	base := time.Now()
	r.Push(0, seqBytes(0), base)
	// الحزمة 1 ضائعة؛ تصل 2 و3 فتنتظران
	r.Push(2, seqBytes(2), base)
	r.Push(3, seqBytes(3), base)
	if len(got) != 1 {
		t.Fatalf("قبل المهلة يجب تسليم 0 فقط، سُلّم: %v", got)
	}
	// بعد تجاوز المهلة نُعلن 1 مفقودة ونُفرّغ 2 و3
	r.Tick(base.Add(50 * time.Millisecond))
	want := []uint64{0, 2, 3}
	if len(got) != 3 || got[1] != 2 || got[2] != 3 {
		t.Fatalf("بعد المهلة توقّعنا %v، حصلنا %v", want, got)
	}
	if r.Lost != 1 {
		t.Fatalf("توقّعنا فقدان 1، حصلنا %d", r.Lost)
	}
}

func TestReorderLateDropped(t *testing.T) {
	var got []uint64
	r := NewReorderBuffer(40*time.Millisecond, 1024, collect(&got))
	now := time.Now()
	r.Push(5, seqBytes(5), now) // يبدأ من 5
	r.Push(3, seqBytes(3), now) // أقدم من next → تُسقَط
	if r.Late != 1 {
		t.Fatalf("توقّعنا متأخرة 1، حصلنا %d", r.Late)
	}
	if len(got) != 1 || got[0] != 5 {
		t.Fatalf("توقّعنا [5]، حصلنا %v", got)
	}
}

func TestSchedulerProportional(t *testing.T) {
	s := NewScheduler()
	s.Upsert(1, 70, true) // كرت سريع
	s.Upsert(2, 20, true)
	s.Upsert(3, 10, true) // كرت بطيء
	counts := map[uint16]int{}
	for i := 0; i < 10000; i++ {
		id, ok := s.Pick()
		if !ok {
			t.Fatal("توقّعنا مساراً")
		}
		counts[id]++
	}
	// يجب أن تقترب النسب من 70/20/10 ضمن هامش.
	if counts[1] < 6800 || counts[1] > 7200 {
		t.Fatalf("الكرت 1 أخذ %d (المتوقّع ~7000)", counts[1])
	}
	if counts[3] < 800 || counts[3] > 1200 {
		t.Fatalf("الكرت 3 أخذ %d (المتوقّع ~1000)", counts[3])
	}
}

func TestSchedulerSkipsDownPaths(t *testing.T) {
	s := NewScheduler()
	s.Upsert(1, 50, true)
	s.Upsert(2, 50, false) // ساقط
	for i := 0; i < 100; i++ {
		id, ok := s.Pick()
		if !ok || id != 1 {
			t.Fatalf("كان يجب اختيار 1 فقط، حصلنا id=%d ok=%v", id, ok)
		}
	}
	s.SetUp(2, true)
	s.Upsert(1, 50, false) // أسقطنا 1
	for i := 0; i < 100; i++ {
		if id, ok := s.Pick(); !ok || id != 2 {
			t.Fatalf("بعد التبديل كان يجب اختيار 2، حصلنا id=%d ok=%v", id, ok)
		}
	}
}

func TestSchedulerAllDown(t *testing.T) {
	s := NewScheduler()
	s.Upsert(1, 50, false)
	if _, ok := s.Pick(); ok {
		t.Fatal("كل المسارات ساقطة — يجب ألّا يُختار شيء")
	}
}

func TestPathWeightPenalizesLossAndRTT(t *testing.T) {
	good := NewPathStats(2000)
	bad := NewPathStats(2000)
	// bad يعاني فقداناً وتأخيراً
	for i := 0; i < 20; i++ {
		good.OnRTT(10 * time.Millisecond)
		bad.OnKeepaliveLost()
		bad.OnRTT(300 * time.Millisecond)
	}
	if good.Weight() <= bad.Weight() {
		t.Fatalf("الكرت الجيّد (%d) يجب أن يفوق السيّئ (%d)", good.Weight(), bad.Weight())
	}
}
