// تنسيقات العرض.

export function fmtBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  const units = ["KB", "MB", "GB", "TB"];
  let v = n / 1024;
  let i = 0;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i++;
  }
  return `${v.toFixed(v < 10 ? 2 : 1)} ${units[i]}`;
}

// معدّل بالبت/ثانية مُنسّق (Kbps/Mbps).
export function fmtRate(bitsPerSec: number): string {
  if (bitsPerSec < 1000) return `${bitsPerSec.toFixed(0)} bps`;
  if (bitsPerSec < 1_000_000) return `${(bitsPerSec / 1000).toFixed(0)} Kbps`;
  return `${(bitsPerSec / 1_000_000).toFixed(1)} Mbps`;
}

export function fmtMs(ms: number): string {
  if (ms <= 0) return "—";
  return `${ms.toFixed(0)} ms`;
}

export function fmtUptime(sec: number): string {
  const d = Math.floor(sec / 86400);
  const h = Math.floor((sec % 86400) / 3600);
  const m = Math.floor((sec % 3600) / 60);
  if (d > 0) return `${d}ي ${h}س`;
  if (h > 0) return `${h}س ${m}د`;
  return `${m}د`;
}
