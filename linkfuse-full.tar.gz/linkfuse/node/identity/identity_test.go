package identity

import (
	"net"
	"testing"
)

func TestGenerateValidMAC(t *testing.T) {
	for i := 0; i < 100; i++ {
		id := Generate()
		if _, err := net.ParseMAC(id.MAC); err != nil {
			t.Fatalf("MAC غير صالح %q: %v", id.MAC, err)
		}
		if id.DeviceName == "" {
			t.Fatal("اسم الجهاز فارغ")
		}
	}
}

func TestGenerateForDeterministic(t *testing.T) {
	a := GenerateFor(42)
	b := GenerateFor(42)
	if a != b {
		t.Fatalf("نفس البذرة يجب أن تُعطي نفس الهوية: %+v vs %+v", a, b)
	}
	if GenerateFor(1) == GenerateFor(2) {
		t.Fatal("بذور مختلفة يجب أن تُعطي هويات مختلفة")
	}
	if _, err := net.ParseMAC(a.MAC); err != nil {
		t.Fatalf("MAC غير صالح: %v", err)
	}
}

func TestOUIMatchesVendorModel(t *testing.T) {
	// الموديل يجب أن يكون من موديلات نفس الشركة صاحبة الـ OUI.
	for seed := uint64(0); seed < 50; seed++ {
		id := GenerateFor(seed)
		hw, err := net.ParseMAC(id.MAC)
		if err != nil {
			t.Fatalf("MAC غير صالح: %v", err)
		}
		if len(hw) != 6 {
			t.Fatalf("طول MAC خاطئ")
		}
	}
}

func TestRouterIdentity(t *testing.T) {
	a, b := GenerateRouterFor(1001), GenerateRouterFor(1001)
	if a != b {
		t.Fatal("router identity must be stable for the same line")
	}
	if a.DeviceName == "" || len(a.MAC) != 17 {
		t.Fatalf("bad identity %+v", a)
	}
	if GenerateRouterFor(1001).MAC == GenerateRouterFor(1002).MAC {
		t.Fatal("different lines need different MACs")
	}
}

func TestDHCPHostName(t *testing.T) {
	cases := map[string]string{
		"Omar iPhone 14 Pro Max": "Omars-iPhone",
		"Khaled iPad Air":        "Khaleds-iPad",
		"Nawaf Galaxy S23":       "Galaxy-S23",
		"Saeed Redmi Note 12":    "Redmi-Note-12",
	}
	for name, want := range cases {
		if got := (Identity{DeviceName: name}).DHCPHostName(); got != want {
			t.Errorf("%q -> %q, want %q", name, got, want)
		}
	}
	if (Identity{DeviceName: "Omar iPhone 12"}).IsAndroid() || !(Identity{DeviceName: "Omar Galaxy S23"}).IsAndroid() {
		t.Error("IsAndroid wrong")
	}
	// variety across 50 cards
	seen := map[string]bool{}
	for i := uint64(1); i <= 50; i++ {
		seen[GenerateFor(i).DHCPHostName()] = true
	}
	t.Logf("%d different host names over 50 cards", len(seen))
	if len(seen) < 15 {
		t.Errorf("too little variety: %d", len(seen))
	}
}
