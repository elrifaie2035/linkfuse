/** @type {import('next').NextConfig} */
// "standalone" bundles the server with only the files it needs, so the node
// runs it with plain `node server.js` (no npm install on the node).
const nextConfig = { reactStrictMode: true, output: "standalone" };
export default nextConfig;
