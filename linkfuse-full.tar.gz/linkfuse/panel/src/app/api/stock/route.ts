import { nodeFetch } from "@/lib/api";
export const dynamic = "force-dynamic";
export async function GET() {
  try {
    const r = await nodeFetch("/api/stock");
    return new Response(await r.text(), { status: r.status, headers: { "Content-Type": "application/json" } });
  } catch (e: any) {
    return Response.json({ error: `تعذّر الوصول للعقدة: ${e.message}` }, { status: 502 });
  }
}
export async function DELETE(req: Request) {
  const status = new URL(req.url).searchParams.get("status") || "";
  const r = await nodeFetch(`/api/stock?status=${encodeURIComponent(status)}`, { method: "DELETE" });
  return new Response(await r.text(), { status: r.status, headers: { "Content-Type": "application/json" } });
}
