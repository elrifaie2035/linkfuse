// Package hotspot يسجّل دخول كرت على صفحة هوتسبوت المزوّد من داخل namespace الكرت.
// يدعم آلية MikroTik القياسية: حقول مخفية (dst/popup)، وتحدّي CHAP بـ MD5 حين
// يكون مفعّلاً، وPAP (كلمة مرور صريحة) حين لا يكون. القوالب قابلة للتعديل لأي مزوّد.
package hotspot

import (
	"context"
	"crypto/md5"
	"encoding/hex"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"regexp"
	"strings"
	"time"

	"github.com/linkfuse/node/netns"
)

// Config إعداد صفحة الدخول (قالب المزوّد).
type Config struct {
	LoginURL      string            // "http://10.3.0.1/login"
	TestURL       string            // رابط للتحقّق من نجاح الدخول (افتراضي http://10.3.0.1)
	UsernameField string            // اسم حقل المستخدم (افتراضي "username")
	PasswordField string            // اسم حقل كلمة المرور (افتراضي "password")
	Extra         map[string]string // حقول ثابتة إضافية يفرضها المزوّد
	Timeout       time.Duration     // مهلة كل طلب (افتراضي 10s)
	Retries       int               // عدد المحاولات (افتراضي 3)
	RetryWait     time.Duration     // الانتظار بين المحاولات (افتراضي 2s)
}

func (c *Config) defaults() {
	if c.UsernameField == "" {
		c.UsernameField = "username"
	}
	if c.PasswordField == "" {
		c.PasswordField = "password"
	}
	if c.TestURL == "" {
		if u, err := url.Parse(c.LoginURL); err == nil {
			c.TestURL = u.Scheme + "://" + u.Host
		}
	}
	if c.Timeout == 0 {
		c.Timeout = 10 * time.Second
	}
	if c.Retries == 0 {
		c.Retries = 3
	}
	if c.RetryWait == 0 {
		c.RetryWait = 2 * time.Second
	}
}

// newClient يبني عميل HTTP كل اتصالاته تُفتح داخل namespace الكرت.
func newClient(nsPath string, timeout time.Duration) *http.Client {
	dial := func(ctx context.Context, network, addr string) (net.Conn, error) {
		var conn net.Conn
		err := netns.Do(nsPath, func() error {
			d := net.Dialer{Timeout: timeout}
			c, e := d.Dial(network, addr)
			conn = c
			return e
		})
		return conn, err
	}
	return &http.Client{
		Timeout:   timeout,
		Transport: &http.Transport{DialContext: dial, DisableKeepAlives: true},
		// لا نتبع إعادة التوجيه تلقائياً كي نقرأ صفحة الدخول كما هي.
		CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse },
	}
}

var reHidden = regexp.MustCompile(`(?is)<input[^>]*type=["']?hidden["']?[^>]*>`)
var reName = regexp.MustCompile(`(?is)name=["']?([^"'\s>]+)`)
var reValue = regexp.MustCompile(`(?is)value=["']?([^"'>]*)`)
var reAction = regexp.MustCompile(`(?is)<form[^>]*action=["']?([^"'\s>]+)`)
var reLoggedIn = regexp.MustCompile(`(?is)(logged in|status|logout|bytes|uptime)`)

// Login يسجّل دخول الكرت ويُعيد الهوية المستخدَمة. يعيد المحاولة عند الفشل العابر.
func Login(nsPath string, cfg Config, username, password string) error {
	cfg.defaults()
	var lastErr error
	for attempt := 1; attempt <= cfg.Retries; attempt++ {
		if err := loginOnce(nsPath, cfg, username, password); err != nil {
			lastErr = err
			time.Sleep(cfg.RetryWait)
			continue
		}
		return nil
	}
	return fmt.Errorf("login failed after %d attempts: %w", cfg.Retries, lastErr)
}

func loginOnce(nsPath string, cfg Config, username, password string) error {
	client := newClient(nsPath, cfg.Timeout)

	// 1) نجلب صفحة الدخول.
	body, finalURL, err := get(client, cfg.LoginURL)
	if err != nil {
		return fmt.Errorf("fetch login page: %w", err)
	}
	// إن كنّا داخلين أصلاً فالصفحة صفحة حالة.
	if reLoggedIn.MatchString(body) && !strings.Contains(strings.ToLower(body), "password") {
		return nil
	}

	// 2) نقرأ الحقول المخفية (dst, popup, chap-id, chap-challenge…).
	hidden := parseHidden(body)
	form := url.Values{}
	for k, v := range hidden {
		form.Set(k, v)
	}
	for k, v := range cfg.Extra {
		form.Set(k, v)
	}
	form.Set(cfg.UsernameField, username)

	// 3) CHAP أم PAP؟
	if id, ok := hidden["chap-id"]; ok {
		if ch, ok2 := hidden["chap-challenge"]; ok2 {
			form.Set(cfg.PasswordField, chapResponse(id, password, ch))
		} else {
			form.Set(cfg.PasswordField, password)
		}
	} else {
		form.Set(cfg.PasswordField, password)
	}

	// 4) وجهة الإرسال: نفضّل رابط الدخول المُعدّ (IP مباشر) على action النموذج،
	// لأن action غالباً اسم نطاق (مثل h.ps) لا يُحلّ داخل namespace الكرت (لا DNS).
	action := cfg.LoginURL
	if m := reAction.FindStringSubmatch(body); m != nil {
		cand := resolveURL(finalURL, m[1])
		// نستخدم action النموذج فقط إن كان مضيفه عنوان IP (قابلاً للوصول بلا DNS).
		if u, err := url.Parse(cand); err == nil {
			host := u.Hostname()
			if net.ParseIP(host) != nil {
				action = cand
			}
		}
	}

	// 5) نرسل النموذج.
	if _, _, err := post(client, action, form); err != nil {
		return fmt.Errorf("submit form: %w", err)
	}

	// 6) التحقّق الحاسم: هل عبر الإنترنت فعلاً؟ (الإشارة الوحيدة الموثوقة).
	if internetReachable(client) {
		return nil
	}
	// احتياطي: ربما الوجهة الخارجية محجوبة لكن الدخول نجح — نفحص صفحة الحالة.
	if ok, _ := verify(client, cfg.TestURL); ok {
		return nil
	}
	return fmt.Errorf("login not confirmed (wrong password or expired card?)")
}

// internetReachable يتحقّق من عبور الإنترنت فعلياً بالوصول لعناوين IP خارجية
// (بلا DNS). أي ردّ HTTP (حتى redirect) يعني أن الإنترنت يعمل. نجرّب عدّة وجهات
// لأن المزوّد قد يحجب بعضها.
func internetReachable(c *http.Client) bool {
	targets := []string{
		"http://1.1.1.1",          // Cloudflare
		"http://8.8.8.8",          // Google DNS
		"http://208.67.222.222",   // OpenDNS
		"http://204.79.197.200",   // Microsoft
	}
	for _, t := range targets {
		resp, err := c.Get(t)
		if err == nil {
			resp.Body.Close()
			return true // أي ردّ = الإنترنت يعمل
		}
	}
	return false
}

// chapResponse = hex( MD5( chr(id) + password + hexDecode(challenge) ) ) — قياسي في MikroTik.
func chapResponse(idHex, password, challengeHex string) string {
	id := hexToBytes(idHex)
	ch := hexToBytes(challengeHex)
	h := md5.New()
	h.Write(id) // عادةً بايت واحد
	h.Write([]byte(password))
	h.Write(ch)
	return hex.EncodeToString(h.Sum(nil))
}

func hexToBytes(s string) []byte {
	s = strings.TrimPrefix(strings.TrimSpace(s), "0x")
	if len(s)%2 == 1 {
		s = "0" + s
	}
	b, err := hex.DecodeString(s)
	if err != nil {
		return []byte(s) // احتياطي: نعامله كنصّ
	}
	return b
}

func parseHidden(body string) map[string]string {
	out := map[string]string{}
	for _, tag := range reHidden.FindAllString(body, -1) {
		nm := reName.FindStringSubmatch(tag)
		if nm == nil {
			continue
		}
		val := ""
		if vm := reValue.FindStringSubmatch(tag); vm != nil {
			val = vm[1]
		}
		out[nm[1]] = val
	}
	return out
}

func get(c *http.Client, u string) (body, finalURL string, err error) {
	resp, err := c.Get(u)
	if err != nil {
		return "", u, err
	}
	defer resp.Body.Close()
	b, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	return string(b), u, nil
}

func post(c *http.Client, u string, form url.Values) (body string, status int, err error) {
	resp, err := c.PostForm(u, form)
	if err != nil {
		return "", 0, err
	}
	defer resp.Body.Close()
	b, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	return string(b), resp.StatusCode, nil
}

func verify(c *http.Client, testURL string) (bool, error) {
	resp, err := c.Get(testURL)
	if err != nil {
		return false, err
	}
	defer resp.Body.Close()
	b, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	s := string(b)
	// نجاح إن لم نُعَد إلى صفحة فيها حقل كلمة مرور.
	if strings.Contains(strings.ToLower(s), "password") && strings.Contains(strings.ToLower(s), "login") {
		return false, nil
	}
	return true, nil
}

func resolveURL(base, ref string) string {
	b, err := url.Parse(base)
	if err != nil {
		return ref
	}
	r, err := url.Parse(ref)
	if err != nil {
		return ref
	}
	return b.ResolveReference(r).String()
}
