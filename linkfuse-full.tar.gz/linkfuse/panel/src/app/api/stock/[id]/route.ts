import { nodeFetch } from "@/lib/api";
export const dynamic = "force-dynamic";
export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const r = await nodeFetch(`/api/stock/${id}`, { method: "DELETE" });
  return new Response(await r.text(), { status: r.status, headers: { "Content-Type": "application/json" } });
}
