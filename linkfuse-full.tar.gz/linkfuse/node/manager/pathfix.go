package manager

import (
	"log"

	"github.com/linkfuse/node/netns"
	"github.com/linkfuse/tunnel/client"
)

// A broadband line redials by itself (pppd "persist") when the provider drops
// the session, and gets a NEW address. The tunnel socket of that line was
// opened from the old address, so it stays dead although the line is online
// again (all 9 lines showed 0 bps on 2026-11-07 until lf-node restarted).
//
// Every watcher round the tunnel socket of a card is reopened when
//   - its PPPoE address changed, or
//   - it is online but its tunnel path has been dead for 2 rounds in a row.

func (m *Manager) refreshPaths(live []CardCfg) {
	if m.cl == nil {
		return
	}
	dead := map[uint16]bool{}
	for _, st := range m.cl.Stats() {
		if st.Weight <= 0 {
			dead[st.ID] = true
		}
	}
	for _, cc := range live {
		reason := ""
		if cc.isPPPoE() && m.pppoeIPFn != nil {
			ip := m.pppoeIPFn(cc.ID)
			m.healthMu.Lock()
			if m.lineIP == nil {
				m.lineIP = map[uint16]string{}
			}
			prev := m.lineIP[cc.ID]
			if ip != "" {
				m.lineIP[cc.ID] = ip
			}
			m.healthMu.Unlock()
			if ip != "" && prev != "" && ip != prev {
				reason = "line redialled, new address " + ip
			}
		}
		m.healthMu.Lock()
		if m.deadRounds == nil {
			m.deadRounds = map[uint16]int{}
		}
		if dead[cc.ID] && m.isHealthyLocked(cc.ID) {
			m.deadRounds[cc.ID]++
		} else {
			m.deadRounds[cc.ID] = 0
		}
		if reason == "" && m.deadRounds[cc.ID] >= 2 {
			reason = "online but its tunnel path is dead"
		}
		m.healthMu.Unlock()
		if reason == "" {
			continue
		}
		if err := m.reopenFn(cc); err != nil {
			log.Printf("[node] card #%d: %s; reopening the tunnel socket failed: %v", cc.ID, reason, err)
			continue
		}
		m.healthMu.Lock()
		m.deadRounds[cc.ID] = 0
		m.healthMu.Unlock()
		log.Printf("[node] card #%d: %s - tunnel socket reopened", cc.ID, reason)
	}
}

// reopenPath opens a fresh tunnel socket inside the card's namespace and
// replaces the path (AddPath swaps a path with the same ID).
func (m *Manager) reopenPath(cc CardCfg) error {
	conn, err := netns.DialUDP(netns.Path(nsCard(cc.ID).NS), m.cfg.Server)
	if err != nil {
		return err
	}
	m.cl.AddPath(client.PathConn{ID: cc.ID, Conn: conn, BaseKbps: cc.BaseKbps})
	return nil
}

func (m *Manager) isHealthyLocked(id uint16) bool {
	ok, seen := m.healthy[id]
	return ok && seen
}
