package integration

// اختبار تكامل حقيقي من طرف لطرف: عميل وخادم فعليان يتبادلان بايتات عبر سوكيتات
// UDP حقيقية على loopback، بثلاثة مسارات، مع تشفير وتوزيع وإعادة ترتيب حقيقية.
// لا يحتاج صلاحيات ولا أجهزة TUN لأننا نحقن جهاز TUN وهمياً في الذاكرة.
//
// مسار الاختبار: نحقن "حزم مستخدم" في TUN العميل → تمرّ عبر الكروت الثلاثة →
// يعيد الخادم ترتيبها ويكتبها على TUN الخادم (الذي يعكسها كأنها ردّ الإنترنت) →
// تعود موزّعةً إلى العميل → يعيد ترتيبها ويكتبها على TUN العميل → نتحقّق منها.

import (
	"encoding/binary"
	"net"
	"testing"
	"time"

	"github.com/linkfuse/tunnel/client"
	"github.com/linkfuse/tunnel/server"
)

// injectTUN: TUN العميل. Read يسحب ما نحقنه، Write يجمع ما يصل.
type injectTUN struct {
	in  chan []byte
	out chan []byte
}

func newInjectTUN() *injectTUN {
	return &injectTUN{in: make(chan []byte, 4096), out: make(chan []byte, 4096)}
}
func (t *injectTUN) Read(p []byte) (int, error) {
	pkt := <-t.in
	return copy(p, pkt), nil
}
func (t *injectTUN) Write(p []byte) (int, error) {
	cp := make([]byte, len(p))
	copy(cp, p)
	t.out <- cp
	return len(p), nil
}
func (t *injectTUN) Close() error { return nil }

// echoTUN: TUN الخادم. ما يكتبه الخادم (خارج للإنترنت) يُعاد فوراً كقراءة (ردّ الإنترنت).
type echoTUN struct {
	loop chan []byte
}

func newEchoTUN() *echoTUN { return &echoTUN{loop: make(chan []byte, 4096)} }
func (t *echoTUN) Read(p []byte) (int, error) {
	pkt := <-t.loop
	return copy(p, pkt), nil
}
func (t *echoTUN) Write(p []byte) (int, error) {
	cp := make([]byte, len(p))
	copy(cp, p)
	t.loop <- cp
	return len(p), nil
}
func (t *echoTUN) Close() error { return nil }

func TestEndToEndThreePaths(t *testing.T) {
	const psk = "integration-psk-abcdefghij"

	// === الخادم على منفذ loopback عشوائي ===
	sTUN := newEchoTUN()
	srv, err := server.NewWithTUN(server.Config{
		Listen: "127.0.0.1:0", TunName: "test", PSK: psk, BaseKbps: 2000,
		ReorderHold: 40 * time.Millisecond, ReorderCap: 4096,
		KeepaliveInt: 300 * time.Millisecond, PathTimeout: 3 * time.Second,
	}, sTUN)
	if err != nil {
		t.Fatal(err)
	}
	go srv.Run()
	serverAddr := srv.Addr()

	// === العميل بثلاثة مسارات (ثلاثة سوكيتات → ثلاثة منافذ مصدر مختلفة) ===
	raddr, _ := net.ResolveUDPAddr("udp", serverAddr)
	var pcs []client.PathConn
	for id := uint16(1); id <= 3; id++ {
		conn, err := net.DialUDP("udp", nil, raddr)
		if err != nil {
			t.Fatal(err)
		}
		_ = conn.SetReadBuffer(4 << 20)
		_ = conn.SetWriteBuffer(4 << 20)
		pcs = append(pcs, client.PathConn{ID: id, Conn: conn, BaseKbps: 2000})
	}
	cTUN := newInjectTUN()
	cl, err := client.NewWithTUN(client.Config{
		TunName: "test", PSK: psk,
		ReorderHold: 40 * time.Millisecond, ReorderCap: 4096,
		KeepaliveInt: 300 * time.Millisecond, PathTimeout: 3 * time.Second,
	}, cTUN, pcs)
	if err != nil {
		t.Fatal(err)
	}
	go cl.Run()

	// ننتظر قليلاً حتى تتعلّم المسارات وتُرسَل أول نبضات.
	time.Sleep(600 * time.Millisecond)

	// === نحقن حزماً مرقّمة ونقيس نسبة العودة وترتيبها ===
	// نهدّئ الحقن قليلاً كي لا يُسقط loopback دفعةً كبيرة (الشبكة الحقيقية
	// أبطأ من loopback، فهذا أقرب لواقعها). النفق لا يعيد الإرسال عمداً.
	const n = 1000
	go func() {
		for i := 0; i < n; i++ {
			pkt := make([]byte, 100)
			binary.BigEndian.PutUint32(pkt[0:4], uint32(i))
			for j := 4; j < 100; j++ {
				pkt[j] = byte(i + j)
			}
			cTUN.in <- pkt
			if i%20 == 19 {
				time.Sleep(time.Millisecond)
			}
		}
	}()

	received := make(map[uint32]bool)
	var lastSeen int64 = -1
	outOfOrder := 0
	deadline := time.After(15 * time.Second)
	quiet := time.NewTimer(2 * time.Second)
loop:
	for {
		select {
		case pkt := <-cTUN.out:
			if len(pkt) >= 4 {
				id := binary.BigEndian.Uint32(pkt[0:4])
				received[id] = true
				if int64(id) < lastSeen {
					outOfOrder++ // تسليم خارج الترتيب (يجب أن يكون نادراً بفضل إعادة الترتيب)
				}
				lastSeen = int64(id)
			}
			quiet.Reset(2 * time.Second)
			if len(received) >= n {
				break loop
			}
		case <-quiet.C:
			break loop // توقّف الوصول — ننهي ونحكم بالنسبة
		case <-deadline:
			break loop
		}
	}

	// المعيار الصحيح لنفق دمج: تسليم عالٍ جداً (لا 100% لأن لا إعادة إرسال)،
	// وترتيب شبه تامّ، ومشاركة كل الكروت.
	delivered := len(received)
	if delivered < n*99/100 {
		t.Fatalf("تسليم منخفض: %d من %d (%.1f%%)", delivered, n, 100*float64(delivered)/float64(n))
	}
	if outOfOrder > n/100 {
		t.Fatalf("خروج عن الترتيب كثير: %d (إعادة الترتيب لا تعمل جيّداً)", outOfOrder)
	}
	t.Logf("سُلّم %d/%d (%.1f%%)، خارج الترتيب %d", delivered, n, 100*float64(delivered)/float64(n), outOfOrder)

	// نتحقّق أن الكروت الثلاثة كلها شاركت فعلاً في الحمل (دمج حقيقي لا كرت واحد).
	used := 0
	for _, st := range cl.Stats() {
		t.Logf("مسار #%d: RTT=%.1fms موثوقية=%.2f وزن=%d أرسل=%dB استقبل=%dB",
			st.ID, st.SRTTms, st.Reliability, st.Weight, st.TxBytes, st.RxBytes)
		if st.TxBytes > 0 {
			used++
		}
	}
	if used < 3 {
		t.Fatalf("توقّعنا مشاركة الكروت الثلاثة، شارك %d فقط", used)
	}
}

// يثبت إضافة وإزالة كرت أثناء عمل النفق (المتطلّب الصريح: تقليل/زيادة الكروت حيّاً).
func TestDynamicAddRemovePaths(t *testing.T) {
	const psk = "integration-psk-abcdefghij"

	sTUN := newEchoTUN()
	srv, err := server.NewWithTUN(server.Config{
		Listen: "127.0.0.1:0", TunName: "test", PSK: psk, BaseKbps: 2000,
		ReorderHold: 40 * time.Millisecond, ReorderCap: 4096,
		KeepaliveInt: 300 * time.Millisecond, PathTimeout: 3 * time.Second,
	}, sTUN)
	if err != nil {
		t.Fatal(err)
	}
	go srv.Run()
	raddr, _ := net.ResolveUDPAddr("udp", srv.Addr())

	dial := func() *net.UDPConn {
		c, e := net.DialUDP("udp", nil, raddr)
		if e != nil {
			t.Fatal(e)
		}
		_ = c.SetReadBuffer(4 << 20)
		_ = c.SetWriteBuffer(4 << 20)
		return c
	}

	// نبدأ بكرت واحد.
	cTUN := newInjectTUN()
	cl, err := client.NewWithTUN(client.Config{
		TunName: "test", PSK: psk,
		ReorderHold: 40 * time.Millisecond, ReorderCap: 4096,
		KeepaliveInt: 300 * time.Millisecond, PathTimeout: 3 * time.Second,
	}, cTUN, []client.PathConn{{ID: 1, Conn: dial(), BaseKbps: 2000}})
	if err != nil {
		t.Fatal(err)
	}
	go cl.Run()
	time.Sleep(300 * time.Millisecond)

	if cl.PathCount() != 1 {
		t.Fatalf("توقّعنا كرتاً واحداً، حصلنا %d", cl.PathCount())
	}

	// نضيف كرتين أثناء التشغيل.
	cl.AddPath(client.PathConn{ID: 2, Conn: dial(), BaseKbps: 2000})
	cl.AddPath(client.PathConn{ID: 3, Conn: dial(), BaseKbps: 2000})
	time.Sleep(300 * time.Millisecond)
	if cl.PathCount() != 3 {
		t.Fatalf("بعد الإضافة توقّعنا 3 كروت، حصلنا %d", cl.PathCount())
	}

	// حركة: يجب أن تمرّ والكروت الثلاثة تعمل.
	runTraffic := func(n int) int {
		go func() {
			for i := 0; i < n; i++ {
				pkt := make([]byte, 80)
				binary.BigEndian.PutUint32(pkt, uint32(i))
				cTUN.in <- pkt
				if i%20 == 19 {
					time.Sleep(time.Millisecond)
				}
			}
		}()
		got := map[uint32]bool{}
		quiet := time.NewTimer(2 * time.Second)
		for {
			select {
			case p := <-cTUN.out:
				if len(p) >= 4 {
					got[binary.BigEndian.Uint32(p)] = true
				}
				quiet.Reset(1500 * time.Millisecond)
				if len(got) >= n {
					return len(got)
				}
			case <-quiet.C:
				return len(got)
			}
		}
	}

	if d := runTraffic(300); d < 297 {
		t.Fatalf("بعد الإضافة: تسليم ضعيف %d/300", d)
	}

	// نزيل كرتاً — يجب أن تستمر الحركة على الكرتين الباقيين.
	cl.RemovePath(2)
	time.Sleep(200 * time.Millisecond)
	if cl.PathCount() != 2 {
		t.Fatalf("بعد الإزالة توقّعنا كرتين، حصلنا %d", cl.PathCount())
	}
	if d := runTraffic(300); d < 297 {
		t.Fatalf("بعد الإزالة: تسليم ضعيف %d/300", d)
	}
	t.Log("إضافة وإزالة الكروت أثناء التشغيل تعمل، والحركة مستمرّة")
}
