// Package manager يدير دورة حياة الكروت فوق عميل النفق: يهيّئ الكرت (namespace +
// هوية وهمية + DHCP + دخول هوتسبوت + سوكيت)، ويضيفه/يزيله حيّاً، ويجمع الإحصاءات،
// ويحفظ قائمة الكروت في ملف الإعداد. تستهلكه واجهة API وبرنامج lf-node.
package manager

import (
	"encoding/json"
	"fmt"
	"log"
	"os"
	"strconv"
	"sync"
	"time"

	"github.com/linkfuse/node/hotspot"
	"github.com/linkfuse/node/identity"
	"github.com/linkfuse/node/netns"
	"github.com/linkfuse/tunnel/client"
)

// CardCfg إعداد كرت كما يُحفَظ في ملف الإعداد.
type CardCfg struct {
	ID       uint16 `json:"id"`
	Username string `json:"username"`
	Password string `json:"password"`
	BaseKbps int    `json:"base_kbps"`
}

// LoginCfg قالب صفحة دخول المزوّد.
type LoginCfg struct {
	LoginURL      string            `json:"login_url"`
	TestURL       string            `json:"test_url"`
	UsernameField string            `json:"username_field"`
	PasswordField string            `json:"password_field"`
	Extra         map[string]string `json:"extra"`
}

// NodeConfig كامل إعداد العقدة.
type NodeConfig struct {
	Server       string    `json:"server"`
	PSK          string    `json:"psk"`
	TunName      string    `json:"tun"`
	TunAddr      string    `json:"tun_addr"`
	MTU          int       `json:"mtu"`
	ParentIface  string    `json:"parent_iface"`
	LANIface     string    `json:"lan_iface"`  // e.g. "ens20": users' network routed into the tunnel
	LANSubnet    string    `json:"lan_subnet"` // e.g. "172.18.0.0/24"; empty = no LAN routing
	ReorderHold  int       `json:"reorder_hold_ms"`
	ReorderCap   int       `json:"reorder_cap"`
	KeepaliveInt int       `json:"keepalive_ms"`
	PathTimeout  int       `json:"path_timeout_ms"`
	DHCPRetries  int       `json:"dhcp_retries"`
	APIListen    string    `json:"api_listen"` // ":8088"
	APIToken     string    `json:"api_token"`
	Login        LoginCfg  `json:"login"`
	Cards        []CardCfg `json:"cards"`
}

// cardState حالة كرت في الذاكرة (الإعداد + الهوية).
type cardState struct {
	cfg    CardCfg
	device string // اسم الجهاز الوهمي
	mac    string
}

// Manager المدير.
type Manager struct {
	mu      sync.Mutex
	cfg     *NodeConfig
	cfgPath string
	cl      *client.Client
	cards   map[uint16]*cardState
}

// New ينشئ مديراً من إعداد محمّل.
func New(cfg *NodeConfig, cfgPath string) *Manager {
	return &Manager{cfg: cfg, cfgPath: cfgPath, cards: map[uint16]*cardState{}}
}

func (m *Manager) loginCfg() hotspot.Config {
	return hotspot.Config{
		LoginURL: m.cfg.Login.LoginURL, TestURL: m.cfg.Login.TestURL,
		UsernameField: m.cfg.Login.UsernameField, PasswordField: m.cfg.Login.PasswordField,
		Extra: m.cfg.Login.Extra,
	}
}

// bringUp يهيّئ كرتاً كاملاً ويُعيد مساره الجاهز للنفق وهويته.
func (m *Manager) bringUp(cc CardCfg) (client.PathConn, identity.Identity, error) {
	id := identity.GenerateFor(uint64(cc.ID))
	card := netns.Card{
		NS:     "lfcard-" + strconv.Itoa(int(cc.ID)),
		Parent: m.cfg.ParentIface,
		MVName: "lfm" + strconv.Itoa(int(cc.ID)),
		MAC:    id.MAC,
	}
	card.Teardown()
	log.Printf("[node] card #%d: identity %q (%s)", cc.ID, id.DeviceName, id.MAC)
	if err := card.Setup(); err != nil {
		return client.PathConn{}, id, fmt.Errorf("namespace: %w", err)
	}
	if err := card.DHCP(m.cfg.DHCPRetries, 3*time.Second); err != nil {
		card.Teardown()
		return client.PathConn{}, id, fmt.Errorf("dhcp: %w", err)
	}
	ip, _ := card.IPv4()
	log.Printf("[node] card #%d: got IP %s, logging in...", cc.ID, ip)
	if err := hotspot.Login(netns.Path(card.NS), m.loginCfg(), cc.Username, cc.Password); err != nil {
		card.Teardown()
		return client.PathConn{}, id, fmt.Errorf("hotspot login: %w", err)
	}
	conn, err := netns.DialUDP(netns.Path(card.NS), m.cfg.Server)
	if err != nil {
		card.Teardown()
		return client.PathConn{}, id, fmt.Errorf("tunnel socket: %w", err)
	}
	log.Printf("[node] card #%d: ready", cc.ID)
	return client.PathConn{ID: cc.ID, Conn: conn, BaseKbps: cc.BaseKbps}, id, nil
}

// BringUpInitial يهيّئ كروت الإعداد **بالتتابع** (واحداً تلو الآخر) ويُعيد
// المسارات الناجحة. التتابع ضروري لأن تشغيل عدّة DHCP معاً على نفس خط المزوّد
// يتعارض (أثبتته التجربة: بالتتابع ينجح، بالتوازي يفشل). concurrency يُتجاهَل.
func (m *Manager) BringUpInitial(concurrency int) []client.PathConn {
	var pcs []client.PathConn
	for _, cc := range m.cfg.Cards {
		pc, id, err := m.bringUp(cc)
		if err != nil {
			log.Printf("[node] card #%d FAILED: %v", cc.ID, err)
			continue
		}
		m.mu.Lock()
		m.cards[cc.ID] = &cardState{cfg: cc, device: id.DeviceName, mac: id.MAC}
		m.mu.Unlock()
		pcs = append(pcs, pc)
		time.Sleep(1500 * time.Millisecond) // فاصل بسيط بين الكروت لتفادي تعارض DHCP
	}
	return pcs
}

// AttachClient يربط المدير بعميل النفق بعد إنشائه.
func (m *Manager) AttachClient(cl *client.Client) { m.cl = cl }

// Add يضيف كرتاً جديداً أثناء التشغيل.
func (m *Manager) Add(cc CardCfg) error {
	m.mu.Lock()
	if _, exists := m.cards[cc.ID]; exists {
		m.mu.Unlock()
		return fmt.Errorf("card #%d already exists", cc.ID)
	}
	m.mu.Unlock()

	pc, id, err := m.bringUp(cc)
	if err != nil {
		return err
	}
	m.cl.AddPath(pc)
	m.mu.Lock()
	m.cards[cc.ID] = &cardState{cfg: cc, device: id.DeviceName, mac: id.MAC}
	replaced := false
	for i := range m.cfg.Cards {
		if m.cfg.Cards[i].ID == cc.ID { // card already in config (e.g. failed at startup): update, don't duplicate
			m.cfg.Cards[i] = cc
			replaced = true
		}
	}
	if !replaced {
		m.cfg.Cards = append(m.cfg.Cards, cc)
	}
	m.mu.Unlock()
	m.persist()
	return nil
}

// Remove يزيل كرتاً أثناء التشغيل.
func (m *Manager) Remove(id uint16) error {
	m.mu.Lock()
	if _, ok := m.cards[id]; !ok {
		m.mu.Unlock()
		return fmt.Errorf("card #%d not found", id)
	}
	delete(m.cards, id)
	out := m.cfg.Cards[:0]
	for _, c := range m.cfg.Cards {
		if c.ID != id {
			out = append(out, c)
		}
	}
	m.cfg.Cards = out
	m.mu.Unlock()

	m.cl.RemovePath(id)
	netns.Card{NS: "lfcard-" + strconv.Itoa(int(id))}.Teardown()
	m.persist()
	return nil
}

// CardStat سطر إحصاء كرت للّوحة.
type CardStat struct {
	ID          uint16  `json:"id"`
	Device      string  `json:"device"`
	MAC         string  `json:"mac"`
	Username    string  `json:"username"`
	SRTTms      float64 `json:"srtt_ms"`
	Reliability float64 `json:"reliability"`
	Weight      int     `json:"weight"`
	TxBytes     uint64  `json:"tx_bytes"`
	RxBytes     uint64  `json:"rx_bytes"`
	Up          bool    `json:"up"`
}

// Snapshot الحالة الكاملة للّوحة.
type Snapshot struct {
	Cards      []CardStat `json:"cards"`
	TotalTx    uint64     `json:"total_tx"`
	TotalRx    uint64     `json:"total_rx"`
	ActiveUp   int        `json:"active_up"`
	CardCount  int        `json:"card_count"`
	BondedKbps int        `json:"bonded_kbps"` // مجموع سعة الكروت الحيّة
}

// Snapshot يجمع إحصاءات النفق مع هويات الكروت.
func (m *Manager) Snapshot() Snapshot {
	var snap Snapshot
	if m.cl == nil {
		return snap
	}
	stats := m.cl.Stats()
	m.mu.Lock()
	defer m.mu.Unlock()
	snap.TotalTx = m.cl.TxBytes.Load()
	snap.TotalRx = m.cl.RxBytes.Load()
	for _, st := range stats {
		cs := CardStat{
			ID: st.ID, SRTTms: st.SRTTms, Reliability: st.Reliability,
			Weight: st.Weight, TxBytes: st.TxBytes, RxBytes: st.RxBytes,
			Up: st.Weight > 0,
		}
		if info, ok := m.cards[st.ID]; ok {
			cs.Device = info.device
			cs.MAC = info.mac
			cs.Username = info.cfg.Username
			if cs.Up {
				snap.BondedKbps += info.cfg.BaseKbps
			}
		}
		if cs.Up {
			snap.ActiveUp++
		}
		snap.Cards = append(snap.Cards, cs)
	}
	snap.CardCount = len(m.cards)
	return snap
}

// Config يُعيد إعداد العقدة (للـ API: الخادم، منفذ الاستماع…).
func (m *Manager) Config() *NodeConfig { return m.cfg }

func (m *Manager) persist() {
	m.mu.Lock()
	b, err := json.MarshalIndent(m.cfg, "", "  ")
	m.mu.Unlock()
	if err != nil {
		return
	}
	tmp := m.cfgPath + ".tmp"
	if os.WriteFile(tmp, b, 0600) == nil {
		_ = os.Rename(tmp, m.cfgPath)
	}
}

// Load يقرأ إعداد العقدة من ملف.
func Load(path string) (*NodeConfig, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	cfg := &NodeConfig{
		TunName: "lf0", TunAddr: "10.9.0.2/24", MTU: 1400, ParentIface: "ens19",
		ReorderHold: 40, ReorderCap: 4096, KeepaliveInt: 1000, PathTimeout: 5000,
		DHCPRetries: 4, APIListen: ":8088",
	}
	if err := json.Unmarshal(b, cfg); err != nil {
		return nil, err
	}
	if cfg.PSK == "" || cfg.Server == "" || cfg.Login.LoginURL == "" {
		return nil, fmt.Errorf("psk, server and login.login_url are required")
	}
	return cfg, nil
}
