package proto

import "sync"

// Scheduler يوزّع الحزم الصادرة على المسارات (الكروت) توزيعاً نسبياً حسب وزن
// كل مسار، بخوارزمية Smooth Weighted Round Robin (نفس فكرة nginx upstream).
// الوزن يُحدَّث لحظياً من القياسات: المسار الأسرع والأقل فقداناً يأخذ حصة أكبر،
// والمسار الساقط يُستبعَد فوراً (up=false) دون أن يتوقّف التوزيع.
//
// آمن للتوازي: goroutine القراءة من TUN تستدعي Pick، وgoroutine القياس تستدعي
// Set/SetUp، فنحمي الحالة بقفل واحد خفيف.
type Scheduler struct {
	mu    sync.Mutex
	items []*schedItem
	index map[uint16]*schedItem
}

type schedItem struct {
	id     uint16
	weight int // الوزن الفعّال (≥0)؛ 0 أو up=false يعني لا تُرسل عليه
	cur    int // عدّاد SWRR الجاري
	up     bool
}

// NewScheduler ينشئ موزّعاً فارغاً.
func NewScheduler() *Scheduler {
	return &Scheduler{index: make(map[uint16]*schedItem)}
}

// Upsert يضيف مساراً أو يحدّث وزنه. الوزن المقترح = سعة الكرت المقدّرة
// مضروبة في (1 − نسبة الفقدان) ومعدّلة بعامل التأخير؛ يحسبه المتصل.
func (s *Scheduler) Upsert(id uint16, weight int, up bool) {
	if weight < 0 {
		weight = 0
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if it, ok := s.index[id]; ok {
		it.weight = weight
		it.up = up
		return
	}
	it := &schedItem{id: id, weight: weight, up: up}
	s.items = append(s.items, it)
	s.index[id] = it
}

// SetUp يعلّم مساراً حيّاً أو ساقطاً دون تغيير وزنه المخزّن.
func (s *Scheduler) SetUp(id uint16, up bool) {
	s.mu.Lock()
	if it, ok := s.index[id]; ok {
		it.up = up
	}
	s.mu.Unlock()
}

// Remove يحذف مساراً نهائياً (عند إزالة كرت من النظام).
func (s *Scheduler) Remove(id uint16) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if _, ok := s.index[id]; !ok {
		return
	}
	delete(s.index, id)
	out := s.items[:0]
	for _, it := range s.items {
		if it.id != id {
			out = append(out, it)
		}
	}
	s.items = out
}

// Pick يُعيد مُعرّف المسار الذي تُرسَل عليه الحزمة التالية.
// ok=false إذا لم يوجد أي مسار حيّ بوزن موجب (كل الكروت ساقطة).
func (s *Scheduler) Pick() (id uint16, ok bool) {
	s.mu.Lock()
	defer s.mu.Unlock()

	total := 0
	var best *schedItem
	for _, it := range s.items {
		if !it.up || it.weight <= 0 {
			continue
		}
		it.cur += it.weight
		total += it.weight
		if best == nil || it.cur > best.cur {
			best = it
		}
	}
	if best == nil {
		return 0, false
	}
	best.cur -= total
	return best.id, true
}

// Snapshot يُعيد نسخة من الأوزان الحالية (للعرض في اللوحة/السجلّ).
func (s *Scheduler) Snapshot() map[uint16]int {
	s.mu.Lock()
	defer s.mu.Unlock()
	m := make(map[uint16]int, len(s.items))
	for _, it := range s.items {
		if it.up {
			m[it.id] = it.weight
		} else {
			m[it.id] = 0
		}
	}
	return m
}
