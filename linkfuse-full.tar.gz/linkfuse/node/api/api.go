// Package api يقدّم واجهة HTTP للعقدة تستهلكها لوحة التحكم: إحصاءات حية،
// وإضافة/إزالة كرت. محميّة برمز (token) في ترويسة Authorization.
package api

import (
	"encoding/json"
	"log"
	"net/http"
	"strconv"
	"strings"

	"github.com/linkfuse/node/manager"
)

type Server struct {
	mgr   *manager.Manager
	token string
}

func New(mgr *manager.Manager, token string) *Server {
	return &Server{mgr: mgr, token: token}
}

func (s *Server) auth(r *http.Request) bool {
	if s.token == "" {
		return true // بلا رمز = مفتوح (للتجربة فقط)
	}
	h := r.Header.Get("Authorization")
	return h == "Bearer "+s.token
}

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}

// Handler يبني موجّه الطلبات.
func (s *Server) Handler() http.Handler {
	mux := http.NewServeMux()

	mux.HandleFunc("/api/stats", func(w http.ResponseWriter, r *http.Request) {
		if !s.auth(r) {
			writeJSON(w, 401, map[string]string{"error": "unauthorized"})
			return
		}
		writeJSON(w, 200, s.mgr.Snapshot())
	})

	mux.HandleFunc("/api/cards", func(w http.ResponseWriter, r *http.Request) {
		if !s.auth(r) {
			writeJSON(w, 401, map[string]string{"error": "unauthorized"})
			return
		}
		switch r.Method {
		case http.MethodGet:
			writeJSON(w, 200, s.mgr.Config().Cards)
		case http.MethodPost:
			var cc manager.CardCfg
			if err := json.NewDecoder(r.Body).Decode(&cc); err != nil {
				writeJSON(w, 400, map[string]string{"error": "json غير صالح"})
				return
			}
			if cc.BaseKbps == 0 {
				cc.BaseKbps = 2000
			}
			if err := s.mgr.Add(cc); err != nil {
				writeJSON(w, 400, map[string]string{"error": err.Error()})
				return
			}
			writeJSON(w, 201, map[string]any{"ok": true, "id": cc.ID})
		default:
			writeJSON(w, 405, map[string]string{"error": "method"})
		}
	})

	// DELETE /api/cards/{id}
	mux.HandleFunc("/api/cards/", func(w http.ResponseWriter, r *http.Request) {
		if !s.auth(r) {
			writeJSON(w, 401, map[string]string{"error": "unauthorized"})
			return
		}
		if r.Method != http.MethodDelete {
			writeJSON(w, 405, map[string]string{"error": "method"})
			return
		}
		idStr := strings.TrimPrefix(r.URL.Path, "/api/cards/")
		id, err := strconv.Atoi(idStr)
		if err != nil {
			writeJSON(w, 400, map[string]string{"error": "id غير صالح"})
			return
		}
		if err := s.mgr.Remove(uint16(id)); err != nil {
			writeJSON(w, 400, map[string]string{"error": err.Error()})
			return
		}
		writeJSON(w, 200, map[string]any{"ok": true})
	})

	return mux
}

// Run يشغّل خادم API (يحجز الـ goroutine المستدعية).
func (s *Server) Run(listen string) error {
	log.Printf("[api] node API on %s", listen)
	return http.ListenAndServe(listen, s.Handler())
}
