"use client";

import { useEffect, useRef, useState } from "react";
import { fmtBytes, fmtRate, fmtMs, fmtUptime } from "@/lib/format";

type Card = {
  id: number;
  device: string;
  mac: string;
  username: string;
  srtt_ms: number;
  reliability: number;
  weight: number;
  tx_bytes: number;
  rx_bytes: number;
  up: boolean;
  kind?: string;
  package?: string;
  expires_at?: string;
};
type Snapshot = {
  cards: Card[];
  total_tx: number;
  total_rx: number;
  active_up: number;
  card_count: number;
  bonded_kbps: number;
  error?: string;
};
type Usage = {
  total_bytes?: number;
  rx_bytes?: number;
  tx_bytes?: number;
  uptime_sec?: number;
  quota_gb?: number;
  error?: string;
};

const C = {
  bg: "var(--bg)", panel: "var(--panel)", panel2: "var(--panel2)", line: "var(--line)",
  text: "var(--text)", muted: "var(--muted)", accent: "var(--accent)",
  good: "var(--good)", warn: "var(--warn)", bad: "var(--bad)",
};

export default function Page() {
  const [snap, setSnap] = useState<Snapshot | null>(null);
  const [usage, setUsage] = useState<Usage | null>(null);
  const [rateDown, setRateDown] = useState(0);
  const [rateUp, setRateUp] = useState(0);
  const [perCardRate, setPerCardRate] = useState<Record<number, number>>({});
  const prev = useRef<{ t: number; rx: number; tx: number; card: Record<number, number> } | null>(null);

  async function poll() {
    try {
      const [s, u] = await Promise.all([
        fetch("/api/stats").then((r) => r.json()),
        fetch("/api/usage").then((r) => r.json()).catch(() => ({})),
      ]);
      setSnap(s);
      setUsage(u);
      const now = Date.now();
      if (prev.current && !s.error) {
        const dt = (now - prev.current.t) / 1000;
        if (dt > 0) {
          setRateDown(((s.total_rx - prev.current.rx) * 8) / dt);
          setRateUp(((s.total_tx - prev.current.tx) * 8) / dt);
          const pcr: Record<number, number> = {};
          for (const c of s.cards || []) {
            const p = prev.current.card[c.id] ?? c.rx_bytes;
            pcr[c.id] = Math.max(0, ((c.rx_bytes - p) * 8) / dt);
          }
          setPerCardRate(pcr);
        }
      }
      const cardMap: Record<number, number> = {};
      for (const c of s.cards || []) cardMap[c.id] = c.rx_bytes;
      prev.current = { t: now, rx: s.total_rx, tx: s.total_tx, card: cardMap };
    } catch {
      /* نتجاهل خطأ استطلاع عابر */
    }
  }

  useEffect(() => {
    poll();
    const h = setInterval(poll, 2000);
    return () => clearInterval(h);
  }, []);

  const totalWeight = (snap?.cards || []).reduce((a, c) => a + (c.up ? c.weight : 0), 0) || 1;

  return (
    <main style={{ maxWidth: 1100, margin: "0 auto", padding: 20 }}>
      <Header snap={snap} rateDown={rateDown} rateUp={rateUp} />
      {snap?.error && <ErrorBox msg={snap.error} />}
      <QuotaMeter usage={usage} />
      <StockPanel />
      <DirectSites />
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "flex-start" }}>
        <AddCard onDone={poll} />
        <BulkAdd onDone={poll} />
      </div>
      <CardTable
        cards={snap?.cards || []}
        totalWeight={totalWeight}
        perCardRate={perCardRate}
        onRemove={async (id) => {
          if (!confirm(`إزالة الكرت #${id}؟`)) return;
          await fetch(`/api/cards/${id}`, { method: "DELETE" });
          poll();
        }}
      />
      <p style={{ color: C.muted, fontSize: 12, marginTop: 24, textAlign: "center" }}>
        LinkFuse — تحديث كل ثانيتين · الكروت تُدار أثناء التشغيل
      </p>
    </main>
  );
}

function Header({ snap, rateDown, rateUp }: { snap: Snapshot | null; rateDown: number; rateUp: number }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <h1 style={{ fontSize: 22, margin: "4px 0 16px", fontWeight: 700 }}>
        لوحة دمج الكروت
      </h1>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(160px,1fr))", gap: 12 }}>
        <Stat label="التحميل الآن (مدموج)" value={fmtRate(rateDown)} color={C.good} big />
        <Stat label="الرفع الآن" value={fmtRate(rateUp)} color={C.accent} />
        <Stat label="كروت تعمل" value={`${snap?.active_up ?? 0} / ${snap?.card_count ?? 0}`} />
        <Stat label="السعة الاسمية المدموجة" value={`${(((snap?.bonded_kbps ?? 0) / 1000)).toFixed(0)} Mbps`} />
      </div>
    </div>
  );
}

function Stat({ label, value, color, big }: { label: string; value: string; color?: string; big?: boolean }) {
  return (
    <div style={{ background: C.panel, border: `1px solid ${C.line}`, borderRadius: 12, padding: "12px 14px" }}>
      <div style={{ color: C.muted, fontSize: 12, marginBottom: 6 }}>{label}</div>
      <div style={{ fontSize: big ? 26 : 20, fontWeight: 700, color: color || C.text }}><bdi dir="ltr">{value}</bdi></div>
    </div>
  );
}

function ErrorBox({ msg }: { msg: string }) {
  return (
    <div style={{ background: "#3a1420", border: `1px solid ${C.bad}`, color: "#ffd9de", borderRadius: 10, padding: 12, marginBottom: 14 }}>
      ⚠️ {msg}
    </div>
  );
}

function QuotaMeter({ usage }: { usage: Usage | null }) {
  if (!usage || usage.error) {
    return (
      <div style={{ background: C.panel, border: `1px solid ${C.line}`, borderRadius: 12, padding: 14, marginBottom: 16 }}>
        <div style={{ color: C.muted, fontSize: 13 }}>استهلاك الـ VPS: {usage?.error || "غير متاح"}</div>
      </div>
    );
  }
  const used = usage.total_bytes || 0;
  const quotaBytes = (usage.quota_gb || 0) * 1024 ** 3;
  const pct = quotaBytes > 0 ? Math.min(100, (used / quotaBytes) * 100) : 0;
  const color = pct > 90 ? C.bad : pct > 75 ? C.warn : C.good;
  return (
    <div style={{ background: C.panel, border: `1px solid ${C.line}`, borderRadius: 12, padding: 14, marginBottom: 16 }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8, fontSize: 13 }}>
        <span>حصة بيانات الـ VPS</span>
        <span style={{ color: C.muted }}>
          <bdi dir="ltr">{fmtBytes(used)}</bdi> {usage.quota_gb ? <>من <bdi dir="ltr">{usage.quota_gb} GB</bdi></> : ""} · تشغيل {fmtUptime(usage.uptime_sec || 0)}
        </span>
      </div>
      {usage.quota_gb ? (
        <>
          <div style={{ height: 10, background: C.panel2, borderRadius: 6, overflow: "hidden" }}>
            <div style={{ width: `${pct}%`, height: "100%", background: color, transition: "width .4s" }} />
          </div>
          {pct > 90 && <div style={{ color: C.bad, fontSize: 12, marginTop: 6 }}>⚠️ اقتربت من الحصّة — الحركة تمرّ عبر الـ VPS مرّتين</div>}
        </>
      ) : (
        <div style={{ color: C.muted, fontSize: 12 }}>حدّد QUOTA_GB في الإعداد لتفعيل التنبيه</div>
      )}
    </div>
  );
}

function CardTable({
  cards, totalWeight, perCardRate, onRemove,
}: {
  cards: Card[]; totalWeight: number; perCardRate: Record<number, number>; onRemove: (id: number) => void;
}) {
  if (cards.length === 0) {
    return <div style={{ color: C.muted, padding: 20, textAlign: "center" }}>لا كروت بعد — أضف كرتاً من الأعلى.</div>;
  }
  const sorted = [...cards].sort((a, b) => a.id - b.id);
  return (
    <div style={{ background: C.panel, border: `1px solid ${C.line}`, borderRadius: 12, overflow: "hidden" }}>
      <div style={{ display: "grid", gridTemplateColumns: "48px 1fr 90px 70px 80px 90px 100px 70px 70px", gap: 8, padding: "10px 12px", color: C.muted, fontSize: 12, borderBottom: `1px solid ${C.line}` }}>
        <div>#</div><div>الجهاز</div><div>السرعة الآن</div><div>التأخير</div><div>متبقٍ</div><div>الموثوقية</div><div>الحصة</div><div>الحالة</div><div></div>
      </div>
      {sorted.map((c) => {
        const share = c.up ? ((c.weight / totalWeight) * 100) : 0;
        return (
          <div key={c.id} style={{ display: "grid", gridTemplateColumns: "48px 1fr 90px 70px 80px 90px 100px 70px 70px", gap: 8, padding: "10px 12px", alignItems: "center", borderBottom: `1px solid ${C.line}`, fontSize: 13, opacity: c.up ? 1 : 0.5 }}>
            <div style={{ color: C.muted }}>{c.id}</div>
            <div>
              <div>
                {c.device || c.username || `كرت ${c.id}`}
                {c.kind === "pppoe" && <span style={{ marginInlineStart: 6, fontSize: 10, color: "var(--accent)", border: "1px solid var(--accent)", borderRadius: 4, padding: "0 4px" }}>برودباند</span>}
              </div>
              <div style={{ color: C.muted, fontSize: 11, fontFamily: "monospace" }}><bdi dir="ltr">{c.mac}</bdi></div>
            </div>
            <div style={{ color: C.good }}><bdi dir="ltr">{fmtRate(perCardRate[c.id] || 0)}</bdi></div>
            <div><bdi dir="ltr">{fmtMs(c.srtt_ms)}</bdi></div>
            <div style={{ color: timeLeftColor(c.expires_at) }}><bdi dir="ltr">{fmtLeft(c.expires_at)}</bdi></div>
            <div><Bar pct={c.reliability * 100} color={c.reliability > 0.8 ? C.good : c.reliability > 0.5 ? C.warn : C.bad} /></div>
            <div><Bar pct={share} color={C.accent} label={`${share.toFixed(0)}%`} /></div>
            <div style={{ color: c.up ? C.good : C.bad }}>{c.up ? "● يعمل" : "○ ساقط"}</div>
            <div><button onClick={() => onRemove(c.id)} style={btnDanger}>إزالة</button></div>
          </div>
        );
      })}
    </div>
  );
}

function Bar({ pct, color, label }: { pct: number; color: string; label?: string }) {
  return (
    <div style={{ position: "relative", height: 16, background: C.panel2, borderRadius: 4, overflow: "hidden" }}>
      <div style={{ width: `${Math.min(100, pct)}%`, height: "100%", background: color, transition: "width .4s" }} />
      <span style={{ position: "absolute", inset: 0, textAlign: "center", fontSize: 10, lineHeight: "16px", color: C.text }}>
        {label ?? `${pct.toFixed(0)}%`}
      </span>
    </div>
  );
}

function AddCard({ onDone }: { onDone: () => void }) {
  const [open, setOpen] = useState(false);
  const [id, setId] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [kbps, setKbps] = useState("2000");
  const [kind, setKind] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  async function submit() {
    setErr("");
    setBusy(true);
    try {
      const r = await fetch("/api/cards", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: Number(id), username, password, base_kbps: Number(kbps), kind }),
      });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || "فشل");
      setOpen(false);
      setId(""); setUsername(""); setPassword("");
      onDone();
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  }

  if (!open) {
    return (
      <button onClick={() => setOpen(true)} style={{ ...btnPrimary, marginBottom: 16 }}>
        + إضافة كرت أثناء التشغيل
      </button>
    );
  }
  return (
    <div style={{ background: C.panel, border: `1px solid ${C.line}`, borderRadius: 12, padding: 14, marginBottom: 16 }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(130px,1fr))", gap: 10 }}>
        <label style={{ display: "block", fontSize: 12, color: C.muted }}>
          النوع
          <select
            value={kind}
            onChange={(e) => { setKind(e.target.value); setKbps(e.target.value === "pppoe" ? "8000" : "2000"); }}
            style={{ width: "100%", marginTop: 4, padding: "8px 10px", background: C.bg, border: `1px solid ${C.line}`, borderRadius: 8, color: C.text, fontSize: 14 }}
          >
            <option value="">بطاقة هوتسبوت</option>
            <option value="pppoe">خط برودباند (PPPoE)</option>
          </select>
        </label>
        <Field label="رقم الكرت" value={id} onChange={setId} type="number" />
        <Field label="اسم المستخدم" value={username} onChange={setUsername} />
        <Field label="كلمة المرور" value={password} onChange={setPassword} />
        <Field label="السعة Kbps" value={kbps} onChange={setKbps} type="number" />
      </div>
      {err && <div style={{ color: C.bad, fontSize: 12, marginTop: 8 }}>{err}</div>}
      <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
        <button onClick={submit} disabled={busy} style={btnPrimary}>{busy ? "جارٍ التهيئة…" : "إضافة"}</button>
        <button onClick={() => setOpen(false)} style={btnGhost}>إلغاء</button>
      </div>
    </div>
  );
}

// BulkAdd: paste many cards at once, one per line: "username password"
// (space, colon, comma or tab between them). IDs continue after the highest
// existing card ID. Cards are added one by one (each logs in to the hotspot).
function BulkAdd({ onDone }: { onDone: () => void }) {
  const [open, setOpen] = useState(false);
  const [text, setText] = useState("");
  const [kbps, setKbps] = useState("2000");
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState("");
  const [errors, setErrors] = useState<string[]>([]);

  const lines = text
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean)
    .map((l) => l.split(/[\s:,;]+/))
    .filter((p) => p.length >= 2);

  async function submit() {
    setBusy(true);
    setErrors([]);
    const errs: string[] = [];
    try {
      const existing: { id: number }[] = await fetch("/api/cards").then((r) => r.json());
      let nextId = Math.max(0, ...(Array.isArray(existing) ? existing.map((c) => c.id) : [])) + 1;
      for (let i = 0; i < lines.length; i++) {
        const [username, password] = lines[i];
        setProgress(`${i + 1} / ${lines.length}`);
        const r = await fetch("/api/cards", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: nextId, username, password, base_kbps: Number(kbps) }),
        });
        if (r.ok) {
          nextId++;
        } else {
          const j = await r.json().catch(() => ({}));
          if (String(j.error || "").includes("already exists") && nextId < 10000) {
            nextId++; // ID taken: retry the same card with the next ID
            i--;
            continue;
          }
          // failed cards are not saved, so their ID stays free for the next one
          errs.push(`${username}: ${j.error || r.status}`);
        }
        onDone();
      }
    } catch (e: any) {
      errs.push(e.message);
    } finally {
      setErrors(errs);
      setBusy(false);
      setProgress(errs.length ? `انتهى — ${lines.length - errs.length} نجحت، ${errs.length} فشلت` : `انتهى — ${lines.length} نجحت`);
      if (!errs.length) setText("");
    }
  }

  if (!open) {
    return (
      <button onClick={() => setOpen(true)} style={{ ...btnGhost, marginBottom: 16 }}>
        إضافة عدّة كروت دفعة واحدة
      </button>
    );
  }
  return (
    <div style={{ flexBasis: "100%", background: C.panel, border: `1px solid ${C.line}`, borderRadius: 12, padding: 14, marginBottom: 16 }}>
      <div style={{ fontSize: 12, color: C.muted, marginBottom: 6 }}>
        كرت في كل سطر: اسم المستخدم ثم كلمة المرور (بينهما مسافة أو :)
      </div>
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        rows={8}
        dir="ltr"
        placeholder={"215328805572 123456\n260328844572 654321"}
        style={{ width: "100%", padding: 10, background: C.bg, border: `1px solid ${C.line}`, borderRadius: 8, color: C.text, fontFamily: "monospace", fontSize: 13 }}
      />
      <div style={{ display: "flex", gap: 10, alignItems: "flex-end", marginTop: 10, flexWrap: "wrap" }}>
        <div style={{ width: 140 }}><Field label="السعة Kbps لكل كرت" value={kbps} onChange={setKbps} type="number" /></div>
        <button onClick={submit} disabled={busy || lines.length === 0} style={btnPrimary}>
          {busy ? `جارٍ الإضافة ${progress}…` : `إضافة ${lines.length} كرت`}
        </button>
        <button onClick={() => setOpen(false)} disabled={busy} style={btnGhost}>إغلاق</button>
        {!busy && progress && <span style={{ fontSize: 12, color: C.muted }}>{progress}</span>}
      </div>
      {errors.length > 0 && (
        <div style={{ color: C.bad, fontSize: 12, marginTop: 8, direction: "ltr", textAlign: "left" }}>
          {errors.map((e, i) => <div key={i}>{e}</div>)}
        </div>
      )}
    </div>
  );
}

// ---- time left helpers ----
function msLeft(exp?: string): number | null {
  if (!exp) return null;
  const t = Date.parse(exp);
  if (!t || new Date(t).getUTCFullYear() < 2000) return null;
  return t - Date.now();
}
function fmtLeft(exp?: string): string {
  const ms = msLeft(exp);
  if (ms === null) return "—";
  if (ms <= 0) return "0m";
  const m = Math.floor(ms / 60000);
  const d = Math.floor(m / 1440);
  if (d > 0) return `${d}d ${Math.floor((m % 1440) / 60)}h`;
  return `${Math.floor(m / 60)}h ${m % 60}m`;
}
function timeLeftColor(exp?: string): string {
  const ms = msLeft(exp);
  if (ms === null) return C.muted;
  return ms < 30 * 60000 ? C.warn : C.text;
}

type StockCard = {
  id: number; username: string; package: string; duration_h: number; status: string;
  first_login?: string; expires_at?: string; ended_at?: string; fails: number; last_error?: string;
};
type StockView = { target: number; counts: Record<string, number>; cards: StockCard[] | null; error?: string };

// StockPanel: import the provider's Excel file, set how many cards run at once,
// and see what is left. Expired cards are replaced automatically by the node.
function StockPanel() {
  const [view, setView] = useState<StockView | null>(null);
  const [target, setTarget] = useState("");
  const [kbps, setKbps] = useState("2000");
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [showBad, setShowBad] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  async function load() {
    try {
      const v: StockView = await fetch("/api/stock").then((r) => r.json());
      setView(v);
      setTarget((t) => (t === "" ? String(v.target ?? 0) : t));
    } catch { /* transient */ }
  }
  useEffect(() => {
    load();
    const h = setInterval(load, 5000);
    return () => clearInterval(h);
  }, []);

  async function importFile(f: File) {
    setBusy(true);
    setMsg(null);
    try {
      const r = await fetch(`/api/stock/import?kbps=${encodeURIComponent(kbps)}`, { method: "POST", body: await f.arrayBuffer() });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || "فشل الاستيراد");
      let text = `أُضيفت ${j.added} بطاقة إلى المخزون`;
      if (j.duplicates) text += ` · ${j.duplicates} موجودة مسبقاً`;
      if (j.missing_password?.length) text += ` · بلا كلمة مرور (لم تُضف): ${j.missing_password.join("، ")}`;
      setMsg({ ok: true, text });
      load();
    } catch (e: any) {
      setMsg({ ok: false, text: e.message });
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  async function saveTarget() {
    const n = Math.max(0, Number(target) || 0);
    await fetch("/api/stock/target", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ target: n }) });
    setMsg({ ok: true, text: n > 0 ? `سيُبقي النظام ${n} بطاقة تعمل ويستبدل المنتهية تلقائياً` : "التبديل التلقائي متوقف" });
    load();
  }

  async function clear(status: string) {
    await fetch(`/api/stock?status=${status}`, { method: "DELETE" });
    load();
  }

  if (view?.error) return <ErrorBox msg={view.error} />;
  const counts = view?.counts || {};
  const cards = view?.cards || [];
  const unusedHours = cards.filter((c) => c.status === "unused").reduce((a, c) => a + (c.duration_h || 0), 0);
  const tgt = view?.target || 0;
  const coverH = tgt > 0 ? unusedHours / tgt : 0;
  const bad = cards.filter((c) => c.status === "bad");

  return (
    <div style={{ background: C.panel, border: `1px solid ${C.line}`, borderRadius: 12, padding: 14, marginBottom: 16 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 8, marginBottom: 12 }}>
        <div style={{ fontWeight: 700 }}>مخزون البطاقات</div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", fontSize: 12 }}>
          <Chip label="جاهزة" n={counts.unused || 0} color={C.accent} />
          <Chip label="تعمل" n={counts.active || 0} color={C.good} />
          <Chip label="منتهية" n={counts.expired || 0} color={C.muted} />
          <Chip label="مرفوضة" n={counts.bad || 0} color={C.bad} />
        </div>
      </div>

      <div style={{ display: "flex", gap: 10, alignItems: "flex-end", flexWrap: "wrap" }}>
        <div style={{ width: 150 }}>
          <Field label="عدد البطاقات العاملة" value={target} onChange={setTarget} type="number" />
        </div>
        <button onClick={saveTarget} style={btnPrimary}>حفظ</button>
        <div style={{ width: 1, alignSelf: "stretch", background: C.line, margin: "0 6px" }} />
        <div style={{ width: 130 }}>
          <Field label="السعة Kbps لكل بطاقة" value={kbps} onChange={setKbps} type="number" />
        </div>
        <input ref={fileRef} type="file" accept=".xlsx,.csv,.txt" style={{ display: "none" }}
          onChange={(e) => e.target.files?.[0] && importFile(e.target.files[0])} />
        <button onClick={() => fileRef.current?.click()} disabled={busy} style={btnGhost}>
          {busy ? "جارٍ الاستيراد…" : "استيراد ملف Excel"}
        </button>
      </div>

      {msg && <div style={{ color: msg.ok ? C.good : C.bad, fontSize: 12, marginTop: 10 }}>{msg.text}</div>}

      <div style={{ color: C.muted, fontSize: 12, marginTop: 10 }}>
        {tgt > 0
          ? <>المخزون الجاهز يكفي نحو <bdi dir="ltr">{coverH.toFixed(1)}</bdi> ساعة بمعدل {tgt} بطاقة تعمل معاً.</>
          : "حدّد عدد البطاقات العاملة لتفعيل التبديل التلقائي."}
        {(counts.expired || 0) > 0 && <> · <a onClick={() => clear("expired")} style={linkStyle}>حذف المنتهية من القائمة</a></>}
        {bad.length > 0 && <> · <a onClick={() => setShowBad(!showBad)} style={linkStyle}>{showBad ? "إخفاء" : "عرض"} المرفوضة</a></>}
      </div>

      {showBad && bad.length > 0 && (
        <div style={{ marginTop: 10, fontSize: 12, borderTop: `1px solid ${C.line}`, paddingTop: 8 }}>
          {bad.map((c) => (
            <div key={c.id} style={{ display: "flex", gap: 10, padding: "3px 0", alignItems: "baseline" }}>
              <span style={{ fontFamily: "monospace" }} dir="ltr">{c.username}</span>
              <span style={{ color: C.muted, flex: 1 }} dir="ltr">{c.last_error || "—"}</span>
            </div>
          ))}
          <a onClick={() => clear("bad")} style={linkStyle}>حذف المرفوضة من القائمة</a>
        </div>
      )}
    </div>
  );
}

// DirectSites: sites that do not go through the tunnel (local payment/bank
// sites); they leave through the node's own local internet.
function DirectSites() {
  const [open, setOpen] = useState(false);
  const [text, setText] = useState("");
  const [info, setInfo] = useState<{ domains: string[]; ips: Record<string, string[]>; iface: string } | null>(null);
  const [msg, setMsg] = useState("");

  async function load(fill: boolean) {
    try {
      const j = await fetch("/api/direct").then((r) => r.json());
      if (j.error) return;
      setInfo(j);
      if (fill) setText((j.domains || []).join("\n"));
    } catch { /* transient */ }
  }
  useEffect(() => { load(true); }, []);

  async function save() {
    const domains = text.split(/[\s,]+/).map((d) => d.trim()).filter(Boolean);
    const r = await fetch("/api/direct", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ domains }) });
    const j = await r.json();
    if (!r.ok) { setMsg(j.error || "فشل الحفظ"); return; }
    setText(j.domains.join("\n"));
    setMsg(`حُفظت ${j.domains.length} مواقع — تمرّ مباشرة خلال ثوانٍ`);
    setTimeout(() => load(false), 4000);
  }

  const n = info?.domains?.length || 0;
  return (
    <div style={{ background: C.panel, border: `1px solid ${C.line}`, borderRadius: 12, padding: 14, marginBottom: 16 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
        <div>
          <span style={{ fontWeight: 700 }}>مواقع تمرّ مباشرة (بدون النفق)</span>
          <span style={{ color: C.muted, fontSize: 12, marginInlineStart: 8 }}>
            {n} موقع{info?.iface ? <> · عبر <bdi dir="ltr">{info.iface}</bdi></> : null}
          </span>
        </div>
        <button onClick={() => setOpen(!open)} style={btnGhost}>{open ? "إخفاء" : "تعديل"}</button>
      </div>
      {open && (
        <div style={{ marginTop: 10 }}>
          <div style={{ fontSize: 12, color: C.muted, marginBottom: 6 }}>
            موقع في كل سطر (مثل jawwalpay.ps). الصفحات التي تحمّل من نطاقات أخرى تحتاج تلك النطاقات أيضاً.
          </div>
          <textarea value={text} onChange={(e) => setText(e.target.value)} rows={7} dir="ltr"
            style={{ width: "100%", padding: 10, background: C.bg, border: `1px solid ${C.line}`, borderRadius: 8, color: C.text, fontFamily: "monospace", fontSize: 13 }} />
          <div style={{ display: "flex", gap: 10, alignItems: "center", marginTop: 8, flexWrap: "wrap" }}>
            <button onClick={save} style={btnPrimary}>حفظ</button>
            {msg && <span style={{ fontSize: 12, color: C.good }}>{msg}</span>}
          </div>
          {info && n > 0 && (
            <div style={{ marginTop: 10, fontSize: 12, borderTop: `1px solid ${C.line}`, paddingTop: 8 }} dir="ltr">
              {info.domains.map((d) => (
                <div key={d} style={{ display: "flex", gap: 10, padding: "2px 0" }}>
                  <span style={{ fontFamily: "monospace", minWidth: 220 }}>{d}</span>
                  <span style={{ color: (info.ips?.[d] || []).length ? C.muted : C.bad }}>
                    {(info.ips?.[d] || []).length ? (info.ips[d] || []).join(", ") : "not resolved yet"}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function Chip({ label, n, color }: { label: string; n: number; color: string }) {
  return (
    <span style={{ border: `1px solid ${C.line}`, borderRadius: 20, padding: "3px 10px", color }}>
      {label} <b><bdi dir="ltr">{n}</bdi></b>
    </span>
  );
}

const linkStyle: React.CSSProperties = { color: "var(--accent)", cursor: "pointer", textDecoration: "underline" };

function Field({ label, value, onChange, type = "text" }: { label: string; value: string; onChange: (v: string) => void; type?: string }) {
  return (
    <label style={{ display: "block", fontSize: 12, color: C.muted }}>
      {label}
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        style={{ width: "100%", marginTop: 4, padding: "8px 10px", background: C.bg, border: `1px solid ${C.line}`, borderRadius: 8, color: C.text, fontSize: 14 }}
      />
    </label>
  );
}

const btnPrimary: React.CSSProperties = { background: C.accent, color: "#04122a", border: "none", borderRadius: 8, padding: "9px 16px", fontWeight: 700, cursor: "pointer", fontSize: 14 };
const btnGhost: React.CSSProperties = { background: "transparent", color: C.muted, border: `1px solid ${C.line}`, borderRadius: 8, padding: "9px 16px", cursor: "pointer", fontSize: 14 };
const btnDanger: React.CSSProperties = { background: "transparent", color: C.bad, border: `1px solid ${C.bad}`, borderRadius: 6, padding: "4px 10px", cursor: "pointer", fontSize: 12 };
