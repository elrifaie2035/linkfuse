// lf-client: طرف النفق على العقدة المحلية.
//
// التشغيل:  lf-client -config /etc/linkfuse/client.json
//
// هذا الوضع يربط كل كرت عبر اسم واجهته (SO_BINDTODEVICE) — مناسب عندما يكون كل
// كرت واجهةً مرئية في المجال الجذر (NIC مستقل أو veth من namespace الكرت).
// للوضع الكامل القائم على network namespaces لكل كرت، تُنشئ طبقة node السوكيتات
// داخل كل namespace وتستدعي مكتبة client مباشرة.
package main

import (
	"encoding/json"
	"flag"
	"log"
	"net"
	"os"
	"os/exec"
	"strconv"
	"syscall"
	"time"

	"github.com/linkfuse/tunnel/client"
)

type pathSpec struct {
	ID       uint16 `json:"id"`
	Iface    string `json:"iface"`     // اسم واجهة الكرت للخروج عبره
	BaseKbps int    `json:"base_kbps"` // سعة الكرت الاسمية
}

type fileConfig struct {
	Server       string     `json:"server"`   // "IP:51820"
	TunName      string     `json:"tun"`      // "lf0"
	TunAddr      string     `json:"tun_addr"` // "10.9.0.2/24"
	MTU          int        `json:"mtu"`
	PSK          string     `json:"psk"`
	ReorderHold  int        `json:"reorder_hold_ms"`
	ReorderCap   int        `json:"reorder_cap"`
	KeepaliveInt int        `json:"keepalive_ms"`
	PathTimeout  int        `json:"path_timeout_ms"`
	Paths        []pathSpec `json:"paths"`
}

func main() {
	cfgPath := flag.String("config", "/etc/linkfuse/client.json", "مسار ملف الإعداد JSON")
	flag.Parse()

	fc := loadConfig(*cfgPath)

	pcs := make([]client.PathConn, 0, len(fc.Paths))
	for _, ps := range fc.Paths {
		conn, err := dialVia(ps.Iface, fc.Server)
		if err != nil {
			log.Printf("[lf-client] تعذّر ربط الكرت #%d عبر %s: %v — سيُتجاهَل مؤقتاً", ps.ID, ps.Iface, err)
			continue
		}
		pcs = append(pcs, client.PathConn{ID: ps.ID, Conn: conn, BaseKbps: ps.BaseKbps})
		log.Printf("[lf-client] الكرت #%d عبر %s جاهز", ps.ID, ps.Iface)
	}
	if len(pcs) == 0 {
		log.Fatal("لا يوجد أي مسار صالح")
	}

	cl, err := client.New(client.Config{
		TunName:      fc.TunName,
		PSK:          fc.PSK,
		ReorderHold:  time.Duration(fc.ReorderHold) * time.Millisecond,
		ReorderCap:   fc.ReorderCap,
		KeepaliveInt: time.Duration(fc.KeepaliveInt) * time.Millisecond,
		PathTimeout:  time.Duration(fc.PathTimeout) * time.Millisecond,
	}, pcs)
	if err != nil {
		log.Fatalf("تهيئة العميل: %v", err)
	}

	setupTun(fc.TunName, fc.TunAddr, fc.MTU)

	log.Printf("[lf-client] يعمل بـ %d مسار", len(pcs))
	cl.Run()
}

// dialVia يفتح سوكيت UDP موصولاً بالخادم ومقيّداً بالخروج عبر الواجهة ifname.
// SO_BINDTODEVICE يحتاج صلاحية root (CAP_NET_RAW).
func dialVia(ifname, server string) (*net.UDPConn, error) {
	d := net.Dialer{
		Control: func(network, address string, c syscall.RawConn) error {
			var operr error
			if err := c.Control(func(fd uintptr) {
				operr = syscall.SetsockoptString(int(fd), syscall.SOL_SOCKET, syscall.SO_BINDTODEVICE, ifname)
			}); err != nil {
				return err
			}
			return operr
		},
	}
	conn, err := d.Dial("udp", server)
	if err != nil {
		return nil, err
	}
	return conn.(*net.UDPConn), nil
}

func loadConfig(path string) fileConfig {
	b, err := os.ReadFile(path)
	if err != nil {
		log.Fatalf("قراءة الإعداد %s: %v", path, err)
	}
	fc := fileConfig{
		TunName: "lf0", TunAddr: "10.9.0.2/24", MTU: 1400,
		ReorderHold: 40, ReorderCap: 4096, KeepaliveInt: 1000, PathTimeout: 5000,
	}
	if err := json.Unmarshal(b, &fc); err != nil {
		log.Fatalf("تحليل الإعداد: %v", err)
	}
	if fc.PSK == "" || fc.Server == "" {
		log.Fatal("psk وserver مطلوبان في الإعداد")
	}
	return fc
}

func setupTun(name, addr string, mtu int) {
	run("ip", "addr", "add", addr, "dev", name)
	run("ip", "link", "set", "dev", name, "mtu", strconv.Itoa(mtu))
	run("ip", "link", "set", "dev", name, "up")
}

func run(args ...string) {
	if out, err := exec.Command(args[0], args[1:]...).CombinedOutput(); err != nil {
		log.Printf("[setup] %v: %v (%s)", args, err, string(out))
	}
}
