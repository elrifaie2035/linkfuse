//go:build linux && arm64

package netns

const sysSetns = 268
