//go:build linux

package netns

import (
	"fmt"
	"os/exec"
	"strings"
	"time"
)

// Card يصف ما يلزم لتهيئة كرت داخل namespace خاص به.
type Card struct {
	NS     string // اسم الـ namespace، مثلاً "lfcard-3"
	Parent string // واجهة خط المزوّد (WAN)، مثلاً "ens19"
	MVName string // اسم واجهة MACVLAN داخل الـ namespace، مثلاً "lfm3"
	MAC    string // عنوان MAC الوهمي "f0:18:98:ab:cd:ef"
}

func ipRun(args ...string) (string, error) {
	out, err := exec.Command("ip", args...).CombinedOutput()
	if err != nil {
		return string(out), fmt.Errorf("ip %s: %v (%s)", strings.Join(args, " "), err, strings.TrimSpace(string(out)))
	}
	return string(out), nil
}

// Setup يُنشئ namespace الكرت وواجهة MACVLAN بالـ MAC الوهمي ويُشغّلها.
// MACVLAN في وضع bridge يجعل المزوّد يرى كل كرت كجهاز مستقلّ بعنوانه الخاص.
//
// يطابق أسلوب Octopus حرفياً: promisc on على الأب وعلى واجهة الكرت،
// وrp_filter=0 داخل namespace — بدونهما تُسقَط حزم الإنترنت العائدة بصمت.
func (c Card) Setup() error {
	// الأب في الوضع المختلط ليمرّر حركة الـ MAC الوهمي (كما يفعل Octopus).
	_, _ = ipRun("link", "set", c.Parent, "promisc", "on")

	// namespace جديد (نتجاهل الخطأ إن كان موجوداً من تشغيل سابق بعد تنظيفه).
	_, _ = ipRun("netns", "add", c.NS)

	// MACVLAN على واجهة المزوّد في المجال الجذر، ثم ننقلها إلى namespace الكرت.
	tmp := "lftmp-" + c.NS
	if out, err := ipRun("link", "add", "link", c.Parent, "name", tmp, "type", "macvlan", "mode", "bridge"); err != nil {
		return fmt.Errorf("إنشاء MACVLAN: %s", out)
	}
	if _, err := ipRun("link", "set", tmp, "address", c.MAC); err != nil {
		_, _ = ipRun("link", "del", tmp)
		return err
	}
	if _, err := ipRun("link", "set", tmp, "netns", c.NS); err != nil {
		_, _ = ipRun("link", "del", tmp)
		return err
	}
	// داخل الـ namespace: نعيد التسمية ونُشغّل.
	if _, err := ipRun("netns", "exec", c.NS, "ip", "link", "set", tmp, "name", c.MVName); err != nil {
		return err
	}
	_, _ = ipRun("netns", "exec", c.NS, "ip", "link", "set", "lo", "up")
	if _, err := ipRun("netns", "exec", c.NS, "ip", "link", "set", c.MVName, "up"); err != nil {
		return err
	}
	// الوضع المختلط على واجهة الكرت داخل namespace.
	_, _ = ipRun("netns", "exec", c.NS, "ip", "link", "set", c.MVName, "promisc", "on")

	// إطفاء rp_filter داخل namespace (السبب الأكبر لعدم عودة الإنترنت).
	c.sysctlNS("net.ipv4.conf.all.rp_filter=0")
	c.sysctlNS("net.ipv4.conf.default.rp_filter=0")
	c.sysctlNS("net.ipv4.conf." + c.MVName + ".rp_filter=0")
	c.sysctlNS("net.ipv4.conf.all.src_valid_mark=1")
	return nil
}

// sysctlNS يضبط قيمة sysctl داخل namespace الكرت (يتجاهل الفشل).
func (c Card) sysctlNS(kv string) {
	_, _ = ipRun("netns", "exec", c.NS, "sysctl", "-w", kv)
}

// DHCP يطلب عنواناً من المزوّد داخل namespace الكرت مع إعادة محاولة (علاج dhcp_timeout).
// يجرّب udhcpc ثم dhclient حسب المتوفّر.
func (c Card) DHCP(retries int, wait time.Duration) error {
	if retries <= 0 {
		retries = 4
	}
	if wait == 0 {
		wait = 3 * time.Second
	}
	var lastErr error
	for i := 1; i <= retries; i++ {
		if err := c.dhcpOnce(); err != nil {
			lastErr = err
			time.Sleep(wait)
			continue
		}
		// نتأكّد أنه حصل على عنوان فعلاً.
		if c.hasIPv4() {
			return nil
		}
		lastErr = fmt.Errorf("لم يُسنَد عنوان IPv4")
		time.Sleep(wait)
	}
	return fmt.Errorf("فشل DHCP للكرت %s بعد %d محاولة: %w", c.NS, retries, lastErr)
}

func (c Card) dhcpOnce() error {
	// dhclient بملفات lease/pid منفصلة لكل كرت (كما يفعل Octopus) — يمنع تعارض
	// الكروت على ملف lease واحد، وهوية المضيف ثابتة لكل كرت.
	if _, err := exec.LookPath("dhclient"); err == nil {
		lease := "/run/octopus-" + c.NS + ".lease"
		pid := "/run/octopus-" + c.NS + ".pid"
		host := strings.ReplaceAll(c.NS, "lfcard-", "lf")
		out, err := exec.Command("ip", "netns", "exec", c.NS,
			"dhclient", "-v", "-1", "-H", host, "-lf", lease, "-pf", pid, c.MVName).CombinedOutput()
		if err != nil {
			return fmt.Errorf("dhclient: %v (%s)", err, strings.TrimSpace(string(out)))
		}
		return nil
	}
	// udhcpc كبديل
	if _, err := exec.LookPath("udhcpc"); err == nil {
		out, err := exec.Command("ip", "netns", "exec", c.NS,
			"udhcpc", "-i", c.MVName, "-n", "-q", "-t", "5", "-T", "3").CombinedOutput()
		if err != nil {
			return fmt.Errorf("udhcpc: %v (%s)", err, strings.TrimSpace(string(out)))
		}
		return nil
	}
	return fmt.Errorf("لا dhclient ولا udhcpc مثبّت")
}

func (c Card) hasIPv4() bool {
	out, err := ipRun("netns", "exec", c.NS, "ip", "-4", "addr", "show", "dev", c.MVName)
	if err != nil {
		return false
	}
	return strings.Contains(out, "inet ")
}

// Teardown يزيل namespace الكرت وكل ما فيه.
func (c Card) Teardown() {
	_, _ = ipRun("netns", "del", c.NS)
}
