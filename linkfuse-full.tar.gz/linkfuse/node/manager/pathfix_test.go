package manager

import "testing"

func TestLineRedialReopensSocket(t *testing.T) {
	m := testManager(t, nil)
	line := CardCfg{ID: 11025, Kind: KindPPPoE, BaseKbps: 8000}
	ip := "10.32.15.245"
	m.pppoeIPFn = func(uint16) string { return ip }
	reopened := 0
	m.reopenFn = func(CardCfg) error { reopened++; return nil }
	m.refreshPaths([]CardCfg{line})
	m.refreshPaths([]CardCfg{line})
	if reopened != 0 {
		t.Fatalf("reopened without a change: %d", reopened)
	}
	ip = "10.32.15.244"
	m.refreshPaths([]CardCfg{line})
	if reopened != 1 {
		t.Fatalf("socket not reopened after redial: %d", reopened)
	}
}
