package identity

import (
	"net"
	"testing"
)

func TestGenerateValidMAC(t *testing.T) {
	for i := 0; i < 100; i++ {
		id := Generate()
		if _, err := net.ParseMAC(id.MAC); err != nil {
			t.Fatalf("MAC غير صالح %q: %v", id.MAC, err)
		}
		if id.DeviceName == "" {
			t.Fatal("اسم الجهاز فارغ")
		}
	}
}

func TestGenerateForDeterministic(t *testing.T) {
	a := GenerateFor(42)
	b := GenerateFor(42)
	if a != b {
		t.Fatalf("نفس البذرة يجب أن تُعطي نفس الهوية: %+v vs %+v", a, b)
	}
	if GenerateFor(1) == GenerateFor(2) {
		t.Fatal("بذور مختلفة يجب أن تُعطي هويات مختلفة")
	}
	if _, err := net.ParseMAC(a.MAC); err != nil {
		t.Fatalf("MAC غير صالح: %v", err)
	}
}

func TestOUIMatchesVendorModel(t *testing.T) {
	// الموديل يجب أن يكون من موديلات نفس الشركة صاحبة الـ OUI.
	for seed := uint64(0); seed < 50; seed++ {
		id := GenerateFor(seed)
		hw, err := net.ParseMAC(id.MAC)
		if err != nil {
			t.Fatalf("MAC غير صالح: %v", err)
		}
		if len(hw) != 6 {
			t.Fatalf("طول MAC خاطئ")
		}
	}
}
