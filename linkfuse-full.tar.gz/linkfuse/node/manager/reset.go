package manager

import (
	"log"
	"os/exec"
	"sync/atomic"
	"time"
)

// Panel buttons for when the bond feels stuck or slow.
//
// SoftReset ("إعادة ضبط", a few seconds, cards stay logged in):
//   - reopens the tunnel socket of every live card/line,
//   - forgets the measured congestion/delay of every path on both sides (the
//     server follows through the keepalives), so a wrong reading can no
//     longer hold the speed down,
//   - re-sizes both shapers at once.
//
// Restart ("إعادة تشغيل", 1-5 minutes): restarts the lf-node service - every
// card logs out and in again, like after a reboot.

var forceUpShape atomic.Bool

// SoftReset runs the soft reset; it returns how many paths were refreshed.
func (m *Manager) SoftReset() int {
	m.mu.Lock()
	live := make([]CardCfg, 0, len(m.cards))
	for _, cs := range m.cards {
		live = append(live, cs.cfg)
	}
	m.mu.Unlock()
	n := 0
	for _, cc := range live {
		if err := m.reopenFn(cc); err != nil {
			log.Printf("[reset] card #%d: reopening the tunnel socket failed: %v", cc.ID, err)
			continue
		}
		n++
	}
	if m.cl != nil {
		m.cl.SoftReset()
	}
	forceUpShape.Store(true)
	log.Printf("[reset] soft reset from the panel: %d of %d paths refreshed, congestion state cleared on both sides", n, len(live))
	return n
}

// RestartService restarts lf-node a moment after the HTTP answer was sent.
func (m *Manager) RestartService() {
	log.Printf("[reset] full restart requested from the panel")
	go func() {
		time.Sleep(time.Second)
		if err := exec.Command("systemctl", "restart", "--no-block", "lf-node").Run(); err != nil {
			log.Printf("[reset] systemctl restart failed: %v", err)
		}
	}()
}
