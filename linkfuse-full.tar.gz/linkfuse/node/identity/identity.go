// Package identity يولّد هوية هاتف وهمية لكل كرت: عنوان MAC ببادئة OUI لشركة
// حقيقية + اسم جهاز واقعي، فتبدو كل جلسة عند المزوّد كهاتف مختلف — نفس أسلوب Octopus.
package identity

import (
	"crypto/rand"
	"fmt"
	"strings"
)

// vendor بادئة OUI (أول 3 بايت) لشركة + موديلات هواتفها الشائعة.
type vendor struct {
	oui    [3]byte
	models []string
}

// بادئات OUI حقيقية مُسجّلة لكل شركة (مصدرها قوائم IEEE العامة).
var vendors = []vendor{
	{[3]byte{0xF0, 0x18, 0x98}, []string{"iPhone 13", "iPhone 14", "iPhone 14 Pro Max", "iPhone 15", "iPhone 15 Pro"}}, // Apple
	{[3]byte{0xA4, 0x83, 0xE7}, []string{"iPhone 12", "iPhone 13 Pro", "iPhone SE", "iPad Air"}},                       // Apple
	{[3]byte{0xDC, 0xA6, 0x32}, []string{"Galaxy S23", "Galaxy S24 Ultra", "Galaxy A54", "Galaxy A34"}},                // Samsung
	{[3]byte{0x8C, 0x77, 0x12}, []string{"Galaxy S22", "Galaxy M14", "Galaxy A14", "Galaxy Note 20"}},                  // Samsung
	{[3]byte{0x50, 0x8F, 0x4C}, []string{"Redmi Note 12", "Redmi Note 13 Pro", "Mi 11", "Poco X5"}},                    // Xiaomi
	{[3]byte{0x64, 0xB4, 0x73}, []string{"Redmi 10", "Redmi Note 11", "Poco F5", "Mi 12"}},                             // Xiaomi
	{[3]byte{0x48, 0x5F, 0x99}, []string{"Nova 11", "P60 Pro", "Mate 50", "Y9a"}},                                      // Huawei
	{[3]byte{0x34, 0x12, 0xF9}, []string{"Reno 8", "A78", "Find X6", "A96"}},                                           // Oppo
}

// أسماء أولى شائعة لتركيب اسم الجهاز (مثل "Omar iPhone 14 Pro Max").
var firstNames = []string{
	"Omar", "Nawaf", "Ahmad", "Yousef", "Khaled", "Saeed", "Faisal", "Majed",
	"Salem", "Tariq", "Rami", "Sami", "Hani", "Ziad", "Mazen", "Anas",
	"Laith", "Bilal", "Karim", "Nader", "Wael", "Fadi", "Ghassan", "Osama",
}

// Identity هوية كرت واحد.
type Identity struct {
	MAC        string // "f0:18:98:ab:cd:ef"
	DeviceName string // "Omar iPhone 14 Pro Max"
}

// DHCPHostName is the host name a real phone of this kind sends in DHCP:
// iPhones/iPads send "<Name>s-iPhone", Android phones send their model.
func (id Identity) DHCPHostName() string {
	parts := strings.Fields(id.DeviceName)
	if len(parts) < 2 {
		return strings.ReplaceAll(id.DeviceName, " ", "-")
	}
	first, model := parts[0], strings.Join(parts[1:], "-")
	switch {
	case strings.HasPrefix(model, "iPhone"):
		return first + "s-iPhone"
	case strings.HasPrefix(model, "iPad"):
		return first + "s-iPad"
	}
	return model
}

// IsAndroid: Android phones also send a DHCP vendor class ("android-dhcp-13").
func (id Identity) IsAndroid() bool {
	return !strings.Contains(id.DeviceName, "iPhone") && !strings.Contains(id.DeviceName, "iPad")
}

func randByte() byte {
	var b [1]byte
	_, _ = rand.Read(b[:])
	return b[0]
}

func pick[T any](s []T) T {
	return s[int(randByte())%len(s)]
}

// Generate يولّد هوية عشوائية متّسقة (الموديل يطابق شركة الـ OUI).
func Generate() Identity {
	v := pick(vendors)
	suffix := [3]byte{randByte(), randByte(), randByte()}
	mac := fmt.Sprintf("%02x:%02x:%02x:%02x:%02x:%02x",
		v.oui[0], v.oui[1], v.oui[2], suffix[0], suffix[1], suffix[2])
	name := fmt.Sprintf("%s %s", pick(firstNames), pick(v.models))
	return Identity{MAC: mac, DeviceName: name}
}

// GenerateFor يولّد هوية ثابتة مشتقّة من بذرة (مثلاً معرّف الكرت) فتبقى نفسها
// عبر عمليات التشغيل — مفيد كي لا يرى المزوّد الجهاز يغيّر هويته كل إقلاع.
func GenerateFor(seed uint64) Identity {
	v := vendors[seed%uint64(len(vendors))]
	s := seed * 2654435761 // خلط بسيط
	mac := fmt.Sprintf("%02x:%02x:%02x:%02x:%02x:%02x",
		v.oui[0], v.oui[1], v.oui[2], byte(s>>16), byte(s>>8), byte(s))
	name := fmt.Sprintf("%s %s",
		firstNames[(seed/7)%uint64(len(firstNames))],
		v.models[(seed/3)%uint64(len(v.models))])
	return Identity{MAC: mac, DeviceName: name}
}

// Routers: real router vendor OUIs + common models, for broadband (PPPoE) lines.
var routerVendors = []vendor{
	{[3]byte{0x50, 0xC7, 0xBF}, []string{"TP-Link Archer C6", "TP-Link Archer C80", "TP-Link TL-WR841N"}},  // TP-Link
	{[3]byte{0x14, 0xCC, 0x20}, []string{"TP-Link Archer AX23", "TP-Link Archer C5", "TP-Link TL-WR940N"}}, // TP-Link
	{[3]byte{0x00, 0xE0, 0xFC}, []string{"HUAWEI HG8245H", "HUAWEI HG8145V5", "HUAWEI EG8145V5"}},          // Huawei
	{[3]byte{0x34, 0x4B, 0x50}, []string{"ZTE F660", "ZTE F670L", "ZTE ZXHN H108N"}},                       // ZTE
	{[3]byte{0xC8, 0x3A, 0x35}, []string{"Tenda AC10", "Tenda F3", "Tenda AC6"}},                           // Tenda
	{[3]byte{0x4C, 0x5E, 0x0C}, []string{"MikroTik hAP ac2", "MikroTik hAP lite", "MikroTik hEX"}},         // MikroTik
	{[3]byte{0x1C, 0x7E, 0xE5}, []string{"D-Link DIR-615", "D-Link DIR-825", "D-Link DSL-2750U"}},          // D-Link
}

// GenerateRouterFor is GenerateFor for a broadband line: a fixed router
// identity (vendor MAC + router model) derived from the line ID.
func GenerateRouterFor(seed uint64) Identity {
	v := routerVendors[seed%uint64(len(routerVendors))]
	s := seed*2654435761 + 0x9e37
	mac := fmt.Sprintf("%02x:%02x:%02x:%02x:%02x:%02x",
		v.oui[0], v.oui[1], v.oui[2], byte(s>>16), byte(s>>8), byte(s))
	return Identity{MAC: mac, DeviceName: v.models[(seed/5)%uint64(len(v.models))]}
}
