//go:build linux

package netns

import (
	"fmt"
	"os/exec"
	"strings"
	"time"
)

// Card يصف ما يلزم لتهيئة كرت داخل namespace خاص به.
type Card struct {
	NS     string // اسم الـ namespace، مثلاً "lfcard-3"
	Parent string // واجهة خط المزوّد (WAN)، مثلاً "ens19"
	MVName string // اسم واجهة MACVLAN داخل الـ namespace، مثلاً "lfm3"
	MAC    string // عنوان MAC الوهمي "f0:18:98:ab:cd:ef"
}

func ipRun(args ...string) (string, error) {
	out, err := exec.Command("ip", args...).CombinedOutput()
	if err != nil {
		return string(out), fmt.Errorf("ip %s: %v (%s)", strings.Join(args, " "), err, strings.TrimSpace(string(out)))
	}
	return string(out), nil
}

// Setup يُنشئ namespace الكرت وواجهة MACVLAN بالـ MAC الوهمي ويُشغّلها.
// MACVLAN في وضع bridge يجعل المزوّد يرى كل كرت كجهاز مستقلّ بعنوانه الخاص.
func (c Card) Setup() error {
	// namespace جديد (نتجاهل الخطأ إن كان موجوداً من تشغيل سابق بعد تنظيفه).
	_, _ = ipRun("netns", "add", c.NS)

	// MACVLAN على واجهة المزوّد في المجال الجذر، ثم ننقلها إلى namespace الكرت.
	tmp := "lftmp-" + c.NS
	if out, err := ipRun("link", "add", tmp, "link", c.Parent, "type", "macvlan", "mode", "bridge"); err != nil {
		return fmt.Errorf("إنشاء MACVLAN: %s", out)
	}
	if _, err := ipRun("link", "set", tmp, "address", c.MAC); err != nil {
		_, _ = ipRun("link", "del", tmp)
		return err
	}
	if _, err := ipRun("link", "set", tmp, "netns", c.NS); err != nil {
		_, _ = ipRun("link", "del", tmp)
		return err
	}
	// داخل الـ namespace: نعيد التسمية ونُشغّل.
	if _, err := ipRun("netns", "exec", c.NS, "ip", "link", "set", tmp, "name", c.MVName); err != nil {
		return err
	}
	_, _ = ipRun("netns", "exec", c.NS, "ip", "link", "set", "lo", "up")
	if _, err := ipRun("netns", "exec", c.NS, "ip", "link", "set", c.MVName, "up"); err != nil {
		return err
	}
	return nil
}

// DHCP يطلب عنواناً من المزوّد داخل namespace الكرت مع إعادة محاولة (علاج dhcp_timeout).
// يجرّب udhcpc ثم dhclient حسب المتوفّر.
func (c Card) DHCP(retries int, wait time.Duration) error {
	if retries <= 0 {
		retries = 4
	}
	if wait == 0 {
		wait = 3 * time.Second
	}
	var lastErr error
	for i := 1; i <= retries; i++ {
		if err := c.dhcpOnce(); err != nil {
			lastErr = err
			time.Sleep(wait)
			continue
		}
		// نتأكّد أنه حصل على عنوان فعلاً.
		if c.hasIPv4() {
			return nil
		}
		lastErr = fmt.Errorf("لم يُسنَد عنوان IPv4")
		time.Sleep(wait)
	}
	return fmt.Errorf("فشل DHCP للكرت %s بعد %d محاولة: %w", c.NS, retries, lastErr)
}

func (c Card) dhcpOnce() error {
	// udhcpc (BusyBox) إن وُجد
	if _, err := exec.LookPath("udhcpc"); err == nil {
		out, err := exec.Command("ip", "netns", "exec", c.NS,
			"udhcpc", "-i", c.MVName, "-n", "-q", "-t", "5", "-T", "3").CombinedOutput()
		if err != nil {
			return fmt.Errorf("udhcpc: %v (%s)", err, strings.TrimSpace(string(out)))
		}
		return nil
	}
	// dhclient كبديل
	if _, err := exec.LookPath("dhclient"); err == nil {
		out, err := exec.Command("ip", "netns", "exec", c.NS,
			"dhclient", "-1", "-timeout", "15", c.MVName).CombinedOutput()
		if err != nil {
			return fmt.Errorf("dhclient: %v (%s)", err, strings.TrimSpace(string(out)))
		}
		return nil
	}
	return fmt.Errorf("لا udhcpc ولا dhclient مثبّت")
}

func (c Card) hasIPv4() bool {
	out, err := ipRun("netns", "exec", c.NS, "ip", "-4", "addr", "show", "dev", c.MVName)
	if err != nil {
		return false
	}
	return strings.Contains(out, "inet ")
}

// Teardown يزيل namespace الكرت وكل ما فيه.
func (c Card) Teardown() {
	_, _ = ipRun("netns", "del", c.NS)
}
