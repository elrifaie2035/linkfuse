package manager

import (
	"os"
	"path/filepath"
	"testing"
)

func TestLoadStockReturnsLocallyRejectedCards(t *testing.T) {
	p := filepath.Join(t.TempDir(), "stock.json")
	data := `{"cards":[
	 {"id":1,"username":"a","status":"bad","fails":2,"last_error":"namespace: ip link set lft1 address x: exit status 2 (RTNETLINK answers: Address already in use)"},
	 {"id":2,"username":"b","status":"bad","fails":2,"last_error":"hotspot login: invalid password"}]}`
	if err := os.WriteFile(p, []byte(data), 0600); err != nil {
		t.Fatal(err)
	}
	st := loadStock(p)
	if st.Cards[0].Status != StUnused || st.Cards[0].Fails != 0 {
		t.Fatalf("local error card not returned: %+v", st.Cards[0])
	}
	if st.Cards[1].Status != StBad {
		t.Fatalf("provider-rejected card must stay bad: %+v", st.Cards[1])
	}
}
