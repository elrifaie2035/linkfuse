//go:build linux

// Package tundev يفتح جهاز TUN على لينكس مباشرةً عبر ioctl، بلا أي مكتبة خارجية.
// جهاز TUN يسلّم حزم IP الخام (الطبقة 3): نقرأ منه ما يريد النظام إرساله للإنترنت،
// ونكتب فيه ما يعود من النفق فيظهر للنظام كأنه وصل من الشبكة.
package tundev

import (
	"bytes"
	"fmt"
	"os"
	"syscall"
	"unsafe"
)

const (
	iffTun    = 0x0001     // جهاز طبقة 3 (حزم IP)
	iffNoPI   = 0x1000     // بلا بادئة بروتوكول (4 بايت) — نتعامل مع IP خاماً
	tunSetIff = 0x400454ca // ioctl TUNSETIFF على لينكس
)

// Device يمثّل جهاز TUN مفتوحاً.
type Device struct {
	f    *os.File
	Name string // الاسم الفعلي (مثلاً lf0)
}

// Open يفتح /dev/net/tun ويربطه باسم الواجهة المطلوب (أو يترك النظام يسمّيه إن كان فارغاً).
// بعد النجاح على المتصل أن يضبط عنوان الواجهة وتشغيلها عبر `ip addr`/`ip link`.
func Open(name string) (*Device, error) {
	// Open as a raw fd first: Go's poller cannot register a TUN fd before TUNSETIFF,
	// which makes os.OpenFile return a "not pollable" file (reads then fail).
	fd, err := syscall.Open("/dev/net/tun", syscall.O_RDWR|syscall.O_CLOEXEC, 0)
	if err != nil {
		return nil, fmt.Errorf("open /dev/net/tun: %w (are you root and is the tun module loaded?)", err)
	}

	// struct ifreq (40 bytes): name in the first 16 bytes, uint16 flags after it.
	var req [40]byte
	if len(name) >= 16 {
		syscall.Close(fd)
		return nil, fmt.Errorf("interface name too long: %q", name)
	}
	copy(req[:15], name)
	flags := uint16(iffTun | iffNoPI)
	req[16] = byte(flags)
	req[17] = byte(flags >> 8)

	_, _, errno := syscall.Syscall(
		syscall.SYS_IOCTL, uintptr(fd), uintptr(tunSetIff), uintptr(unsafe.Pointer(&req)),
	)
	if errno != 0 {
		syscall.Close(fd)
		return nil, fmt.Errorf("TUNSETIFF: %w", errno)
	}
	// Now the device is attached and pollable: hand it to Go's poller in non-blocking mode.
	if err := syscall.SetNonblock(fd, true); err != nil {
		syscall.Close(fd)
		return nil, fmt.Errorf("set nonblock: %w", err)
	}
	f := os.NewFile(uintptr(fd), "/dev/net/tun")

	got := string(bytes.TrimRight(req[:16], "\x00"))
	return &Device{f: f, Name: got}, nil
}

// Read يقرأ حزمة IP واحدة من الجهاز إلى p ويُعيد طولها.
func (d *Device) Read(p []byte) (int, error) { return d.f.Read(p) }

// Write يكتب حزمة IP واحدة إلى الجهاز.
func (d *Device) Write(p []byte) (int, error) { return d.f.Write(p) }

// Close يغلق الجهاز (تُزال الواجهة تلقائياً).
func (d *Device) Close() error { return d.f.Close() }
