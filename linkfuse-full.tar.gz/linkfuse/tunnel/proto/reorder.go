package proto

import "time"

// ReorderBuffer يعيد ترتيب حزم DATA الواصلة من عدّة مسارات إلى تسلسلها الأصلي
// قبل كتابتها على جهاز TUN. ضروري لأن كل كرت له تأخير مختلف، فتصل الحزم مبعثرة.
//
// غير آمن للتوازي عمداً: يُدار من goroutine واحدة فقط (التي تكتب على TUN).
// هذا يلغي الحاجة للأقفال في المسار الساخن ويجعل المنطق قابلاً للاختبار بدقّة.
//
// سياسة رأس الطابور (head-of-line):
//   - الحزمة المنتظَرة بالضبط (Seq == next) تُسلَّم فوراً ثم نُفرّغ المتجاور بعدها.
//   - الأحدث (Seq > next) تُخزَّن مؤقتاً بانتظار سدّ الفجوة.
//   - الأقدم (Seq < next) متأخرة/مكرّرة فتُسقَط (إعادة إدخالها تضرّ TCP).
//   - إن طال انتظار الفجوة أكثر من MaxHold، أو امتلأ المخزن، نعلن الحزمة
//     الناقصة مفقودة ونقفز إلى أصغر تسلسل مخزَّن (نُسلّم بدل أن نجمّد التدفّق).
type ReorderBuffer struct {
	next    uint64 // التسلسل التالي المتوقَّع
	started bool

	buf map[uint64][]byte // الحزم المبكّرة المخزّنة مؤقتاً (نُسَخ مملوكة)
	ts  map[uint64]time.Time

	maxHold  time.Duration
	capacity int

	deliver func([]byte) // يُكتب على TUN

	// إحصاءات تراكمية
	Delivered uint64
	Reordered uint64 // سُلّمت بعد أن كانت مخزّنة (أي وصلت مبكّرة)
	Lost      uint64 // فجوات أُعلنت مفقودة
	Late      uint64 // وصلت متأخرة جداً فأُسقطت
}

// NewReorderBuffer: maxHold مهلة انتظار الحزمة الناقصة (مثلاً 40ms)،
// capacity أقصى عدد حزم مخزّنة قبل القفز القسري، deliver دالة الكتابة على TUN.
func NewReorderBuffer(maxHold time.Duration, capacity int, deliver func([]byte)) *ReorderBuffer {
	return &ReorderBuffer{
		buf:      make(map[uint64][]byte, capacity),
		ts:       make(map[uint64]time.Time, capacity),
		maxHold:  maxHold,
		capacity: capacity,
		deliver:  deliver,
	}
}

// Push يُدخل حزمة واصلة. data تشير إلى مخزن مؤقت مُعاد الاستخدام، لذا نَنسخ
// عند التخزين. now وقت الوصول (يُمرَّر لتسهيل الاختبار).
func (r *ReorderBuffer) Push(seq uint64, data []byte, now time.Time) {
	if !r.started {
		r.next = seq
		r.started = true
	}

	switch {
	case seq == r.next:
		r.deliver(data)
		r.Delivered++
		r.next++
		r.drainContiguous()

	case seq > r.next:
		if _, dup := r.buf[seq]; dup {
			return // مكرّرة مبكّرة
		}
		cp := make([]byte, len(data))
		copy(cp, data)
		r.buf[seq] = cp
		r.ts[seq] = now
		if len(r.buf) > r.capacity {
			r.forceAdvance()
		}

	default: // seq < r.next
		// A large backward jump means the peer restarted (its sequence reset to 0).
		// Resync to the new sequence instead of dropping everything forever.
		if r.next-seq > uint64(r.capacity)*4+1024 {
			r.buf = map[uint64][]byte{}
			r.ts = map[uint64]time.Time{}
			r.next = seq + 1
			r.deliver(data)
			r.Delivered++
			return
		}
		r.Late++
	}
}

// drainContiguous يُسلّم كل الحزم المتتابعة المخزّنة ابتداءً من next.
func (r *ReorderBuffer) drainContiguous() {
	for {
		d, ok := r.buf[r.next]
		if !ok {
			return
		}
		r.deliver(d)
		r.Delivered++
		r.Reordered++
		delete(r.buf, r.next)
		delete(r.ts, r.next)
		r.next++
	}
}

// Tick يُستدعى دورياً: إن تجاوزت أقدم فجوة مهلةَ MaxHold، نعلنها مفقودة ونتقدّم.
func (r *ReorderBuffer) Tick(now time.Time) {
	if len(r.buf) == 0 {
		return
	}
	// أقدم حزمة مخزّنة: لو مضى عليها أكثر من MaxHold فالفجوة أمامها ضائعة.
	oldest := r.minSeq()
	if t, ok := r.ts[oldest]; ok && now.Sub(t) >= r.maxHold {
		r.jumpTo(oldest)
	}
}

func (r *ReorderBuffer) forceAdvance() {
	r.jumpTo(r.minSeq())
}

// jumpTo يُعلن كل ما بين next وtarget مفقوداً، ثم يُسلّم ابتداءً من target.
func (r *ReorderBuffer) jumpTo(target uint64) {
	if target <= r.next {
		return
	}
	r.Lost += target - r.next
	r.next = target
	if d, ok := r.buf[r.next]; ok {
		r.deliver(d)
		r.Delivered++
		delete(r.buf, r.next)
		delete(r.ts, r.next)
		r.next++
	}
	r.drainContiguous()
}

func (r *ReorderBuffer) minSeq() uint64 {
	var min uint64
	first := true
	for s := range r.buf {
		if first || s < min {
			min, first = s, false
		}
	}
	return min
}
