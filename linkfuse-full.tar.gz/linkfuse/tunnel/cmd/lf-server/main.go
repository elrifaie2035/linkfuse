// lf-server: طرف الدمج على الـ VPS.
//
// التشغيل:  lf-server -config /etc/linkfuse/server.json
//
// يفتح جهاز TUN (فيُنشئه)، يضبط عنوانه وتشغيله، ثم يشغّل حلقات الدمج.
// تفعيل ip_forward وقاعدة MASQUERADE يتمّان من سكربت النشر (deploy/vps-setup.sh).
package main

import (
	"encoding/json"
	"flag"
	"log"
	"os"
	"os/exec"
	"strconv"
	"time"

	"github.com/linkfuse/tunnel/server"
)

type fileConfig struct {
	Listen       string `json:"listen"`
	TunName      string `json:"tun"`
	TunAddr      string `json:"tun_addr"`
	MTU          int    `json:"mtu"`
	PSK          string `json:"psk"`
	BaseKbps     int    `json:"base_kbps"`
	ReorderHold  int    `json:"reorder_hold_ms"`
	ReorderCap   int    `json:"reorder_cap"`
	KeepaliveInt int    `json:"keepalive_ms"`
	PathTimeout  int    `json:"path_timeout_ms"`
	APIListen    string `json:"api_listen"`
	APIToken     string `json:"api_token"`
	ShapePercent int    `json:"shape_percent"` // CAKE limit as % of live cards' capacity; 0 = off
	ShapeRTTms   int    `json:"shape_rtt_ms"`
}

func main() {
	cfgPath := flag.String("config", "/etc/linkfuse/server.json", "path to JSON config file")
	flag.Parse()

	fc := loadConfig(*cfgPath)

	srv, err := server.New(server.Config{
		Listen:       fc.Listen,
		TunName:      fc.TunName,
		PSK:          fc.PSK,
		BaseKbps:     fc.BaseKbps,
		ReorderHold:  time.Duration(fc.ReorderHold) * time.Millisecond,
		ReorderCap:   fc.ReorderCap,
		KeepaliveInt: time.Duration(fc.KeepaliveInt) * time.Millisecond,
		PathTimeout:  time.Duration(fc.PathTimeout) * time.Millisecond,
	})
	if err != nil {
		log.Fatalf("server init: %v", err)
	}

	// الجهاز صار موجوداً الآن (أنشأه Open) — نضبط عنوانه وMTU ونشغّله.
	setupTun(fc.TunName, fc.TunAddr, fc.MTU)

	if fc.APIListen != "" {
		go func() {
			if err := srv.ServeAPI(fc.APIListen, fc.APIToken); err != nil {
				log.Printf("[lf-server] usage API stopped: %v", err)
			}
		}()
	}

	go srv.ShapeLoop(fc.ShapePercent, fc.ShapeRTTms)

	log.Println("[lf-server] running")
	srv.Run()
}

func loadConfig(path string) fileConfig {
	b, err := os.ReadFile(path)
	if err != nil {
		log.Fatalf("read config %s: %v", path, err)
	}
	fc := fileConfig{
		Listen: ":51820", TunName: "lf0", TunAddr: "10.9.0.1/24", MTU: 1400,
		BaseKbps: 2000, ShapePercent: 92, ShapeRTTms: 100, ReorderHold: 40, ReorderCap: 4096, KeepaliveInt: 1000, PathTimeout: 5000,
	}
	if err := json.Unmarshal(b, &fc); err != nil {
		log.Fatalf("parse config: %v", err)
	}
	if fc.PSK == "" {
		log.Fatal("psk is required in config")
	}
	return fc
}

func setupTun(name, addr string, mtu int) {
	run("ip", "addr", "add", addr, "dev", name)
	run("ip", "link", "set", "dev", name, "mtu", strconv.Itoa(mtu))
	run("ip", "link", "set", "dev", name, "up")
}

func run(args ...string) {
	if out, err := exec.Command(args[0], args[1:]...).CombinedOutput(); err != nil {
		log.Printf("[setup] %v: %v (%s)", args, err, string(out))
	}
}
