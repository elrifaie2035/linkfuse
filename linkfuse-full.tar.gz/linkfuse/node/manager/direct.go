package manager

import (
	"context"
	"log"
	"net"
	"os/exec"
	"sort"
	"strings"
	"sync"
	"time"
)

// Direct ("bypass") sites: traffic from the LAN to these domains does not go
// through the tunnel; it leaves directly through the node's own local
// internet (direct_iface, e.g. ens18), so local payment/bank sites see a
// local address. Implemented with one "to IP lookup main" rule per resolved
// address at priority 90, before the LAN -> tunnel rule (priority 100).

const directRulePref = "90"

type directState struct {
	mu       sync.Mutex
	lastSeen map[string]time.Time // ip -> last time a domain resolved to it
	byDomain map[string][]string  // domain -> current IPs (for the panel)
	applied  map[string]bool      // ip -> rule installed
	kick     chan struct{}
	runFn    func(args ...string) error
	lookupFn func(ctx context.Context, host string) []string
}

func newDirectState() *directState {
	d := &directState{
		lastSeen: map[string]time.Time{},
		byDomain: map[string][]string{},
		applied:  map[string]bool{},
		kick:     make(chan struct{}, 1),
	}
	d.runFn = func(args ...string) error { return exec.Command(args[0], args[1:]...).Run() }
	d.lookupFn = lookupAll
	return d
}

// lookupAll resolves a name through the system resolver and through public
// resolvers, and returns the union of IPv4 addresses (sites behind a CDN may
// answer differently depending on who asks).
func lookupAll(ctx context.Context, host string) []string {
	set := map[string]bool{}
	add := func(r *net.Resolver) {
		c, cancel := context.WithTimeout(ctx, 4*time.Second)
		defer cancel()
		ips, err := r.LookupIP(c, "ip4", host)
		if err != nil {
			return
		}
		for _, ip := range ips {
			set[ip.String()] = true
		}
	}
	add(net.DefaultResolver)
	for _, srv := range []string{"1.1.1.1:53", "8.8.8.8:53"} {
		srv := srv
		add(&net.Resolver{PreferGo: true, Dial: func(ctx context.Context, network, _ string) (net.Conn, error) {
			d := net.Dialer{Timeout: 3 * time.Second}
			return d.DialContext(ctx, "udp", srv)
		}})
	}
	out := make([]string, 0, len(set))
	for ip := range set {
		out = append(out, ip)
	}
	sort.Strings(out)
	return out
}

// normalizeDomains trims, lower-cases, strips "http(s)://" and paths, drops empties/duplicates.
func normalizeDomains(in []string) []string {
	seen := map[string]bool{}
	var out []string
	for _, d := range in {
		d = strings.ToLower(strings.TrimSpace(d))
		d = strings.TrimPrefix(strings.TrimPrefix(d, "https://"), "http://")
		if i := strings.IndexAny(d, "/:"); i >= 0 {
			d = d[:i]
		}
		d = strings.TrimSuffix(strings.TrimPrefix(d, "*."), ".")
		if d == "" || seen[d] {
			continue
		}
		seen[d] = true
		out = append(out, d)
	}
	return out
}

// DirectInfo is shown in the panel.
type DirectInfo struct {
	Domains []string            `json:"domains"`
	IPs     map[string][]string `json:"ips"`
	Iface   string              `json:"iface"`
}

func (m *Manager) direct() *directState {
	m.directOnce.Do(func() { m.directSt = newDirectState() })
	return m.directSt
}

func (m *Manager) DirectInfo() DirectInfo {
	d := m.direct()
	m.mu.Lock()
	info := DirectInfo{Domains: append([]string{}, m.cfg.DirectDomains...), Iface: m.cfg.DirectIface}
	m.mu.Unlock()
	d.mu.Lock()
	info.IPs = map[string][]string{}
	for k, v := range d.byDomain {
		info.IPs[k] = append([]string{}, v...)
	}
	d.mu.Unlock()
	if info.Domains == nil {
		info.Domains = []string{}
	}
	return info
}

// SetDirectDomains replaces the list (from the panel) and refreshes now.
func (m *Manager) SetDirectDomains(domains []string) []string {
	clean := normalizeDomains(domains)
	m.mu.Lock()
	m.cfg.DirectDomains = clean
	m.mu.Unlock()
	m.persist()
	select {
	case m.direct().kick <- struct{}{}:
	default:
	}
	log.Printf("[direct] %d sites go direct (not through the tunnel)", len(clean))
	return clean
}

// DirectLoop sets up NAT for the direct path once, then re-resolves the
// domains every interval (or when the list changes) and syncs the rules.
func (m *Manager) DirectLoop(lanIf, subnet string, interval time.Duration) {
	if lanIf == "" || subnet == "" {
		return
	}
	d := m.direct()
	m.mu.Lock()
	iface := m.cfg.DirectIface
	m.mu.Unlock()
	if iface == "" {
		iface = defaultRouteDev()
		m.mu.Lock()
		m.cfg.DirectIface = iface
		m.mu.Unlock()
	}
	if iface == "" {
		log.Println("[direct] no default route on the node: direct sites disabled")
		return
	}
	// leftovers from a previous run
	for i := 0; i < 1000 && d.runFn("ip", "rule", "del", "pref", directRulePref) == nil; i++ {
	}
	iptEnsure("-t", "nat", "POSTROUTING", "-s", subnet, "-o", iface, "-j", "MASQUERADE")
	iptEnsure("FORWARD", "-i", lanIf, "-o", iface, "-j", "ACCEPT")
	iptEnsure("FORWARD", "-i", iface, "-o", lanIf, "-m", "conntrack", "--ctstate", "RELATED,ESTABLISHED", "-j", "ACCEPT")
	iptEnsure("-t", "mangle", "FORWARD", "-o", iface, "-p", "tcp", "--tcp-flags", "SYN,RST", "SYN", "-j", "TCPMSS", "--clamp-mss-to-pmtu")
	log.Printf("[direct] direct sites leave through %s", iface)
	for {
		m.syncDirect(time.Now())
		select {
		case <-time.After(interval):
		case <-d.kick:
		}
	}
}

// syncDirect resolves all domains and installs/removes "to IP" rules.
// An address stays routed directly for an hour after it was last seen, so
// open connections are not moved into the tunnel when DNS rotates.
func (m *Manager) syncDirect(now time.Time) {
	d := m.direct()
	m.mu.Lock()
	domains := append([]string{}, m.cfg.DirectDomains...)
	m.mu.Unlock()

	byDomain := map[string][]string{}
	for _, dom := range domains {
		byDomain[dom] = d.lookupFn(context.Background(), dom)
	}

	d.mu.Lock()
	defer d.mu.Unlock()
	d.byDomain = byDomain
	wanted := map[string]bool{}
	for _, ips := range byDomain {
		for _, ip := range ips {
			d.lastSeen[ip] = now
		}
	}
	for ip, t := range d.lastSeen {
		if now.Sub(t) <= time.Hour && len(domains) > 0 {
			wanted[ip] = true
		} else {
			delete(d.lastSeen, ip)
		}
	}
	// a domain removed from the list: drop its addresses right away
	if len(domains) == 0 {
		wanted = map[string]bool{}
	}
	for ip := range wanted {
		if !d.applied[ip] {
			if d.runFn("ip", "rule", "add", "to", ip+"/32", "lookup", "main", "pref", directRulePref) == nil {
				d.applied[ip] = true
			}
		}
	}
	for ip := range d.applied {
		if !wanted[ip] {
			_ = d.runFn("ip", "rule", "del", "to", ip+"/32", "lookup", "main", "pref", directRulePref)
			delete(d.applied, ip)
		}
	}
}

func defaultRouteDev() string {
	out, err := exec.Command("ip", "route", "show", "default").Output()
	if err != nil {
		return ""
	}
	f := strings.Fields(string(out))
	for i := 0; i+1 < len(f); i++ {
		if f[i] == "dev" {
			return f[i+1]
		}
	}
	return ""
}

// iptEnsure adds an iptables rule only if it is not present yet.
// args: [-t table] CHAIN rule...
func iptEnsure(args ...string) {
	var table []string
	if args[0] == "-t" {
		table, args = args[:2], args[2:]
	}
	chain, rule := args[0], args[1:]
	check := append(append(append([]string{}, table...), "-C", chain), rule...)
	if exec.Command("iptables", check...).Run() == nil {
		return
	}
	add := append(append(append([]string{}, table...), "-A", chain), rule...)
	if out, err := exec.Command("iptables", add...).CombinedOutput(); err != nil {
		log.Printf("[direct] iptables %v: %v (%s)", add, err, strings.TrimSpace(string(out)))
	}
}
