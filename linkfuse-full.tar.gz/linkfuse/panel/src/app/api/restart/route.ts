import { nodeFetch } from "@/lib/api";
export const dynamic = "force-dynamic";
export async function POST() {
  try {
    const r = await nodeFetch("/api/restart", { method: "POST", body: "{}" });
    return new Response(await r.text(), { status: r.status, headers: { "Content-Type": "application/json" } });
  } catch (e: any) {
    return Response.json({ error: `تعذّر الوصول للعقدة: ${e.message}` }, { status: 502 });
  }
}
