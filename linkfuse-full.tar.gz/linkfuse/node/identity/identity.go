// Package identity يولّد هوية هاتف وهمية لكل كرت: عنوان MAC ببادئة OUI لشركة
// حقيقية + اسم جهاز واقعي، فتبدو كل جلسة عند المزوّد كهاتف مختلف — نفس أسلوب Octopus.
package identity

import (
	"crypto/rand"
	"fmt"
)

// vendor بادئة OUI (أول 3 بايت) لشركة + موديلات هواتفها الشائعة.
type vendor struct {
	oui    [3]byte
	models []string
}

// بادئات OUI حقيقية مُسجّلة لكل شركة (مصدرها قوائم IEEE العامة).
var vendors = []vendor{
	{[3]byte{0xF0, 0x18, 0x98}, []string{"iPhone 13", "iPhone 14", "iPhone 14 Pro Max", "iPhone 15", "iPhone 15 Pro"}}, // Apple
	{[3]byte{0xA4, 0x83, 0xE7}, []string{"iPhone 12", "iPhone 13 Pro", "iPhone SE", "iPad Air"}},                       // Apple
	{[3]byte{0xDC, 0xA6, 0x32}, []string{"Galaxy S23", "Galaxy S24 Ultra", "Galaxy A54", "Galaxy A34"}},                // Samsung
	{[3]byte{0x8C, 0x77, 0x12}, []string{"Galaxy S22", "Galaxy M14", "Galaxy A14", "Galaxy Note 20"}},                  // Samsung
	{[3]byte{0x50, 0x8F, 0x4C}, []string{"Redmi Note 12", "Redmi Note 13 Pro", "Mi 11", "Poco X5"}},                    // Xiaomi
	{[3]byte{0x64, 0xB4, 0x73}, []string{"Redmi 10", "Redmi Note 11", "Poco F5", "Mi 12"}},                             // Xiaomi
	{[3]byte{0x48, 0x5F, 0x99}, []string{"Nova 11", "P60 Pro", "Mate 50", "Y9a"}},                                      // Huawei
	{[3]byte{0x34, 0x12, 0xF9}, []string{"Reno 8", "A78", "Find X6", "A96"}},                                           // Oppo
}

// أسماء أولى شائعة لتركيب اسم الجهاز (مثل "Omar iPhone 14 Pro Max").
var firstNames = []string{
	"Omar", "Nawaf", "Ahmad", "Yousef", "Khaled", "Saeed", "Faisal", "Majed",
	"Salem", "Tariq", "Rami", "Sami", "Hani", "Ziad", "Mazen", "Anas",
	"Laith", "Bilal", "Karim", "Nader", "Wael", "Fadi", "Ghassan", "Osama",
}

// Identity هوية كرت واحد.
type Identity struct {
	MAC        string // "f0:18:98:ab:cd:ef"
	DeviceName string // "Omar iPhone 14 Pro Max"
}

func randByte() byte {
	var b [1]byte
	_, _ = rand.Read(b[:])
	return b[0]
}

func pick[T any](s []T) T {
	return s[int(randByte())%len(s)]
}

// Generate يولّد هوية عشوائية متّسقة (الموديل يطابق شركة الـ OUI).
func Generate() Identity {
	v := pick(vendors)
	suffix := [3]byte{randByte(), randByte(), randByte()}
	mac := fmt.Sprintf("%02x:%02x:%02x:%02x:%02x:%02x",
		v.oui[0], v.oui[1], v.oui[2], suffix[0], suffix[1], suffix[2])
	name := fmt.Sprintf("%s %s", pick(firstNames), pick(v.models))
	return Identity{MAC: mac, DeviceName: name}
}

// GenerateFor يولّد هوية ثابتة مشتقّة من بذرة (مثلاً معرّف الكرت) فتبقى نفسها
// عبر عمليات التشغيل — مفيد كي لا يرى المزوّد الجهاز يغيّر هويته كل إقلاع.
func GenerateFor(seed uint64) Identity {
	v := vendors[seed%uint64(len(vendors))]
	s := seed * 2654435761 // خلط بسيط
	mac := fmt.Sprintf("%02x:%02x:%02x:%02x:%02x:%02x",
		v.oui[0], v.oui[1], v.oui[2], byte(s>>16), byte(s>>8), byte(s))
	name := fmt.Sprintf("%s %s",
		firstNames[(seed/7)%uint64(len(firstNames))],
		v.models[(seed/3)%uint64(len(v.models))])
	return Identity{MAC: mac, DeviceName: name}
}
