module github.com/linkfuse/node

go 1.24.7

require github.com/linkfuse/tunnel v0.0.0

replace github.com/linkfuse/tunnel => ../tunnel
