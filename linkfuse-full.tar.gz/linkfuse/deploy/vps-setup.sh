#!/usr/bin/env bash
# إعداد خادم الدمج على الـ VPS (فرانكفورت). شغّله مرّة بصلاحية root.
set -e
WAN_IF="${1:-eth0}"       # واجهة خروج الـ VPS للإنترنت
TUN_SUBNET="10.9.0.0/24"  # شبكة النفق
UDP_PORT="${2:-51820}"

echo "[+] تفعيل تمرير الحزم"
sysctl -w net.ipv4.ip_forward=1
grep -q 'net.ipv4.ip_forward=1' /etc/sysctl.conf || echo 'net.ipv4.ip_forward=1' >> /etc/sysctl.conf

echo "[+] NAT لشبكة النفق عبر $WAN_IF"
iptables -t nat -C POSTROUTING -s "$TUN_SUBNET" -o "$WAN_IF" -j MASQUERADE 2>/dev/null || \
  iptables -t nat -A POSTROUTING -s "$TUN_SUBNET" -o "$WAN_IF" -j MASQUERADE

echo "[+] السماح بمنفذ النفق UDP/$UDP_PORT"
iptables -C INPUT -p udp --dport "$UDP_PORT" -j ACCEPT 2>/dev/null || \
  iptables -A INPUT -p udp --dport "$UDP_PORT" -j ACCEPT

# MSS clamping يمنع مشاكل أحجام الحزم عبر النفق
iptables -t mangle -C FORWARD -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --clamp-mss-to-pmtu 2>/dev/null || \
  iptables -t mangle -A FORWARD -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --clamp-mss-to-pmtu

echo "[+] احفظ القواعد (netfilter-persistent أو iptables-save)"
command -v netfilter-persistent >/dev/null && netfilter-persistent save || iptables-save > /etc/iptables.rules
echo "[✓] تمّ. شغّل lf-server بعد وضع /etc/linkfuse/server.json"
