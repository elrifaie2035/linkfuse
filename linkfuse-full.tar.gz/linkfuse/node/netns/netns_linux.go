//go:build linux

// Package netns ينفّذ عمليات داخل network namespace محدّد (namespace الكرت).
// أهمّ استخدام: إنشاء سوكيت UDP للنفق *داخل* namespace الكرت، فيخرج عبر ذلك الكرت
// حصراً. السوكيت يُنشأ في الـ namespace الهدف ثم يبقى مربوطاً به حتى بعد العودة.
package netns

import (
	"fmt"
	"net"
	"os"
	"runtime"
	"syscall"
)

const cloneNewNet = 0x40000000 // CLONE_NEWNET

// Path يُعيد مسار ملف الـ namespace المُسمّى (كما ينشئه `ip netns add`).
func Path(name string) string { return "/var/run/netns/" + name }

func setns(fd int) error {
	_, _, errno := syscall.Syscall(uintptr(sysSetns), uintptr(fd), uintptr(cloneNewNet), 0)
	if errno != 0 {
		return errno
	}
	return nil
}

// Do ينفّذ fn بينما يكون الخيط الحالي داخل namespace المسار nsPath، ثم يعيد الخيط
// إلى namespace الأصلي. يقفل الخيط على goroutine واحدة طوال التنفيذ (ضروري لأن
// الـ namespace خاصية خيط لا عملية).
func Do(nsPath string, fn func() error) error {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()

	// نحفظ namespace الخيط الحالي كي نعود إليه.
	origin, err := os.Open("/proc/thread-self/ns/net")
	if err != nil {
		// بديل أقدم للنواة التي لا تدعم thread-self
		origin, err = os.Open("/proc/self/ns/net")
		if err != nil {
			return fmt.Errorf("فتح namespace الأصلي: %w", err)
		}
	}
	defer origin.Close()

	target, err := os.Open(nsPath)
	if err != nil {
		return fmt.Errorf("فتح namespace الكرت %s: %w", nsPath, err)
	}
	defer target.Close()

	if err := setns(int(target.Fd())); err != nil {
		return fmt.Errorf("الدخول إلى namespace الكرت: %w", err)
	}
	// مهما حدث، نعود إلى الأصلي قبل الخروج.
	defer func() { _ = setns(int(origin.Fd())) }()

	return fn()
}

// DialUDP يفتح سوكيت UDP موصولاً بـ server من داخل namespace الكرت nsPath.
// السوكيت يُنشأ داخل الـ namespace فيخرج عبر كرته، ويبقى صالحاً بعد العودة.
func DialUDP(nsPath, server string) (*net.UDPConn, error) {
	raddr, err := net.ResolveUDPAddr("udp", server)
	if err != nil {
		return nil, err
	}
	var conn *net.UDPConn
	err = Do(nsPath, func() error {
		c, derr := net.DialUDP("udp", nil, raddr)
		if derr != nil {
			return derr
		}
		_ = c.SetReadBuffer(4 << 20)
		_ = c.SetWriteBuffer(4 << 20)
		conn = c
		return nil
	})
	if err != nil {
		return nil, err
	}
	return conn, nil
}
