//go:build linux

package netns

import (
	"context"
	"fmt"
	"os"
	"os/exec"
	"strings"
	"time"
)

// Card يصف ما يلزم لتهيئة كرت داخل namespace خاص به.
type Card struct {
	NS     string // اسم الـ namespace، مثلاً "lfcard-3"
	Parent string // واجهة خط المزوّد (WAN)، مثلاً "ens19"
	MVName string // اسم واجهة MACVLAN داخل الـ namespace، مثلاً "lfm3"
	MAC    string // عنوان MAC الوهمي "f0:18:98:ab:cd:ef"
	// HostName / VendorClass are sent in DHCP instead of the VM's own host
	// name (Ubuntu's default dhclient.conf sends gethostname() for every card).
	HostName    string
	VendorClass string
}

func ipRun(args ...string) (string, error) {
	out, err := exec.Command("ip", args...).CombinedOutput()
	if err != nil {
		return string(out), fmt.Errorf("ip %s: %v (%s)", strings.Join(args, " "), err, strings.TrimSpace(string(out)))
	}
	return string(out), nil
}

// Setup يُنشئ namespace الكرت وواجهة MACVLAN بالـ MAC الوهمي ويُشغّلها.
// MACVLAN في وضع bridge يجعل المزوّد يرى كل كرت كجهاز مستقلّ بعنوانه الخاص.
//
// يطابق أسلوب Octopus حرفياً: promisc on على الأب وعلى واجهة الكرت،
// وrp_filter=0 داخل namespace — بدونهما تُسقَط حزم الإنترنت العائدة بصمت.
func (c Card) Setup() error {
	// ملاحظة: لا نضع promisc على الأب (ens19) — فهو يكسر DHCP في بيئة Proxmox.
	// نكتفي بوضع promisc على واجهة الكرت داخل namespace (أدناه).

	// namespace جديد (نتجاهل الخطأ إن كان موجوداً من تشغيل سابق بعد تنظيفه).
	_, _ = ipRun("netns", "add", c.NS)

	// MACVLAN على واجهة المزوّد في المجال الجذر، ثم ننقلها إلى namespace الكرت.
	tmp := c.tmpName()
	if out, err := ipRun("link", "add", "link", c.Parent, "name", tmp, "type", "macvlan", "mode", "bridge"); err != nil {
		return fmt.Errorf("create MACVLAN: %s", out)
	}
	// The same MAC may still be held for a few seconds by this card's previous
	// interface: a deleted namespace is destroyed only after its last process
	// (dhclient/pppd) exits and the kernel finishes cleaning it up.
	var macErr error
	for try := 0; try < 20; try++ {
		if _, macErr = ipRun("link", "set", tmp, "address", c.MAC); macErr == nil || !strings.Contains(macErr.Error(), "in use") {
			break
		}
		time.Sleep(500 * time.Millisecond)
	}
	if macErr != nil {
		_, _ = ipRun("link", "del", tmp)
		return macErr
	}
	if _, err := ipRun("link", "set", tmp, "netns", c.NS); err != nil {
		_, _ = ipRun("link", "del", tmp)
		return err
	}
	// داخل الـ namespace: نعيد التسمية ونُشغّل.
	if _, err := ipRun("netns", "exec", c.NS, "ip", "link", "set", tmp, "name", c.MVName); err != nil {
		return err
	}
	_, _ = ipRun("netns", "exec", c.NS, "ip", "link", "set", "lo", "up")
	if _, err := ipRun("netns", "exec", c.NS, "ip", "link", "set", c.MVName, "up"); err != nil {
		return err
	}
	// الوضع المختلط على واجهة الكرت داخل namespace.
	_, _ = ipRun("netns", "exec", c.NS, "ip", "link", "set", c.MVName, "promisc", "on")

	// إطفاء rp_filter داخل namespace (السبب الأكبر لعدم عودة الإنترنت).
	c.sysctlNS("net.ipv4.conf.all.rp_filter=0")
	c.sysctlNS("net.ipv4.conf.default.rp_filter=0")
	c.sysctlNS("net.ipv4.conf." + c.MVName + ".rp_filter=0")
	c.sysctlNS("net.ipv4.conf.all.src_valid_mark=1")
	return nil
}

// sysctlNS يضبط قيمة sysctl داخل namespace الكرت (يتجاهل الفشل).
func (c Card) sysctlNS(kv string) {
	_, _ = ipRun("netns", "exec", c.NS, "sysctl", "-w", kv)
}

// DHCP يطلب عنواناً من المزوّد داخل namespace الكرت مع إعادة محاولة (علاج dhcp_timeout).
// يجرّب udhcpc ثم dhclient حسب المتوفّر.
func (c Card) DHCP(retries int, wait time.Duration) error {
	if retries <= 0 {
		retries = 4
	}
	if wait == 0 {
		wait = 3 * time.Second
	}
	var lastErr error
	for i := 1; i <= retries; i++ {
		if err := c.dhcpOnce(); err != nil {
			lastErr = err
			time.Sleep(wait)
			continue
		}
		// نتأكّد أنه حصل على عنوان فعلاً.
		if c.hasIPv4() {
			return nil
		}
		lastErr = fmt.Errorf("no IPv4 address assigned")
		time.Sleep(wait)
	}
	return fmt.Errorf("DHCP failed for card %s after %d attempts: %w", c.NS, retries, lastErr)
}

func (c Card) dhcpOnce() error {
	// dhclient بملفات lease/pid منفصلة لكل كرت (كما يفعل Octopus) — يمنع تعارض
	// الكروت على ملف lease واحد، وهوية المضيف ثابتة لكل كرت.
	if _, err := exec.LookPath("dhclient"); err == nil {
		// Paths allowed by Ubuntu's AppArmor profile for dhclient
		// (/run/octopus-* is denied -> "Permission denied" and no lease renewal file).
		lease := "/var/lib/dhcp/dhclient-" + c.NS + ".leases"
		pid := "/run/dhclient-" + c.NS + ".pid"
		// ملاحظة: لا نستخدم -H (اسم المضيف) لأن ISC dhclient 4.4+ لا يدعمها.
		// Bound each attempt: a stuck dhclient (-1) would otherwise wait ~60 s.
		ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
		defer cancel()
		// Own config file per card: send the fake phone name, never the VM's.
		// (/var/lib/dhcp is readable by dhclient under AppArmor.)
		conf := "/var/lib/dhcp/dhclient-" + c.NS + ".conf"
		cf := "request subnet-mask, broadcast-address, time-offset, routers,\n" +
			"\tdomain-name, domain-name-servers, interface-mtu;\n"
		if c.HostName != "" {
			cf += fmt.Sprintf("send host-name \"%s\";\n", c.HostName)
		}
		if c.VendorClass != "" {
			cf += fmt.Sprintf("send vendor-class-identifier \"%s\";\n", c.VendorClass)
		}
		if err := os.WriteFile(conf, []byte(cf), 0644); err != nil {
			return fmt.Errorf("dhclient config: %w", err)
		}
		out, err := exec.CommandContext(ctx, "ip", "netns", "exec", c.NS,
			"dhclient", "-v", "-1", "-cf", conf, "-lf", lease, "-pf", pid, c.MVName).CombinedOutput()
		if err != nil {
			return fmt.Errorf("dhclient: %v (%s)", err, strings.TrimSpace(string(out)))
		}
		return nil
	}
	// udhcpc كبديل
	if _, err := exec.LookPath("udhcpc"); err == nil {
		out, err := exec.Command("ip", "netns", "exec", c.NS,
			"udhcpc", "-i", c.MVName, "-n", "-q", "-t", "5", "-T", "3").CombinedOutput()
		if err != nil {
			return fmt.Errorf("udhcpc: %v (%s)", err, strings.TrimSpace(string(out)))
		}
		return nil
	}
	return fmt.Errorf("neither dhclient nor udhcpc is installed")
}

// IPv4 يُعيد عنوان IPv4 المُسنَد لواجهة الكرت (أو فارغاً).
func (c Card) IPv4() (string, error) {
	out, err := ipRun("netns", "exec", c.NS, "ip", "-4", "-o", "addr", "show", "dev", c.MVName)
	if err != nil {
		return "", err
	}
	for _, f := range strings.Fields(out) {
		if strings.Contains(f, ".") && strings.Contains(f, "/") {
			return f, nil
		}
	}
	return "", nil
}

func (c Card) hasIPv4() bool {
	out, err := ipRun("netns", "exec", c.NS, "ip", "-4", "addr", "show", "dev", c.MVName)
	if err != nil {
		return false
	}
	return strings.Contains(out, "inet ")
}

// Teardown يزيل namespace الكرت وكل ما فيه، ويحذف أي واجهة MACVLAN عالقة
// في المجال الرئيسي من تشغيل سابق (تفادي خطأ "Address already in use").
func (c Card) Teardown() {
	c.StopPPPoE()
	// Stop this card's dhclient first: a process left inside the namespace
	// keeps it (and its MAC) alive after "ip netns del".
	_ = exec.Command("pkill", "-f", "dhclient-"+c.NS+"[.]").Run()
	_, _ = ipRun("netns", "del", c.NS)
	// الواجهة المؤقّتة قد تبقى في المجال الرئيسي إن فشل التشغيل السابق.
	tmp := c.tmpName()
	_, _ = ipRun("link", "del", tmp)
	_, _ = ipRun("link", "del", c.MVName)
	// نوقف أي dhclient عالق على هذا الكرت (يحمل العنوان المحجوز).
	_ = exec.Command("pkill", "-f", "dhclient-"+c.NS+"[.]").Run()
}

// PPPoE starts a PPPoE session (pppd, rp-pppoe plugin) on the card's MACVLAN
// inside its namespace, so the line is dialled with the fake router MAC.
// Credentials go into a root-only peers file (not on the command line).
// Waits until the link has an IPv4 address and a default route.
func (c Card) PPPoE(user, pass string, timeout time.Duration) error {
	if _, err := exec.LookPath("pppd"); err != nil {
		return fmt.Errorf("pppd is not installed (sudo apt install ppp)")
	}
	peer := "lf-" + c.NS
	conf := fmt.Sprintf(`plugin rp-pppoe.so
nic-%s
user "%s"
password "%s"
noauth
defaultroute
noipdefault
persist
maxfail 0
holdoff 5
mtu 1492
mru 1492
lcp-echo-interval 10
lcp-echo-failure 3
linkname %s
`, c.MVName, escapePPP(user), escapePPP(pass), peer)
	if err := os.MkdirAll("/etc/ppp/peers", 0755); err != nil {
		return err
	}
	if err := os.WriteFile("/etc/ppp/peers/"+peer, []byte(conf), 0600); err != nil {
		return fmt.Errorf("write peers file: %w", err)
	}
	c.StopPPPoE()
	// pppd daemonises by itself; "persist" makes it redial when the line drops.
	if out, err := exec.Command("ip", "netns", "exec", c.NS, "pppd", "call", peer).CombinedOutput(); err != nil {
		return fmt.Errorf("pppd: %v (%s)", err, strings.TrimSpace(string(out)))
	}
	deadline := time.Now().Add(timeout)
	for time.Now().Before(deadline) {
		time.Sleep(time.Second)
		out, _ := ipRun("netns", "exec", c.NS, "ip", "-4", "-o", "addr", "show")
		if strings.Contains(out, " ppp") {
			r, _ := ipRun("netns", "exec", c.NS, "ip", "route", "show", "default")
			if strings.Contains(r, "ppp") {
				return nil
			}
		}
	}
	c.StopPPPoE()
	return fmt.Errorf("PPPoE did not connect within %s (wrong username/password or no PPPoE server)", timeout)
}

// StopPPPoE ends the session (pppd sends PADT on SIGTERM).
func (c Card) StopPPPoE() {
	if exec.Command("pkill", "-TERM", "-f", "pppd call lf-"+c.NS+"$").Run() == nil {
		time.Sleep(500 * time.Millisecond)
	}
}

// PPPoEIPv4 returns the address on the ppp interface.
func (c Card) PPPoEIPv4() string {
	out, _ := ipRun("netns", "exec", c.NS, "ip", "-4", "-o", "addr", "show")
	for _, line := range strings.Split(out, "\n") {
		if strings.Contains(line, " ppp") {
			for _, f := range strings.Fields(line) {
				if strings.Contains(f, ".") && strings.Contains(f, "/") {
					return f
				}
			}
		}
	}
	return ""
}

func escapePPP(s string) string {
	return strings.NewReplacer(`\`, `\\`, `"`, `\"`).Replace(s)
}

// tmpName is the short temporary MACVLAN name used before the interface moves
// into the namespace. Linux limits interface names to 15 characters, so it is
// derived from MVName ("lfm1001" -> "lft1001"), not from the namespace name.
func (c Card) tmpName() string {
	return "lft" + strings.TrimPrefix(c.MVName, "lfm")
}
