package netns

import "testing"

func TestInterfaceNamesFitLinuxLimit(t *testing.T) {
	for _, id := range []string{"1", "99", "100", "1001", "65535"} {
		c := Card{NS: "lfcard-" + id, MVName: "lfm" + id}
		for _, n := range []string{c.tmpName(), c.MVName} {
			if len(n) > 15 {
				t.Errorf("interface name %q is longer than 15 characters", n)
			}
		}
	}
}
