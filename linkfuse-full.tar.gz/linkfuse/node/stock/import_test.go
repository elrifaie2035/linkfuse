package stock

import (
	"os"
	"testing"
)

func TestDurationHours(t *testing.T) {
	cases := map[string]float64{
		"اشتراك يومي 8 ساعات 2 ميجا": 8,
		"اشتراك شهري 2 ميجا":         720,
		"اشتراك اسبوعي":              168,
		"باقة 3 أيام":                72,
		"":                           0,
	}
	for in, want := range cases {
		if got := DurationHours(in); got != want {
			t.Errorf("%q: got %v want %v", in, got, want)
		}
	}
}

func TestParseText(t *testing.T) {
	rep, err := Parse([]byte("Username Password\n111111111111 123456\n222222222222:654321 شهري\n333333333333\n111111111111 999999\n"))
	if err != nil {
		t.Fatal(err)
	}
	if len(rep.Entries) != 2 || len(rep.MissingPassword) != 1 {
		t.Fatalf("got %+v", rep)
	}
	if rep.Entries[1].DurationH != 720 {
		t.Fatalf("monthly duration: %v", rep.Entries[1].DurationH)
	}
}

// Real provider export, path given by LF_XLSX (not committed: it holds credentials).
func TestParseProviderXLSX(t *testing.T) {
	p := os.Getenv("LF_XLSX")
	if p == "" {
		t.Skip("LF_XLSX not set")
	}
	b, err := os.ReadFile(p)
	if err != nil {
		t.Fatal(err)
	}
	rep, err := Parse(b)
	if err != nil {
		t.Fatal(err)
	}
	t.Logf("rows=%d entries=%d missing=%d", rep.Rows, len(rep.Entries), len(rep.MissingPassword))
	for _, e := range rep.Entries {
		if len(e.Username) != 12 || e.DurationH != 8 || e.Password == "" {
			t.Errorf("bad entry %+v", e)
		}
	}
	if len(rep.Entries)+len(rep.MissingPassword) != 50 {
		t.Errorf("expected 50 cards total")
	}
}
