package hotspot

import (
	"crypto/md5"
	"encoding/hex"
	"strings"
	"testing"
)

// صفحة دخول MikroTik مبسّطة للاختبار.
const sampleLogin = `<html><body>
<form name="login" action="http://10.3.0.1/login" method="post">
  <input type="hidden" name="dst" value="http://example.com">
  <input type="hidden" name="popup" value="true">
  <input type="hidden" name="chap-id" value="0a">
  <input type="hidden" name="chap-challenge" value="123456789abcdef0">
  <input type="text" name="username">
  <input type="password" name="password">
</form></body></html>`

func TestParseHidden(t *testing.T) {
	h := parseHidden(sampleLogin)
	for _, k := range []string{"dst", "popup", "chap-id", "chap-challenge"} {
		if _, ok := h[k]; !ok {
			t.Fatalf("الحقل المخفي %q لم يُستخرَج: %+v", k, h)
		}
	}
	if h["popup"] != "true" {
		t.Fatalf("قيمة popup خاطئة: %q", h["popup"])
	}
	if h["chap-challenge"] != "123456789abcdef0" {
		t.Fatalf("قيمة chap-challenge خاطئة: %q", h["chap-challenge"])
	}
}

func TestFormActionParsed(t *testing.T) {
	m := reAction.FindStringSubmatch(sampleLogin)
	if m == nil || m[1] != "http://10.3.0.1/login" {
		t.Fatalf("action لم يُستخرَج صحيحاً: %v", m)
	}
}

func TestChapResponseMatchesMikrotik(t *testing.T) {
	// المرجع: MD5( byte(id) + password + hexDecode(challenge) )
	id := "0a"
	pass := "cardpass123"
	challenge := "123456789abcdef0"

	got := chapResponse(id, pass, challenge)

	// نحسب المتوقّع يدوياً بنفس التعريف القياسي.
	idB, _ := hex.DecodeString("0a")
	chB, _ := hex.DecodeString(challenge)
	h := md5.New()
	h.Write(idB)
	h.Write([]byte(pass))
	h.Write(chB)
	want := hex.EncodeToString(h.Sum(nil))

	if got != want {
		t.Fatalf("CHAP خاطئ:\n  got=%s\n want=%s", got, want)
	}
	if len(got) != 32 {
		t.Fatalf("طول استجابة CHAP يجب أن يكون 32 hex، حصلنا %d", len(got))
	}
}

func TestChapChangesWithChallenge(t *testing.T) {
	a := chapResponse("01", "pw", "aaaa")
	b := chapResponse("01", "pw", "bbbb")
	if a == b {
		t.Fatal("تحدٍّ مختلف يجب أن يُعطي استجابة مختلفة")
	}
}

func TestPageMessage(t *testing.T) {
	page := `<html><head><style>.a{}</style></head><body><form><input name="username"></form>
	<div class="err">user 554327824572 has reached uptime limit</div></body></html>`
	if got := pageMessage(page); got == "" || !strings.Contains(got, "uptime limit") {
		t.Fatalf("got %q", got)
	}
	if got := pageMessage("<html><body>Welcome</body></html>"); got != "" {
		t.Fatalf("unexpected %q", got)
	}
}
