// lf-node: منسّق العقدة المحلية (بصلاحية root).
//
// التشغيل:  lf-node -config /etc/linkfuse/node.json
//
// يهيّئ كروت الإعداد (namespace + هوية وهمية + DHCP + دخول هوتسبوت)، يشغّل عميل
// النفق، ثم يفتح واجهة HTTP للّوحة (إحصاءات حية + إضافة/إزالة كرت أثناء التشغيل).
package main

import (
	"flag"
	"log"
	"os/exec"
	"strconv"
	"time"

	"github.com/linkfuse/node/api"
	"github.com/linkfuse/node/manager"
	"github.com/linkfuse/tunnel/client"
)

func main() {
	cfgPath := flag.String("config", "/etc/linkfuse/node.json", "مسار ملف الإعداد JSON")
	flag.Parse()

	cfg, err := manager.Load(*cfgPath)
	if err != nil {
		log.Fatalf("[node] إعداد: %v", err)
	}

	mgr := manager.New(cfg, *cfgPath)
	log.Printf("[node] تهيئة %d كرت…", len(cfg.Cards))
	pcs := mgr.BringUpInitial(8)
	if len(pcs) == 0 {
		log.Fatal("[node] لم ينجح أي كرت — تحقّق من الكروت والإعداد وصفحة الدخول")
	}
	log.Printf("[node] %d/%d كرت جاهز", len(pcs), len(cfg.Cards))

	cl, err := client.New(client.Config{
		TunName:      cfg.TunName,
		PSK:          cfg.PSK,
		ReorderHold:  time.Duration(cfg.ReorderHold) * time.Millisecond,
		ReorderCap:   cfg.ReorderCap,
		KeepaliveInt: time.Duration(cfg.KeepaliveInt) * time.Millisecond,
		PathTimeout:  time.Duration(cfg.PathTimeout) * time.Millisecond,
	}, pcs)
	if err != nil {
		log.Fatalf("[node] عميل النفق: %v", err)
	}
	mgr.AttachClient(cl)
	setupTun(cfg.TunName, cfg.TunAddr, cfg.MTU)

	go cl.Run() // النفق في الخلفية
	log.Println("[node] النفق يعمل")

	// واجهة اللوحة (تحجز الـ main).
	if err := api.New(mgr, cfg.APIToken).Run(cfg.APIListen); err != nil {
		log.Fatalf("[node] واجهة API: %v", err)
	}
}

func setupTun(name, addr string, mtu int) {
	run("ip", "addr", "add", addr, "dev", name)
	run("ip", "link", "set", "dev", name, "mtu", strconv.Itoa(mtu))
	run("ip", "link", "set", "dev", name, "up")
}

func run(args ...string) {
	if out, err := exec.Command(args[0], args[1:]...).CombinedOutput(); err != nil {
		log.Printf("[setup] %v: %v (%s)", args, err, string(out))
	}
}
