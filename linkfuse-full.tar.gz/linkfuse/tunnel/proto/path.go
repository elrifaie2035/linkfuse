package proto

import (
	"sync"
	"time"
)

// PathStats يحمل القياسات الحيّة لمسار (كرت) واحد ويشتقّ منها وزناً للموزّع.
// آمن للتوازي.
type PathStats struct {
	mu sync.Mutex

	BaseKbps int // سعة الكرت الاسمية (مثلاً 2000 لكرت 2Mbps) — مدخل من الإعداد

	srtt        time.Duration // RTT مُنعَّم (EWMA)
	reliability float64        // نسبة وصول النبضات (EWMA)، 1 = ممتاز

	LastSeen time.Time // آخر datagram وصل من هذا المسار

	// عدّادات تراكمية للعرض والمحاسبة
	TxPkts, TxBytes uint64
	RxPkts, RxBytes uint64
	KaSent, KaAcked uint64
}

// NewPathStats يبدأ المسار بافتراض ممتاز حتى تُثبت القياسات العكس.
func NewPathStats(baseKbps int) *PathStats {
	return &PathStats{BaseKbps: baseKbps, reliability: 1.0, srtt: 50 * time.Millisecond}
}

// OnRTT يُحدّث SRTT بعيّنة جديدة (من KeepaliveAck) بخوارزمية EWMA (α=1/8).
func (p *PathStats) OnRTT(sample time.Duration) {
	p.mu.Lock()
	if p.srtt == 0 {
		p.srtt = sample
	} else {
		p.srtt += (sample - p.srtt) / 8
	}
	p.reliability += (1.0 - p.reliability) / 8 // نبضة وصلت → موثوقية أعلى
	if p.reliability > 1 {
		p.reliability = 1
	}
	p.mu.Unlock()
}

// OnKeepaliveLost يُسجّل نبضة لم يصل ردّها ضمن المهلة (يخفض الموثوقية).
func (p *PathStats) OnKeepaliveLost() {
	p.mu.Lock()
	p.reliability += (0.0 - p.reliability) / 8
	p.mu.Unlock()
}

// Touch يسجّل أن بايتات وصلت على هذا المسار الآن (علامة حياة).
func (p *PathStats) Touch(now time.Time, nbytes int) {
	p.mu.Lock()
	p.LastSeen = now
	p.RxPkts++
	p.RxBytes += uint64(nbytes)
	p.mu.Unlock()
}

// AddTx يسجّل بايتات صادرة.
func (p *PathStats) AddTx(nbytes int) {
	p.mu.Lock()
	p.TxPkts++
	p.TxBytes += uint64(nbytes)
	p.mu.Unlock()
}

// SRTT, Reliability قراءات آمنة.
func (p *PathStats) SRTT() time.Duration {
	p.mu.Lock()
	defer p.mu.Unlock()
	return p.srtt
}
func (p *PathStats) Reliability() float64 {
	p.mu.Lock()
	defer p.mu.Unlock()
	return p.reliability
}

// Weight يحسب وزن المسار للموزّع: السعة الاسمية مُعاقَبة بالفقدان (تربيعياً
// ليُقصى المسار السيّئ بسرعة) وبالتأخير المرتفع. الحدّ الأدنى 1 لمسار حيّ.
func (p *PathStats) Weight() int {
	p.mu.Lock()
	defer p.mu.Unlock()
	rel := p.reliability
	rttMs := float64(p.srtt.Milliseconds())
	rttFactor := 100.0 / (100.0 + rttMs) // 1 عند 0ms، 0.5 عند 100ms
	w := float64(p.BaseKbps) * rel * rel * rttFactor
	if w < 1 {
		w = 1
	}
	return int(w)
}

// IsStale: هل انقطع المسار (لا datagram منذ مدة)؟
func (p *PathStats) IsStale(now time.Time, timeout time.Duration) bool {
	p.mu.Lock()
	defer p.mu.Unlock()
	if p.LastSeen.IsZero() {
		return false // لم يبدأ بعد
	}
	return now.Sub(p.LastSeen) > timeout
}
