import { nodeFetch } from "@/lib/api";
export const dynamic = "force-dynamic";
// Forwards the uploaded file (.xlsx or text) unchanged to the node.
export async function POST(req: Request) {
  const kbps = new URL(req.url).searchParams.get("kbps") || "2000";
  const body = await req.arrayBuffer();
  const r = await nodeFetch(`/api/stock/import?kbps=${encodeURIComponent(kbps)}`, {
    method: "POST",
    body,
    headers: { "Content-Type": "application/octet-stream" },
  });
  return new Response(await r.text(), { status: r.status, headers: { "Content-Type": "application/json" } });
}
