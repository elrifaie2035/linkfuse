#!/usr/bin/env bash
# إعداد توجيه العقدة المحلية بعد تشغيل lf-node. root.
set -e
LAN_IF="${1:-ens20}"        # واجهة شبكتك الداخلية (المستخدمون)
LAN_SUBNET="${2:-172.18.0.0/24}"
TUN="lf0"

echo "[+] تفعيل التمرير"
sysctl -w net.ipv4.ip_forward=1

echo "[+] توجيه حركة الشبكة الداخلية داخل النفق"
# كل ما يأتي من الـ LAN يخرج عبر النفق lf0 إلى الخادم ثم الإنترنت
iptables -t nat -C POSTROUTING -o "$TUN" -j MASQUERADE 2>/dev/null || \
  iptables -t nat -A POSTROUTING -o "$TUN" -j MASQUERADE
iptables -C FORWARD -i "$LAN_IF" -o "$TUN" -j ACCEPT 2>/dev/null || \
  iptables -A FORWARD -i "$LAN_IF" -o "$TUN" -j ACCEPT
iptables -C FORWARD -i "$TUN" -o "$LAN_IF" -m state --state RELATED,ESTABLISHED -j ACCEPT 2>/dev/null || \
  iptables -A FORWARD -i "$TUN" -o "$LAN_IF" -m state --state RELATED,ESTABLISHED -j ACCEPT

iptables -t mangle -C FORWARD -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --clamp-mss-to-pmtu 2>/dev/null || \
  iptables -t mangle -A FORWARD -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --clamp-mss-to-pmtu

echo "[✓] تمّ. تأكّد أن واجهة المزوّد (parent_iface) مُشغّلة بلا IP في المجال الجذر:"
echo "    ip link set <parent_iface> up"
