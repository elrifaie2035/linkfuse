package server

import (
	"fmt"
	"log"
	"os/exec"
	"strings"
	"time"
)

// LiveCapacityKbps is the bonded capacity the live paths really carry now:
// base_kbps x reliability x congestion of every non-stale path.
func (s *Server) LiveCapacityKbps() int {
	now := time.Now()
	total := 0.0
	s.mu.RLock()
	for _, p := range s.paths {
		if p.stats.IsStale(now, s.cfg.PathTimeout) {
			continue
		}
		total += p.stats.EffectiveKbps()
	}
	s.mu.RUnlock()
	return int(total)
}

// ShapeLoop keeps a CAKE shaper on the TUN device sized to the live cards
// (percent of LiveCapacityKbps). The queue then forms here, where CAKE keeps
// latency low, instead of in the provider's hotspot buffers (bufferbloat).
// percent <= 0 disables shaping.
func (s *Server) ShapeLoop(percent, rttMs int) {
	if percent <= 0 {
		log.Println("[shaper] disabled (shape_percent = 0)")
		return
	}
	if rttMs <= 0 {
		rttMs = 100
	}
	_ = exec.Command("modprobe", "sch_cake").Run()
	current := 0
	for {
		time.Sleep(5 * time.Second)
		target := s.LiveCapacityKbps() * percent / 100
		target = (target / 100) * 100 // round to 100 kbit
		if target < 500 {
			continue // no live cards yet
		}
		// Only touch tc when the change is meaningful (>5%).
		if current != 0 && abs(target-current)*100 < current*5 {
			continue
		}
		args := []string{"qdisc", "replace", "dev", s.cfg.TunName, "root", "cake",
			"bandwidth", fmt.Sprintf("%dkbit", target), "besteffort", "rtt", fmt.Sprintf("%dms", rttMs)}
		if out, err := exec.Command("tc", args...).CombinedOutput(); err != nil {
			log.Printf("[shaper] tc failed, shaping off: %v (%s)", err, strings.TrimSpace(string(out)))
			return
		}
		log.Printf("[shaper] download limit %d kbit (%d%% of live cards)", target, percent)
		current = target
	}
}

func abs(x int) int {
	if x < 0 {
		return -x
	}
	return x
}
