package proto

import (
	"testing"
	"time"
)

func idleSched(n, kbps int) *Scheduler {
	s := NewScheduler()
	for i := 1; i <= n; i++ {
		s.Upsert(uint16(i), kbps, true)
	}
	s.SetIdleSpread(true)
	return s
}

// drive sends `pps` packets per second for `d`, returns packets per path.
func drive(s *Scheduler, pps int, d time.Duration) map[uint16]int {
	out := map[uint16]int{}
	gap := time.Second / time.Duration(pps)
	for t := time.Duration(0); t < d; t += gap {
		id, ok := s.Pick()
		if ok {
			out[id]++
		}
		time.Sleep(gap)
	}
	return out
}

func TestIdleUsesSubsetAtLowLoad(t *testing.T) {
	if testing.Short() {
		t.Skip()
	}
	s := idleSched(30, 2000) // 60 Mbps total
	s.mu.Lock()
	s.idle.lastGrow = time.Now().Add(-time.Minute) // allow leaving full mode now
	s.mu.Unlock()
	used := drive(s, 50, 1500*time.Millisecond) // ~0.6 Mbps demand
	used = drive(s, 50, 1500*time.Millisecond)
	if len(used) == 0 || len(used) > 6 {
		t.Fatalf("light load should use a small random subset, used %d paths", len(used))
	}
}

func TestIdleBurstSwitchesAllOn(t *testing.T) {
	s := idleSched(30, 2000)
	s.mu.Lock()
	s.idle.all = false
	for i, it := range s.items {
		it.active = i < 2 // tiny subset: 4 Mbps
	}
	s.idle.activeKbps = 4000
	s.idle.winStart = time.Now()
	s.mu.Unlock()
	seen := map[uint16]bool{}
	for i := 0; i < 400; i++ { // a burst: 400 packets at once
		id, _ := s.Pick()
		seen[id] = true
	}
	if len(seen) < 30 {
		t.Fatalf("burst did not spread over all paths: %d", len(seen))
	}
}

func TestIdleSubsetDownFallsBackToAll(t *testing.T) {
	s := idleSched(5, 2000)
	s.mu.Lock()
	s.idle.all = false
	s.idle.activeKbps = 1e9 // no burst trigger
	s.idle.winStart = time.Now()
	for _, it := range s.items {
		it.active = it.id == 1
	}
	s.mu.Unlock()
	s.SetUp(1, false)
	if _, ok := s.Pick(); !ok {
		t.Fatal("packet dropped although other paths are up")
	}
}

func TestIdleOffIsNormalRoundRobin(t *testing.T) {
	s := NewScheduler()
	for i := 1; i <= 4; i++ {
		s.Upsert(uint16(i), 2000, true)
	}
	seen := map[uint16]int{}
	for i := 0; i < 400; i++ {
		id, _ := s.Pick()
		seen[id]++
	}
	for id, n := range seen {
		if n != 100 {
			t.Fatalf("path %d got %d of 400", id, n)
		}
	}
}
