package proto

import (
	"sync"
	"time"
)

// One-way queueing delay, per direction.
//
// Each side stamps its keepalives with its own monotonic clock (MonoNow). The
// receiver computes recv - sent: that includes an unknown constant offset (the
// two clocks are unrelated), so only its change matters. The lowest value seen
// is the empty-queue baseline; anything above it is queueing delay in THAT
// direction. The receiver sends this back in its keepalive-ack, so the sender
// learns how full the queue is on the path it sends on, without download
// traffic making the upload look congested (and the reverse).
//
// Monotonic clocks are immune to wall-clock steps (date -s, NTP).

var procStart = time.Now()

// MonoNow is nanoseconds since this process started (monotonic).
func MonoNow() int64 { return int64(time.Since(procStart)) }

// OWDTracker turns raw one-way samples into queueing delay.
type OWDTracker struct {
	mu   sync.Mutex
	min  int64
	have bool
}

// Observe takes recv-minus-sent (ns) and returns the queueing delay.
func (o *OWDTracker) Observe(owd int64) time.Duration {
	o.mu.Lock()
	defer o.mu.Unlock()
	switch {
	case !o.have || owd < o.min:
		o.min, o.have = owd, true
	case owd-o.min > int64(10*time.Second):
		o.min = owd // the peer restarted (new clock origin): start over
	default:
		o.min += (owd - o.min) / 2000 // follow a real route change, very slowly
	}
	return time.Duration(owd - o.min)
}

// OnQueueDelay updates the path's congestion from the one-way queueing delay
// the peer measured on the direction this side sends on. From then on RTT no
// longer drives congestion for this path.
func (p *PathStats) OnQueueDelay(q time.Duration) {
	const k = 20 * time.Millisecond
	target := float64(QueueAllowance+k) / float64(q+k)
	if target > 1 {
		target = 1
	}
	if target < minCongestion {
		target = minCongestion
	}
	p.mu.Lock()
	p.owdMode = true
	p.congestion += (target - p.congestion) / 4
	p.mu.Unlock()
}
