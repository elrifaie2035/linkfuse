// Package client هو طرف النفق على العقدة المحلية (مكان 103).
// يقرأ حركة المستخدمين من جهاز TUN، ويوزّعها على سوكيتات UDP، واحدٌ لكل كرت،
// كلٌّ منها مربوط ليخرج عبر كرته (عبر namespace/واجهة الكرت — تُجهّزها طبقة node).
// العائد من الخادم يصل على كل السوكيتات فيُعاد ترتيبه ويُكتب على TUN.
package client

import (
	"encoding/binary"
	"log"
	"net"
	"sync"
	"sync/atomic"
	"time"

	"github.com/linkfuse/tunnel/proto"
	"github.com/linkfuse/tunnel/tundev"
)

// PathConn مسار جاهز: سوكيت UDP موصول مسبقاً بالخادم ومربوط بكرت معيّن.
type PathConn struct {
	ID       uint16
	Conn     *net.UDPConn // نتيجة net.DialUDP، مربوط ليخرج عبر الكرت المطلوب
	BaseKbps int          // سعة الكرت الاسمية
}

// Config إعداد العميل.
type Config struct {
	TunName      string
	PSK          string
	ReorderHold  time.Duration
	ReorderCap   int
	KeepaliveInt time.Duration
	PathTimeout  time.Duration
}

type clientPath struct {
	id       uint16
	conn     *net.UDPConn
	stats    *proto.PathStats
	owd      proto.OWDTracker // server -> client direction
	awaiting atomic.Bool
	closed   atomic.Bool
}

// Client الحالة الكاملة.
type Client struct {
	cfg   Config
	codec *proto.Codec
	tun   proto.TUN
	sched *proto.Scheduler

	pathsMu sync.RWMutex // يحمي paths (الإضافة/الإزالة أثناء التشغيل)
	paths   []*clientPath

	reorder *proto.ReorderBuffer
	inbound chan inItem
	txSeq   uint64
	running atomic.Bool

	RxBytes atomic.Uint64
	TxBytes atomic.Uint64
}

type inItem struct {
	seq  uint64
	data []byte
	at   time.Time
}

// New يجهّز العميل بفتح جهاز TUN حقيقي (للإنتاج).
func New(cfg Config, pcs []PathConn) (*Client, error) {
	tun, err := tundev.Open(cfg.TunName)
	if err != nil {
		return nil, err
	}
	return NewWithTUN(cfg, tun, pcs)
}

// NewWithTUN يجهّز العميل بجهاز TUN مُعطى (يتيح الحقن في الاختبار).
func NewWithTUN(cfg Config, tun proto.TUN, pcs []PathConn) (*Client, error) {
	codec, err := proto.NewCodec(cfg.PSK)
	if err != nil {
		return nil, err
	}
	c := &Client{
		cfg:     cfg,
		codec:   codec,
		tun:     tun,
		sched:   proto.NewScheduler(),
		inbound: make(chan inItem, 4096),
	}
	for _, pc := range pcs {
		p := &clientPath{id: pc.ID, conn: pc.Conn, stats: proto.NewPathStats(pc.BaseKbps)}
		c.paths = append(c.paths, p)
		c.sched.Upsert(pc.ID, pc.BaseKbps, true)
	}
	c.reorder = proto.NewReorderBuffer(cfg.ReorderHold, cfg.ReorderCap, func(pkt []byte) {
		_, _ = c.tun.Write(pkt)
	})
	log.Printf("[client] device %s ready, %d paths", cfg.TunName, len(c.paths))
	return c, nil
}

// Run يشغّل كل الحلقات.
func (c *Client) Run() {
	c.running.Store(true)
	c.pathsMu.RLock()
	for _, p := range c.paths {
		go c.readPath(p) // كل كرت له قارئ مستقل
		c.sendHello(p)
	}
	c.pathsMu.RUnlock()
	go c.assemble() // مجمِّع واحد يملك إعادة الترتيب والكتابة على TUN
	go c.keepaliveLoop()
	go c.healthLoop()
	c.tunToPaths() // يحجز الـ goroutine الرئيسية
}

// AddPath يضيف كرتاً أثناء التشغيل (توسيع فوق الخمسين بلا إيقاف النفق).
func (c *Client) AddPath(pc PathConn) {
	p := &clientPath{id: pc.ID, conn: pc.Conn, stats: proto.NewPathStats(pc.BaseKbps)}
	c.pathsMu.Lock()
	// إن كان المعرّف موجوداً نستبدله (نُغلق القديم أولاً).
	for i, old := range c.paths {
		if old.id == pc.ID {
			old.closed.Store(true)
			_ = old.conn.Close()
			c.paths = append(c.paths[:i], c.paths[i+1:]...)
			break
		}
	}
	c.paths = append(c.paths, p)
	c.pathsMu.Unlock()
	c.sched.Upsert(pc.ID, pc.BaseKbps, true)
	if c.running.Load() {
		go c.readPath(p)
		c.sendHello(p)
	}
	log.Printf("[client] card #%d added at runtime", pc.ID)
}

// RemovePath يزيل كرتاً أثناء التشغيل (تقليل العدد).
func (c *Client) RemovePath(id uint16) {
	c.pathsMu.Lock()
	var removed *clientPath
	for i, p := range c.paths {
		if p.id == id {
			removed = p
			c.paths = append(c.paths[:i], c.paths[i+1:]...)
			break
		}
	}
	c.pathsMu.Unlock()
	if removed == nil {
		return
	}
	c.sched.Remove(id) // نتوقّف عن الإرسال عليه فوراً
	// نُعلم الخادم ليتوقّف هو أيضاً عن الإرسال علينا عبره، قبل إغلاق السوكيت
	// (وإلّا بقي يرسل على كرت مغلق حتى تنتهي مهلته فتضيع الحركة العائدة).
	for i := 0; i < 3; i++ {
		c.sendCtrl(removed, proto.TypeBye, time.Now().UnixNano())
	}
	removed.closed.Store(true)
	_ = removed.conn.Close() // يُنهي goroutine القراءة
	log.Printf("[client] card #%d removed at runtime", id)
}

// PathCount عدد الكروت الحالي.
func (c *Client) PathCount() int {
	c.pathsMu.RLock()
	defer c.pathsMu.RUnlock()
	return len(c.paths)
}

// readPath يقرأ من سوكيت كرت واحد. DATA تُمرَّر للمجمِّع؛ التحكّم يُعالَج فوراً.
func (c *Client) readPath(p *clientPath) {
	buf := make([]byte, proto.Overhead+proto.MaxPayload+64)
	scratch := make([]byte, proto.MaxPayload+proto.HeaderSize+64)
	for {
		n, err := p.conn.Read(buf)
		now := time.Now()
		if err != nil {
			if p.closed.Load() {
				return // أُزيل الكرت عمداً — خروج صامت
			}
			log.Printf("[client] path #%d read error: %v", p.id, err)
			time.Sleep(200 * time.Millisecond)
			continue
		}
		h, payload, err := c.codec.Open(scratch, buf[:n])
		if err != nil {
			continue
		}
		p.stats.Touch(now, n)
		c.RxBytes.Add(uint64(n))
		switch h.Type {
		case proto.TypeData:
			cp := make([]byte, len(payload))
			copy(cp, payload)
			select {
			case c.inbound <- inItem{seq: h.Seq, data: cp, at: now}:
			default: // المجمِّع متأخر — نُسقط (نادر؛ أفضل من حجز القارئ)
			}
		case proto.TypeKeepalive:
			// tell the server how full the queue is on the path it sends on
			q := p.owd.Observe(proto.MonoNow() - h.TS)
			c.sendCtrlPayload(p, proto.TypeKeepaliveAck, h.TS, queuePayload(q))
		case proto.TypeKeepaliveAck:
			rtt := time.Duration(proto.MonoNow() - h.TS)
			if rtt > 0 && rtt < 10*time.Second {
				p.stats.OnRTT(rtt)
			}
			if len(payload) >= 4 { // server measured our upload queue on this path
				p.stats.OnQueueDelay(time.Duration(binary.BigEndian.Uint32(payload)) * time.Microsecond)
			}
			p.awaiting.Store(false)
			c.sched.SetUp(p.id, true)
		}
	}
}

// assemble: الـ goroutine الوحيدة التي تلمس مخزن إعادة الترتيب وتكتب على TUN.
func (c *Client) assemble() {
	t := time.NewTicker(10 * time.Millisecond)
	defer t.Stop()
	rl := proto.ReorderLogger{Name: "download"}
	for {
		select {
		case it := <-c.inbound:
			c.reorder.Push(it.seq, it.data, it.at)
		case now := <-t.C:
			c.reorder.Tick(now)
			rl.Maybe(c.reorder, now)
		}
	}
}

// tunToPaths: يقرأ حركة المستخدم من TUN ويوزّعها على الكروت.
func (c *Client) tunToPaths() {
	pkt := make([]byte, proto.MaxPayload+64)
	out := make([]byte, proto.Overhead+proto.MaxPayload+64)
	for {
		n, err := c.tun.Read(pkt)
		if err != nil {
			log.Printf("[client] TUN read error: %v", err)
			return
		}
		if n == 0 || n > proto.MaxPayload {
			continue
		}
		id, ok := c.sched.Pick()
		if !ok {
			continue
		}
		p := c.pathByID(id)
		if p == nil {
			continue
		}
		seq := atomic.AddUint64(&c.txSeq, 1) - 1
		h := proto.Header{Type: proto.TypeData, PathID: id, Seq: seq}
		sealed, err := c.codec.Seal(out, h, pkt[:n])
		if err != nil {
			continue
		}
		if _, err := p.conn.Write(sealed); err == nil {
			p.stats.AddTx(len(sealed))
			c.TxBytes.Add(uint64(len(sealed)))
		}
	}
}

func (c *Client) sendCtrl(p *clientPath, t proto.FrameType, ts int64) {
	var payload []byte
	if t == proto.TypeKeepalive || t == proto.TypeHello {
		// carry this path's nominal capacity to the server (4 bytes, big endian)
		payload = binary.BigEndian.AppendUint32(nil, uint32(p.stats.Base()))
	}
	c.sendCtrlPayload(p, t, ts, payload)
}

func (c *Client) sendCtrlPayload(p *clientPath, t proto.FrameType, ts int64, payload []byte) {
	out := make([]byte, proto.Overhead+16)
	h := proto.Header{Type: t, PathID: p.id, TS: ts}
	if sealed, err := c.codec.Seal(out, h, payload); err == nil {
		_, _ = p.conn.Write(sealed)
	}
}

// queuePayload encodes a queueing delay as 4 bytes of microseconds.
func queuePayload(q time.Duration) []byte {
	us := q / time.Microsecond
	if us < 0 {
		us = 0
	}
	if us > 4_000_000_000 {
		us = 4_000_000_000
	}
	return binary.BigEndian.AppendUint32(nil, uint32(us))
}

func (c *Client) sendHello(p *clientPath) {
	c.sendCtrl(p, proto.TypeHello, proto.MonoNow())
}

func (c *Client) keepaliveLoop() {
	t := time.NewTicker(c.cfg.KeepaliveInt)
	defer t.Stop()
	for range t.C {
		now := time.Now()
		for _, p := range c.snapshotPaths() {
			if p.awaiting.Swap(true) {
				p.stats.OnKeepaliveLost()
			}
			c.sendCtrl(p, proto.TypeKeepalive, proto.MonoNow())
			c.sched.Upsert(p.id, p.stats.Weight(), !p.stats.IsStale(now, c.cfg.PathTimeout))
		}
	}
}

// snapshotPaths يُعيد نسخة من المسارات الحالية للتكرار الآمن خارج القفل.
func (c *Client) snapshotPaths() []*clientPath {
	c.pathsMu.RLock()
	defer c.pathsMu.RUnlock()
	out := make([]*clientPath, len(c.paths))
	copy(out, c.paths)
	return out
}

func (c *Client) healthLoop() {
	t := time.NewTicker(time.Second)
	defer t.Stop()
	for range t.C {
		now := time.Now()
		for _, p := range c.snapshotPaths() {
			up := !p.stats.IsStale(now, c.cfg.PathTimeout)
			c.sched.Upsert(p.id, p.stats.Weight(), up)
		}
	}
}

func (c *Client) pathByID(id uint16) *clientPath {
	c.pathsMu.RLock()
	defer c.pathsMu.RUnlock()
	for _, p := range c.paths {
		if p.id == id {
			return p
		}
	}
	return nil
}

// Stats لقطة موجزة لكل مسار (تستهلكها اللوحة لاحقاً).
type PathStat struct {
	ID          uint16
	SRTTms      float64
	Reliability float64
	Congestion  float64
	EffKbps     float64
	ShapeKbps   float64 // what the upload shaper sizes from (congestion cut limited)
	Weight      int
	TxBytes     uint64
	RxBytes     uint64
}

func (c *Client) Stats() []PathStat {
	snap := c.sched.Snapshot()
	paths := c.snapshotPaths()
	out := make([]PathStat, 0, len(paths))
	for _, p := range paths {
		out = append(out, PathStat{
			ID:          p.id,
			SRTTms:      float64(p.stats.SRTT().Microseconds()) / 1000,
			Reliability: p.stats.Reliability(),
			Congestion:  p.stats.Congestion(),
			EffKbps:     p.stats.EffectiveKbps(),
			ShapeKbps:   p.stats.ShaperKbps(),
			Weight:      snap[p.id],
			TxBytes:     p.stats.TxBytes,
			RxBytes:     p.stats.RxBytes,
		})
	}
	return out
}
