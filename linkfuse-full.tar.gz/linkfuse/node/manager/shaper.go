package manager

import (
	"fmt"
	"log"
	"os/exec"
	"strings"
	"time"
)

// UploadShapeLoop keeps a CAKE shaper on the node's TUN device (traffic going
// up into the tunnel) sized to the live cards: base_kbps x reliability of each
// working path x percent. The upload queue then forms here, where CAKE keeps
// latency low, instead of in the provider's hotspot buffers.
// percent <= 0 disables it.
func (m *Manager) UploadShapeLoop(tun string, percent, rttMs int) {
	if percent <= 0 {
		log.Println("[shaper] upload shaping disabled (shape_up_percent = 0)")
		return
	}
	if rttMs <= 0 {
		rttMs = 100
	}
	_ = exec.Command("modprobe", "sch_cake").Run()
	current := 0
	for {
		time.Sleep(5 * time.Second)
		if m.cl == nil {
			continue
		}
		total := 0.0
		for _, st := range m.cl.Stats() {
			if st.Weight <= 0 {
				continue
			}
			total += st.EffKbps // capacity x reliability x congestion (real, not written)
		}
		target := int(total) * percent / 100
		target = (target / 100) * 100
		if target < 500 {
			continue
		}
		if current != 0 && absInt(target-current)*100 < current*5 {
			continue
		}
		args := []string{"qdisc", "replace", "dev", tun, "root", "cake",
			"bandwidth", fmt.Sprintf("%dkbit", target), "besteffort", "rtt", fmt.Sprintf("%dms", rttMs)}
		if out, err := exec.Command("tc", args...).CombinedOutput(); err != nil {
			log.Printf("[shaper] tc failed, upload shaping off: %v (%s)", err, strings.TrimSpace(string(out)))
			return
		}
		log.Printf("[shaper] upload limit %d kbit (%d%% of live cards)", target, percent)
		current = target
	}
}

func absInt(x int) int {
	if x < 0 {
		return -x
	}
	return x
}
