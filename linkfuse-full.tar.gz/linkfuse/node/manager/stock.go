package manager

import (
	"encoding/json"
	"fmt"
	"log"
	"os"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/linkfuse/node/hotspot"
	"github.com/linkfuse/node/netns"
	"github.com/linkfuse/node/stock"
)

// Card stock: imported cards wait as "unused"; the manager keeps
// cfg.TargetActive of them running ("active") and replaces each one shortly
// before its validity runs out ("expired"). Cards the hotspot refuses while
// other cards work are marked "bad". Validity is clock time from first login.

const (
	StUnused  = "unused"
	StActive  = "active"
	StExpired = "expired"
	StBad     = "bad"
)

type StockCard struct {
	ID         uint16    `json:"id"`
	Username   string    `json:"username"`
	Password   string    `json:"password"`
	Package    string    `json:"package"`
	DurationH  float64   `json:"duration_h"`
	BaseKbps   int       `json:"base_kbps"`
	Status     string    `json:"status"`
	AddedAt    time.Time `json:"added_at"`
	FirstLogin time.Time `json:"first_login,omitempty"`
	ExpiresAt  time.Time `json:"expires_at,omitempty"`
	EndedAt    time.Time `json:"ended_at,omitempty"`
	Fails      int       `json:"fails"`
	LastError  string    `json:"last_error,omitempty"`
}

type stockStore struct {
	mu    sync.Mutex
	path  string
	Cards []*StockCard `json:"cards"`
}

func (s *stockStore) save() {
	b, err := json.MarshalIndent(struct {
		Cards []*StockCard `json:"cards"`
	}{s.Cards}, "", "  ")
	if err != nil {
		return
	}
	tmp := s.path + ".tmp"
	if os.WriteFile(tmp, b, 0600) == nil {
		_ = os.Rename(tmp, s.path)
	}
}

func loadStock(path string) *stockStore {
	st := &stockStore{path: path}
	if b, err := os.ReadFile(path); err == nil {
		_ = json.Unmarshal(b, st)
	}
	// Cards rejected earlier because of a local setup error (e.g. "Address
	// already in use") were never tried at the provider: put them back.
	fixed := 0
	for _, c := range st.Cards {
		if c.Status == StBad && strings.HasPrefix(c.LastError, "namespace:") {
			c.Status, c.Fails, c.EndedAt = StUnused, 0, time.Time{}
			fixed++
		}
	}
	if fixed > 0 {
		log.Printf("[stock] %d cards rejected by a local error returned to stock", fixed)
		st.save()
	}
	return st
}

// localError: the failure happened on this machine (namespace/interface
// setup), before the card reached the provider.
func localError(err error) bool {
	return err != nil && strings.HasPrefix(err.Error(), "namespace:")
}

// stockPath sits next to node.json.
func (m *Manager) stockPath() string {
	dir := "."
	for i := len(m.cfgPath) - 1; i >= 0; i-- {
		if m.cfgPath[i] == '/' {
			dir = m.cfgPath[:i]
			break
		}
	}
	return dir + "/stock.json"
}

func (m *Manager) stockStore() *stockStore {
	m.stockOnce.Do(func() { m.stock = loadStock(m.stockPath()) })
	return m.stock
}

// ImportResult is returned to the panel.
type ImportResult struct {
	Added           int      `json:"added"`
	Duplicates      int      `json:"duplicates"`
	MissingPassword []string `json:"missing_password"`
	Rows            int      `json:"rows"`
}

// ImportStock adds cards from an .xlsx or text file. Cards already known
// (stock or active config) are skipped.
func (m *Manager) ImportStock(data []byte, baseKbps int) (ImportResult, error) {
	rep, err := stock.Parse(data)
	if err != nil {
		return ImportResult{}, err
	}
	if baseKbps <= 0 {
		baseKbps = 2000
	}
	st := m.stockStore()
	m.mu.Lock()
	known := map[string]bool{}
	maxID := 0
	for _, c := range m.cfg.Cards {
		known[c.Username] = true
		if int(c.ID) > maxID {
			maxID = int(c.ID)
		}
	}
	m.mu.Unlock()
	st.mu.Lock()
	defer st.mu.Unlock()
	for _, c := range st.Cards {
		known[c.Username] = true
		if int(c.ID) > maxID {
			maxID = int(c.ID)
		}
	}
	res := ImportResult{MissingPassword: rep.MissingPassword, Rows: rep.Rows}
	if res.MissingPassword == nil {
		res.MissingPassword = []string{}
	}
	now := time.Now()
	for _, e := range rep.Entries {
		if known[e.Username] {
			res.Duplicates++
			continue
		}
		if maxID >= 65000 {
			return res, fmt.Errorf("card ID space exhausted")
		}
		maxID++
		known[e.Username] = true
		st.Cards = append(st.Cards, &StockCard{
			ID: uint16(maxID), Username: e.Username, Password: e.Password, Package: e.Package,
			DurationH: e.DurationH, BaseKbps: baseKbps, Status: StUnused, AddedAt: now,
		})
		res.Added++
	}
	st.save()
	log.Printf("[stock] imported %d cards (%d duplicates, %d without password)", res.Added, res.Duplicates, len(res.MissingPassword))
	return res, nil
}

// StockView is what the panel shows.
type StockView struct {
	Target int            `json:"target"`
	Counts map[string]int `json:"counts"`
	Cards  []StockCard    `json:"cards"` // passwords removed
}

func (m *Manager) StockView() StockView {
	st := m.stockStore()
	st.mu.Lock()
	defer st.mu.Unlock()
	v := StockView{Target: m.cfg.TargetActive, Counts: map[string]int{StUnused: 0, StActive: 0, StExpired: 0, StBad: 0}}
	for _, c := range st.Cards {
		v.Counts[c.Status]++
		cp := *c
		cp.Password = ""
		v.Cards = append(v.Cards, cp)
	}
	return v
}

// SetTarget changes how many stock cards should run at once (0 = stock off).
func (m *Manager) SetTarget(n int) {
	if n < 0 {
		n = 0
	}
	m.mu.Lock()
	m.cfg.TargetActive = n
	m.mu.Unlock()
	m.persist()
	log.Printf("[stock] target active cards = %d", n)
	go m.maintainStock()
}

// DeleteStock removes cards that are not running (unused/expired/bad) from the
// stock list. status "" removes one card by id.
func (m *Manager) DeleteStock(id uint16, status string) int {
	st := m.stockStore()
	st.mu.Lock()
	defer st.mu.Unlock()
	out := st.Cards[:0]
	n := 0
	for _, c := range st.Cards {
		match := c.Status != StActive && ((status == "" && c.ID == id) || (status != "" && c.Status == status))
		if match {
			n++
			continue
		}
		out = append(out, c)
	}
	st.Cards = out
	st.save()
	return n
}

// isStockActive reports whether id is a running stock card.
func (m *Manager) stockCard(id uint16) *StockCard {
	st := m.stockStore()
	for _, c := range st.Cards {
		if c.ID == id {
			return c
		}
	}
	return nil
}

// cardFailed is called when a running (or configured) card could not log in
// again. A stock card is taken out only when other cards still work (so a line
// outage does not burn the stock). A card with clock time left is parked and
// retried later; after 4 failures in a row it is marked bad.
func (m *Manager) cardFailed(id uint16, err error) {
	if !m.othersHealthy(id) {
		return // line problem, not the card: keep trying
	}
	st := m.stockStore()
	st.mu.Lock()
	c := m.stockCard(id)
	if c == nil || c.Status != StActive {
		st.mu.Unlock()
		return
	}
	c.Fails++
	c.LastError = err.Error()
	retire := c.Fails >= 2
	if retire {
		left := !c.ExpiresAt.IsZero() && time.Until(c.ExpiresAt) > 10*time.Minute
		switch {
		case c.Fails >= 4:
			c.Status = StBad
			c.EndedAt = time.Now()
		case left || c.ExpiresAt.IsZero():
			c.Status = StUnused // parked: retried later, before fresh cards
		default:
			c.Status = StExpired
			c.EndedAt = time.Now()
		}
	}
	status := c.Status
	st.save()
	st.mu.Unlock()
	if retire {
		log.Printf("[stock] card #%d refused (%v), now %s", id, err, status)
		_ = m.Remove(id)
	}
}

func (m *Manager) cardOK(id uint16) {
	st := m.stockStore()
	st.mu.Lock()
	if c := m.stockCard(id); c != nil && c.Fails > 0 && c.Status == StActive {
		c.Fails = 0
		st.save()
	}
	st.mu.Unlock()
}

var maintainMu sync.Mutex

// maintainStock retires cards about to expire and starts fresh ones until
// TargetActive stock cards run.
func (m *Manager) maintainStock() {
	maintainMu.Lock()
	defer maintainMu.Unlock()
	m.mu.Lock()
	target := m.cfg.TargetActive
	lead := time.Duration(m.cfg.ReplaceLeadMin) * time.Minute
	m.mu.Unlock()
	if target <= 0 || m.cl == nil {
		return
	}
	if lead <= 0 {
		lead = 3 * time.Minute
	}
	st := m.stockStore()
	now := time.Now()

	// 1) Cards close to the end of their validity: start a replacement first,
	//    then retire the old card (no gap in capacity).
	st.mu.Lock()
	var ending []uint16
	for _, c := range st.Cards {
		if c.Status == StActive && !c.ExpiresAt.IsZero() && now.After(c.ExpiresAt.Add(-lead)) {
			ending = append(ending, c.ID)
		}
	}
	st.mu.Unlock()
	for _, id := range ending {
		m.startNextStock(3, true)
		st.mu.Lock()
		if c := m.stockCard(id); c != nil {
			c.Status = StExpired
			c.EndedAt = time.Now()
			st.save()
		}
		st.mu.Unlock()
		log.Printf("[stock] card #%d reached its validity, retired", id)
		m.logoutAndRemove(id)
	}

	// 2) Fill up to the target.
	for i := 0; i < 50; i++ {
		if m.activeStockCount() >= target {
			break
		}
		if !m.startNextStock(5, true) {
			break
		}
	}
	// 3) Too many (target lowered): retire the cards with the least time left.
	for m.activeStockCount() > target {
		id := m.soonestEnding()
		if id == 0 {
			break
		}
		st.mu.Lock()
		if c := m.stockCard(id); c != nil {
			// back to the stock: its clock keeps running, so it is picked
			// first next time (until its expiry passes)
			c.Status = StUnused
			st.save()
		}
		st.mu.Unlock()
		m.logoutAndRemove(id)
	}
}

func (m *Manager) activeStockCount() int {
	st := m.stockStore()
	st.mu.Lock()
	defer st.mu.Unlock()
	n := 0
	for _, c := range st.Cards {
		if c.Status == StActive {
			n++
		}
	}
	return n
}

func (m *Manager) soonestEnding() uint16 {
	st := m.stockStore()
	st.mu.Lock()
	defer st.mu.Unlock()
	var best *StockCard
	for _, c := range st.Cards {
		if c.Status != StActive {
			continue
		}
		if best == nil || (!c.ExpiresAt.IsZero() && (best.ExpiresAt.IsZero() || c.ExpiresAt.Before(best.ExpiresAt))) {
			best = c
		}
	}
	if best == nil {
		return 0
	}
	return best.ID
}

// startNextStock brings up the next unused card (longest validity first, then
// oldest import). Tries up to maxTries cards; returns true when one started.
func (m *Manager) startNextStock(maxTries int, mayMarkBad bool) bool {
	st := m.stockStore()
	skip := map[uint16]bool{}
	for try := 0; try < maxTries; try++ {
		st.mu.Lock()
		var cand []*StockCard
		now := time.Now()
		changed := false
		for _, c := range st.Cards {
			if c.Status != StUnused || skip[c.ID] {
				continue
			}
			if !c.ExpiresAt.IsZero() && now.After(c.ExpiresAt.Add(-5*time.Minute)) {
				c.Status = StExpired // started earlier and ran out while parked
				c.EndedAt = now
				changed = true
				continue
			}
			cand = append(cand, c)
		}
		if changed {
			st.save()
		}
		// Order: cards whose clock already runs (soonest end first), then the
		// longest validity (monthly before daily), then oldest import.
		sort.SliceStable(cand, func(i, j int) bool {
			a, b := cand[i], cand[j]
			as, bs := !a.FirstLogin.IsZero(), !b.FirstLogin.IsZero()
			if as != bs {
				return as
			}
			if as && bs && !a.ExpiresAt.Equal(b.ExpiresAt) {
				return a.ExpiresAt.Before(b.ExpiresAt)
			}
			if a.DurationH != b.DurationH {
				return a.DurationH > b.DurationH
			}
			return a.AddedAt.Before(b.AddedAt)
		})
		if len(cand) == 0 {
			st.mu.Unlock()
			log.Printf("[stock] no unused cards left in stock")
			return false
		}
		c := cand[0]
		cc := CardCfg{ID: c.ID, Username: c.Username, Password: c.Password, BaseKbps: c.BaseKbps}
		st.mu.Unlock()

		log.Printf("[stock] starting card #%d (%s)", cc.ID, c.Package)
		err := m.Add(cc)

		st.mu.Lock()
		if err == nil {
			now := time.Now()
			c.Status = StActive // Fails is reset only after a later successful check
			if c.FirstLogin.IsZero() {
				c.FirstLogin = now
			}
			if c.DurationH > 0 {
				c.ExpiresAt = c.FirstLogin.Add(time.Duration(c.DurationH * float64(time.Hour)))
			}
			st.save()
			st.mu.Unlock()
			return true
		}
		c.LastError = err.Error()
		if localError(err) {
			// Our own setup failed (not the provider): never count it against the card.
			skip[c.ID] = true
			log.Printf("[stock] card #%d not started (local error, card kept): %v", c.ID, err)
			st.mu.Unlock()
			continue
		}
		c.Fails++
		// Only blame the card when the line itself works (other cards online);
		// otherwise a provider outage would burn the whole stock.
		skip[c.ID] = true // try the next card in this pass
		if mayMarkBad && m.lineWorks(c.ID) && c.Fails >= 2 {
			c.Status = StBad
			c.EndedAt = time.Now()
			log.Printf("[stock] card #%d refused, marked bad: %v", c.ID, err)
		} else {
			log.Printf("[stock] card #%d failed to start (try %d): %v", c.ID, c.Fails, err)
		}
		st.save()
		st.mu.Unlock()
		if m.liveCount() == 0 {
			return false // line down: wait for the next round
		}
	}
	return false
}

func (m *Manager) liveCount() int {
	m.mu.Lock()
	defer m.mu.Unlock()
	return len(m.cards)
}

// logoutAndRemove ends the hotspot session, then removes the card.
func (m *Manager) logoutAndRemove(id uint16) {
	hotspot.Logout(netns.Path("lfcard-"+strconv.Itoa(int(id))), m.loginCfg())
	_ = m.Remove(id)
}

// RemoveByUser stops a card from the panel. A running stock card is marked
// bad (so it is not started again) and its slot is refilled from the stock.
func (m *Manager) RemoveByUser(id uint16) error {
	st := m.stockStore()
	st.mu.Lock()
	if c := m.stockCard(id); c != nil && c.Status == StActive {
		c.Status = StBad
		c.LastError = "removed from the panel"
		c.EndedAt = time.Now()
		st.save()
	}
	st.mu.Unlock()
	m.mu.Lock()
	pppoe := false
	if cs, ok := m.cards[id]; ok {
		pppoe = cs.cfg.isPPPoE()
	}
	m.mu.Unlock()
	if !pppoe {
		hotspot.Logout(netns.Path("lfcard-"+strconv.Itoa(int(id))), m.loginCfg())
	}
	err := m.Remove(id) // Teardown also ends a PPPoE session
	go m.maintainStock()
	return err
}

// probeWhenAllFail handles the case where every running card fails at once.
// That is either a line outage or a batch of cards started together that all
// ran out together. A fresh card from the stock tells which: if it logs in,
// the line works, the old cards are refused on the next round and replaced.
// The probe never marks the fresh card bad (it may just be the outage).
func (m *Manager) probeWhenAllFail(live []CardCfg) {
	if len(live) == 0 {
		m.allDownRounds = 0
		return
	}
	for _, cc := range live {
		if m.isHealthy(cc.ID) {
			m.allDownRounds = 0
			return
		}
	}
	m.allDownRounds++
	if m.allDownRounds < 2 || m.allDownRounds%2 != 0 {
		return // probe on rounds 2, 4, 6... (about once a minute)
	}
	m.mu.Lock()
	target := m.cfg.TargetActive
	m.mu.Unlock()
	if target <= 0 {
		return
	}
	log.Printf("[stock] every running card fails: probing with a fresh card")
	if m.startNextStock(1, false) {
		log.Printf("[stock] fresh card works: the running cards have expired")
	}
}
