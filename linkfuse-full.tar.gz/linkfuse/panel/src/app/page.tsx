"use client";

import { useEffect, useRef, useState } from "react";
import { fmtBytes, fmtRate, fmtMs, fmtUptime } from "@/lib/format";

type Card = {
  id: number;
  device: string;
  mac: string;
  username: string;
  srtt_ms: number;
  reliability: number;
  weight: number;
  tx_bytes: number;
  rx_bytes: number;
  up: boolean;
};
type Snapshot = {
  cards: Card[];
  total_tx: number;
  total_rx: number;
  active_up: number;
  card_count: number;
  bonded_kbps: number;
  error?: string;
};
type Usage = {
  total_bytes?: number;
  rx_bytes?: number;
  tx_bytes?: number;
  uptime_sec?: number;
  quota_gb?: number;
  error?: string;
};

const C = {
  bg: "var(--bg)", panel: "var(--panel)", panel2: "var(--panel2)", line: "var(--line)",
  text: "var(--text)", muted: "var(--muted)", accent: "var(--accent)",
  good: "var(--good)", warn: "var(--warn)", bad: "var(--bad)",
};

export default function Page() {
  const [snap, setSnap] = useState<Snapshot | null>(null);
  const [usage, setUsage] = useState<Usage | null>(null);
  const [rateDown, setRateDown] = useState(0);
  const [rateUp, setRateUp] = useState(0);
  const [perCardRate, setPerCardRate] = useState<Record<number, number>>({});
  const prev = useRef<{ t: number; rx: number; tx: number; card: Record<number, number> } | null>(null);

  async function poll() {
    try {
      const [s, u] = await Promise.all([
        fetch("/api/stats").then((r) => r.json()),
        fetch("/api/usage").then((r) => r.json()).catch(() => ({})),
      ]);
      setSnap(s);
      setUsage(u);
      const now = Date.now();
      if (prev.current && !s.error) {
        const dt = (now - prev.current.t) / 1000;
        if (dt > 0) {
          setRateDown(((s.total_rx - prev.current.rx) * 8) / dt);
          setRateUp(((s.total_tx - prev.current.tx) * 8) / dt);
          const pcr: Record<number, number> = {};
          for (const c of s.cards || []) {
            const p = prev.current.card[c.id] ?? c.rx_bytes;
            pcr[c.id] = Math.max(0, ((c.rx_bytes - p) * 8) / dt);
          }
          setPerCardRate(pcr);
        }
      }
      const cardMap: Record<number, number> = {};
      for (const c of s.cards || []) cardMap[c.id] = c.rx_bytes;
      prev.current = { t: now, rx: s.total_rx, tx: s.total_tx, card: cardMap };
    } catch {
      /* نتجاهل خطأ استطلاع عابر */
    }
  }

  useEffect(() => {
    poll();
    const h = setInterval(poll, 2000);
    return () => clearInterval(h);
  }, []);

  const totalWeight = (snap?.cards || []).reduce((a, c) => a + (c.up ? c.weight : 0), 0) || 1;

  return (
    <main style={{ maxWidth: 1100, margin: "0 auto", padding: 20 }}>
      <Header snap={snap} rateDown={rateDown} rateUp={rateUp} />
      {snap?.error && <ErrorBox msg={snap.error} />}
      <QuotaMeter usage={usage} />
      <AddCard onDone={poll} />
      <CardTable
        cards={snap?.cards || []}
        totalWeight={totalWeight}
        perCardRate={perCardRate}
        onRemove={async (id) => {
          if (!confirm(`إزالة الكرت #${id}؟`)) return;
          await fetch(`/api/cards/${id}`, { method: "DELETE" });
          poll();
        }}
      />
      <p style={{ color: C.muted, fontSize: 12, marginTop: 24, textAlign: "center" }}>
        LinkFuse — تحديث كل ثانيتين · الكروت تُدار أثناء التشغيل
      </p>
    </main>
  );
}

function Header({ snap, rateDown, rateUp }: { snap: Snapshot | null; rateDown: number; rateUp: number }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <h1 style={{ fontSize: 22, margin: "4px 0 16px", fontWeight: 700 }}>
        لوحة دمج الكروت
      </h1>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(160px,1fr))", gap: 12 }}>
        <Stat label="التحميل الآن (مدموج)" value={fmtRate(rateDown)} color={C.good} big />
        <Stat label="الرفع الآن" value={fmtRate(rateUp)} color={C.accent} />
        <Stat label="كروت تعمل" value={`${snap?.active_up ?? 0} / ${snap?.card_count ?? 0}`} />
        <Stat label="السعة الاسمية المدموجة" value={`${(((snap?.bonded_kbps ?? 0) / 1000)).toFixed(0)} Mbps`} />
      </div>
    </div>
  );
}

function Stat({ label, value, color, big }: { label: string; value: string; color?: string; big?: boolean }) {
  return (
    <div style={{ background: C.panel, border: `1px solid ${C.line}`, borderRadius: 12, padding: "12px 14px" }}>
      <div style={{ color: C.muted, fontSize: 12, marginBottom: 6 }}>{label}</div>
      <div style={{ fontSize: big ? 26 : 20, fontWeight: 700, color: color || C.text }}>{value}</div>
    </div>
  );
}

function ErrorBox({ msg }: { msg: string }) {
  return (
    <div style={{ background: "#3a1420", border: `1px solid ${C.bad}`, color: "#ffd9de", borderRadius: 10, padding: 12, marginBottom: 14 }}>
      ⚠️ {msg}
    </div>
  );
}

function QuotaMeter({ usage }: { usage: Usage | null }) {
  if (!usage || usage.error) {
    return (
      <div style={{ background: C.panel, border: `1px solid ${C.line}`, borderRadius: 12, padding: 14, marginBottom: 16 }}>
        <div style={{ color: C.muted, fontSize: 13 }}>استهلاك الـ VPS: {usage?.error || "غير متاح"}</div>
      </div>
    );
  }
  const used = usage.total_bytes || 0;
  const quotaBytes = (usage.quota_gb || 0) * 1024 ** 3;
  const pct = quotaBytes > 0 ? Math.min(100, (used / quotaBytes) * 100) : 0;
  const color = pct > 90 ? C.bad : pct > 75 ? C.warn : C.good;
  return (
    <div style={{ background: C.panel, border: `1px solid ${C.line}`, borderRadius: 12, padding: 14, marginBottom: 16 }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8, fontSize: 13 }}>
        <span>حصة بيانات الـ VPS</span>
        <span style={{ color: C.muted }}>
          {fmtBytes(used)} {usage.quota_gb ? `من ${usage.quota_gb} GB` : ""} · تشغيل {fmtUptime(usage.uptime_sec || 0)}
        </span>
      </div>
      {usage.quota_gb ? (
        <>
          <div style={{ height: 10, background: C.panel2, borderRadius: 6, overflow: "hidden" }}>
            <div style={{ width: `${pct}%`, height: "100%", background: color, transition: "width .4s" }} />
          </div>
          {pct > 90 && <div style={{ color: C.bad, fontSize: 12, marginTop: 6 }}>⚠️ اقتربت من الحصّة — الحركة تمرّ عبر الـ VPS مرّتين</div>}
        </>
      ) : (
        <div style={{ color: C.muted, fontSize: 12 }}>حدّد QUOTA_GB في الإعداد لتفعيل التنبيه</div>
      )}
    </div>
  );
}

function CardTable({
  cards, totalWeight, perCardRate, onRemove,
}: {
  cards: Card[]; totalWeight: number; perCardRate: Record<number, number>; onRemove: (id: number) => void;
}) {
  if (cards.length === 0) {
    return <div style={{ color: C.muted, padding: 20, textAlign: "center" }}>لا كروت بعد — أضف كرتاً من الأعلى.</div>;
  }
  const sorted = [...cards].sort((a, b) => a.id - b.id);
  return (
    <div style={{ background: C.panel, border: `1px solid ${C.line}`, borderRadius: 12, overflow: "hidden" }}>
      <div style={{ display: "grid", gridTemplateColumns: "48px 1fr 90px 70px 90px 100px 70px 70px", gap: 8, padding: "10px 12px", color: C.muted, fontSize: 12, borderBottom: `1px solid ${C.line}` }}>
        <div>#</div><div>الجهاز</div><div>السرعة الآن</div><div>التأخير</div><div>الموثوقية</div><div>الحصة</div><div>الحالة</div><div></div>
      </div>
      {sorted.map((c) => {
        const share = c.up ? ((c.weight / totalWeight) * 100) : 0;
        return (
          <div key={c.id} style={{ display: "grid", gridTemplateColumns: "48px 1fr 90px 70px 90px 100px 70px 70px", gap: 8, padding: "10px 12px", alignItems: "center", borderBottom: `1px solid ${C.line}`, fontSize: 13, opacity: c.up ? 1 : 0.5 }}>
            <div style={{ color: C.muted }}>{c.id}</div>
            <div>
              <div>{c.device || c.username || `كرت ${c.id}`}</div>
              <div style={{ color: C.muted, fontSize: 11, fontFamily: "monospace" }}>{c.mac}</div>
            </div>
            <div style={{ color: C.good }}>{fmtRate(perCardRate[c.id] || 0)}</div>
            <div>{fmtMs(c.srtt_ms)}</div>
            <div><Bar pct={c.reliability * 100} color={c.reliability > 0.8 ? C.good : c.reliability > 0.5 ? C.warn : C.bad} /></div>
            <div><Bar pct={share} color={C.accent} label={`${share.toFixed(0)}%`} /></div>
            <div style={{ color: c.up ? C.good : C.bad }}>{c.up ? "● يعمل" : "○ ساقط"}</div>
            <div><button onClick={() => onRemove(c.id)} style={btnDanger}>إزالة</button></div>
          </div>
        );
      })}
    </div>
  );
}

function Bar({ pct, color, label }: { pct: number; color: string; label?: string }) {
  return (
    <div style={{ position: "relative", height: 16, background: C.panel2, borderRadius: 4, overflow: "hidden" }}>
      <div style={{ width: `${Math.min(100, pct)}%`, height: "100%", background: color, transition: "width .4s" }} />
      <span style={{ position: "absolute", inset: 0, textAlign: "center", fontSize: 10, lineHeight: "16px", color: C.text }}>
        {label ?? `${pct.toFixed(0)}%`}
      </span>
    </div>
  );
}

function AddCard({ onDone }: { onDone: () => void }) {
  const [open, setOpen] = useState(false);
  const [id, setId] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [kbps, setKbps] = useState("2000");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  async function submit() {
    setErr("");
    setBusy(true);
    try {
      const r = await fetch("/api/cards", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: Number(id), username, password, base_kbps: Number(kbps) }),
      });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || "فشل");
      setOpen(false);
      setId(""); setUsername(""); setPassword("");
      onDone();
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  }

  if (!open) {
    return (
      <button onClick={() => setOpen(true)} style={{ ...btnPrimary, marginBottom: 16 }}>
        + إضافة كرت أثناء التشغيل
      </button>
    );
  }
  return (
    <div style={{ background: C.panel, border: `1px solid ${C.line}`, borderRadius: 12, padding: 14, marginBottom: 16 }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(130px,1fr))", gap: 10 }}>
        <Field label="رقم الكرت" value={id} onChange={setId} type="number" />
        <Field label="اسم المستخدم" value={username} onChange={setUsername} />
        <Field label="كلمة المرور" value={password} onChange={setPassword} />
        <Field label="السعة Kbps" value={kbps} onChange={setKbps} type="number" />
      </div>
      {err && <div style={{ color: C.bad, fontSize: 12, marginTop: 8 }}>{err}</div>}
      <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
        <button onClick={submit} disabled={busy} style={btnPrimary}>{busy ? "جارٍ التهيئة…" : "إضافة"}</button>
        <button onClick={() => setOpen(false)} style={btnGhost}>إلغاء</button>
      </div>
    </div>
  );
}

function Field({ label, value, onChange, type = "text" }: { label: string; value: string; onChange: (v: string) => void; type?: string }) {
  return (
    <label style={{ display: "block", fontSize: 12, color: C.muted }}>
      {label}
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        style={{ width: "100%", marginTop: 4, padding: "8px 10px", background: C.bg, border: `1px solid ${C.line}`, borderRadius: 8, color: C.text, fontSize: 14 }}
      />
    </label>
  );
}

const btnPrimary: React.CSSProperties = { background: C.accent, color: "#04122a", border: "none", borderRadius: 8, padding: "9px 16px", fontWeight: 700, cursor: "pointer", fontSize: 14 };
const btnGhost: React.CSSProperties = { background: "transparent", color: C.muted, border: `1px solid ${C.line}`, borderRadius: 8, padding: "9px 16px", cursor: "pointer", fontSize: 14 };
const btnDanger: React.CSSProperties = { background: "transparent", color: C.bad, border: `1px solid ${C.bad}`, borderRadius: 6, padding: "4px 10px", cursor: "pointer", fontSize: 12 };
