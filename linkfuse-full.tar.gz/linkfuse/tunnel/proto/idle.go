package proto

import (
	"math/rand"
	"time"
)

// Light-load random spreading.
//
// Normally every packet is spread over ALL paths in proportion to their
// weight, so at light load every card carries the same thin trickle. With
// idle spreading on, while the demand is low only a RANDOM subset of paths
// carries data, sized to at least 4x the current demand (so those paths stay
// below a quarter of their capacity: no queue, no extra latency). Members of the
// subset are swapped one at a time every 20-60 s, so over time every card is
// used, but unevenly and at random moments - like real users.
//
// Quality guards:
//   - a burst grows the subset at once: as soon as the packets sent in the
//     current 200 ms window exceed 25% of what the subset can carry (plus ~2
//     packets), every path is switched on immediately. With the subset never
//     below 12 Mbps, the worst extra delay is ~2 ms, once, at a burst's start;
//   - from 50% of the total capacity upwards all paths are used (normal mode);
//   - the subset shrinks only after 10 s of low demand, one path at a time;
//   - keepalives still go over every path, so health is still measured.

const (
	idleWindow     = 200 * time.Millisecond
	idleHeadroom   = 4.0   // subset capacity >= 4 x demand
	idleAllAt      = 0.5   // demand >= 50% of total -> all paths
	idleMinKbps    = 12000 // subset never below 12 Mbps (6 cards, or a line + 2 cards)
	idleBurstKbit  = 24    // burst allowance: ~2 packets
	idleShrinkWait = 10 * time.Second
	idleBurstShare = 0.25 // all paths on when the subset is 25% busy
	pktKbit        = 12.0 // a packet counted as 1500 bytes (conservative)
)

type idleSpread struct {
	on         bool
	rng        *rand.Rand
	winStart   time.Time
	winPicks   int
	demandKbps float64 // EWMA of the measured demand
	all        bool    // every path in use (high demand or burst)
	lastGrow   time.Time
	nextRotate time.Time
	activeKbps float64
}

// SetIdleSpread switches light-load random spreading on or off.
func (s *Scheduler) SetIdleSpread(on bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.idle.on == on {
		return
	}
	s.idle = idleSpread{on: on, rng: rand.New(rand.NewSource(time.Now().UnixNano())), all: true}
	for _, it := range s.items {
		it.active = true
	}
}

// IdleSpread reports whether it is on.
func (s *Scheduler) IdleSpread() bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.idle.on
}

// idleTick runs inside Pick (lock held). It returns true when Pick must use
// only the active subset, false when every path is in use.
func (s *Scheduler) idleTick() bool {
	d := &s.idle
	now := time.Now()
	d.winPicks++
	if d.winStart.IsZero() {
		d.winStart = now
	}
	el := now.Sub(d.winStart)
	// burst guard: more traffic than half of the subset can carry -> all on
	if !d.all && float64(d.winPicks)*pktKbit > d.activeKbps*el.Seconds()*idleBurstShare+idleBurstKbit {
		d.all, d.lastGrow = true, now
		s.setAllActive()
	}
	if el < idleWindow {
		return !d.all
	}
	demand := float64(d.winPicks) * pktKbit / el.Seconds()
	if demand > d.demandKbps {
		d.demandKbps = demand // rises at once
	} else {
		d.demandKbps += (demand - d.demandKbps) / 10 // falls slowly
	}
	d.winStart, d.winPicks = now, 0
	s.resizeSubset(now)
	return !d.all
}

func (s *Scheduler) setAllActive() {
	for _, it := range s.items {
		it.active = true
	}
}

// resizeSubset keeps the subset at >= 3x demand; lock held.
func (s *Scheduler) resizeSubset(now time.Time) {
	d := &s.idle
	total := 0.0
	var up []*schedItem
	for _, it := range s.items {
		if it.up && it.weight > 0 {
			total += float64(it.weight)
			up = append(up, it)
		}
	}
	need := d.demandKbps * idleHeadroom
	if need < idleMinKbps {
		need = idleMinKbps
	}
	if total == 0 || d.demandKbps >= total*idleAllAt || need >= total {
		if !d.all {
			d.all, d.lastGrow = true, now
		}
		s.setAllActive()
		d.activeKbps = total
		return
	}
	if d.all {
		// leaving full mode: only after the demand stayed low for a while
		if now.Sub(d.lastGrow) < idleShrinkWait {
			return
		}
		d.all = false
		for _, it := range up {
			it.active = false
		}
		d.activeKbps = 0
	}
	act, inact := []*schedItem{}, []*schedItem{}
	cap := 0.0
	for _, it := range up {
		if it.active {
			act = append(act, it)
			cap += float64(it.weight)
		} else {
			inact = append(inact, it)
		}
	}
	// grow at once
	for cap < need && len(inact) > 0 {
		i := d.rng.Intn(len(inact))
		it := inact[i]
		inact = append(inact[:i], inact[i+1:]...)
		it.active, it.cur = true, 0
		act = append(act, it)
		cap += float64(it.weight)
		d.lastGrow = now
	}
	// shrink slowly, one path at a time, never below the need
	if cap > need*2 && len(act) > 1 && now.Sub(d.lastGrow) > idleShrinkWait {
		i := d.rng.Intn(len(act))
		if cap-float64(act[i].weight) >= need {
			act[i].active = false
			cap -= float64(act[i].weight)
			inact = append(inact, act[i])
			act = append(act[:i], act[i+1:]...)
			d.lastGrow = now // next shrink 10 s later
		}
	}
	// rotate: swap one working path for a resting one every 20-60 s
	if now.After(d.nextRotate) && len(act) > 0 && len(inact) > 0 {
		i, j := d.rng.Intn(len(act)), d.rng.Intn(len(inact))
		if cap-float64(act[i].weight)+float64(inact[j].weight) >= need {
			act[i].active = false
			inact[j].active, inact[j].cur = true, 0
			cap += float64(inact[j].weight) - float64(act[i].weight)
		}
		d.nextRotate = now.Add(time.Duration(20+d.rng.Intn(41)) * time.Second)
	}
	d.activeKbps = cap
}
