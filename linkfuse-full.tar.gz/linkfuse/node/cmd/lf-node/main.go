// lf-node: منسّق العقدة المحلية (بصلاحية root).
//
// التشغيل:  lf-node -config /etc/linkfuse/node.json
//
// يهيّئ كروت الإعداد (namespace + هوية وهمية + DHCP + دخول هوتسبوت)، يشغّل عميل
// النفق، ثم يفتح واجهة HTTP للّوحة (إحصاءات حية + إضافة/إزالة كرت أثناء التشغيل).
package main

import (
	"flag"
	"log"
	"os/exec"
	"strconv"
	"time"

	"github.com/linkfuse/node/api"
	"github.com/linkfuse/node/manager"
	"github.com/linkfuse/tunnel/client"
)

func main() {
	cfgPath := flag.String("config", "/etc/linkfuse/node.json", "path to JSON config file")
	flag.Parse()

	cfg, err := manager.Load(*cfgPath)
	if err != nil {
		log.Fatalf("[node] config: %v", err)
	}

	// إعدادات النواة في المجال الرئيسي (كما يفعل Octopus) — ضرورية لعبور الإنترنت.
	// Bring the provider line up (it is down after a VM reboot -> DHCP would hang).
	run("ip", "link", "set", cfg.ParentIface, "up")
	run("sysctl", "-w", "net.ipv4.ip_forward=1")
	run("sysctl", "-w", "net.ipv4.conf.all.rp_filter=0")
	run("sysctl", "-w", "net.ipv4.conf.default.rp_filter=0")
	run("sysctl", "-w", "net.ipv4.conf."+cfg.ParentIface+".rp_filter=0")
	run("sysctl", "-w", "net.ipv4.conf.all.src_valid_mark=1")

	mgr := manager.New(cfg, *cfgPath)
	log.Printf("[node] bringing up %d cards...", len(cfg.Cards))
	pcs := mgr.BringUpInitial(8)
	if len(pcs) == 0 {
		log.Fatal("[node] no card succeeded - check cards, config and login page")
	}
	log.Printf("[node] %d/%d cards ready", len(pcs), len(cfg.Cards))

	cl, err := client.New(client.Config{
		TunName:      cfg.TunName,
		PSK:          cfg.PSK,
		ReorderHold:  time.Duration(cfg.ReorderHold) * time.Millisecond,
		ReorderCap:   cfg.ReorderCap,
		KeepaliveInt: time.Duration(cfg.KeepaliveInt) * time.Millisecond,
		PathTimeout:  time.Duration(cfg.PathTimeout) * time.Millisecond,
	}, pcs)
	if err != nil {
		log.Fatalf("[node] tunnel client: %v", err)
	}
	mgr.AttachClient(cl)
	setupTun(cfg.TunName, cfg.TunAddr, cfg.MTU)
	setupLAN(cfg.LANIface, cfg.LANSubnet, cfg.TunName)

	go cl.Run()                    // tunnel in the background
	go mgr.Watch(30 * time.Second) // re-login dropped cards, retry failed ones
	log.Println("[node] tunnel running")

	// واجهة اللوحة (تحجز الـ main).
	if err := api.New(mgr, cfg.APIToken).Run(cfg.APIListen); err != nil {
		log.Fatalf("[node] API: %v", err)
	}
}

func setupTun(name, addr string, mtu int) {
	run("ip", "addr", "add", addr, "dev", name)
	run("ip", "link", "set", "dev", name, "mtu", strconv.Itoa(mtu))
	run("ip", "link", "set", "dev", name, "up")
}

// setupLAN sends all traffic coming from the users' network through the tunnel,
// while the box itself keeps its normal internet (management) route.
// Uses a separate routing table (100) selected by source subnet.
func setupLAN(lanIf, subnet, tun string) {
	if lanIf == "" || subnet == "" {
		log.Println("[node] lan_iface/lan_subnet not set - LAN routing skipped")
		return
	}
	run("ip", "link", "set", lanIf, "up")
	runQuiet("ip", "rule", "del", "from", subnet, "table", "100")
	runQuiet("ip", "rule", "del", "to", subnet, "table", "main")
	// LAN-to-LAN and replies to LAN clients stay local (priority 99 wins over 100).
	run("ip", "rule", "add", "to", subnet, "table", "main", "priority", "99")
	run("ip", "rule", "add", "from", subnet, "table", "100", "priority", "100")
	run("ip", "route", "replace", "default", "dev", tun, "table", "100")
	ensure("-t", "nat", "POSTROUTING", "-s", subnet, "-o", tun, "-j", "MASQUERADE")
	ensure("FORWARD", "-i", lanIf, "-o", tun, "-j", "ACCEPT")
	ensure("FORWARD", "-i", tun, "-o", lanIf, "-m", "conntrack", "--ctstate", "RELATED,ESTABLISHED", "-j", "ACCEPT")
	ensure("-t", "mangle", "FORWARD", "-o", tun, "-p", "tcp", "--tcp-flags", "SYN,RST", "SYN", "-j", "TCPMSS", "--clamp-mss-to-pmtu")
	log.Printf("[node] LAN %s (%s) routed through %s", lanIf, subnet, tun)
}

// ensure adds an iptables rule only if it is not already present.
// args: [-t table] CHAIN rule...
func ensure(args ...string) {
	var table []string
	if args[0] == "-t" {
		table, args = args[:2], args[2:]
	}
	chain, rule := args[0], args[1:]
	check := append(append(append([]string{}, table...), "-C", chain), rule...)
	if exec.Command("iptables", check...).Run() == nil {
		return
	}
	run(append(append(append([]string{"iptables"}, table...), "-A", chain), rule...)...)
}

func runQuiet(args ...string) { _ = exec.Command(args[0], args[1:]...).Run() }

func run(args ...string) {
	if out, err := exec.Command(args[0], args[1:]...).CombinedOutput(); err != nil {
		log.Printf("[setup] %v: %v (%s)", args, err, string(out))
	}
}
