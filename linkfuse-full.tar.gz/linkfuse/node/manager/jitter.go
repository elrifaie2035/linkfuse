package manager

import (
	"log"
	"math/rand"
	"time"
)

// Usage jitter: each card / broadband line is used at its own, slowly
// changing share of its capacity (e.g. between 70% and 100%), so at the
// provider the cards do not all show the same, identical traffic.
//
// The shares are normalised so their sum stays the real total: the shapers
// keep limiting the bond at 92% of the real capacity, and under full load
// each path carries about its own random share (e.g. 84%..100%) instead of
// all paths carrying the same 92%. No path is pushed above 100%, so latency
// stays low. With min_percent >= 84 nothing is lost; a wider range (e.g. 70)
// makes some paths hit the 100% ceiling and costs a few percent of total.

type JitterCfg struct {
	MinPercent int `json:"min_percent"` // lowest share of a path's capacity, e.g. 70
	MaxPercent int `json:"max_percent"` // highest, normally 100
	MinSec     int `json:"min_sec"`     // a new random target every MinSec..MaxSec
	MaxSec     int `json:"max_sec"`
	// IdleRandom: at light load only a random, rotating subset of the paths
	// carries data (both directions; the server follows the node).
	IdleRandom bool `json:"idle_random"`
}

type jitterState struct {
	cur, target float64
	next        time.Time
}

// UsageJitterLoop runs forever; it does nothing while jitter is off.
func (m *Manager) UsageJitterLoop() {
	rng := rand.New(rand.NewSource(time.Now().UnixNano()))
	st := map[uint16]*jitterState{}
	logged := false
	for {
		time.Sleep(5 * time.Second)
		m.mu.Lock()
		j := m.cfg.UsageJitter
		live := make([]CardCfg, 0, len(m.cards))
		for _, cs := range m.cards {
			live = append(live, cs.cfg)
		}
		m.mu.Unlock()
		if m.cl == nil {
			continue
		}
		idle := j != nil && j.IdleRandom
		if m.cl.IdleSpreadOn() != idle {
			m.cl.SetIdleSpread(idle)
			log.Printf("[jitter] light-load random spreading %v", map[bool]string{true: "on", false: "off"}[idle])
		}
		on := j != nil && j.MinPercent > 0 && j.MinPercent < 100
		if !on {
			if len(st) > 0 { // switched off: back to full capacity
				for _, cc := range live {
					m.cl.SetPathKbps(cc.ID, cc.BaseKbps)
				}
				st = map[uint16]*jitterState{}
				log.Printf("[jitter] off: every path back to its full capacity")
			}
			logged = false
			continue
		}
		lo, hi := clampPct(j.MinPercent), clampPct(j.MaxPercent)
		if hi < lo {
			hi = lo
		}
		minS, maxS := j.MinSec, j.MaxSec
		if minS <= 0 {
			minS = 30
		}
		if maxS < minS {
			maxS = minS * 4
		}
		if !logged {
			log.Printf("[jitter] on: each path uses %d-%d%% of its capacity, new target every %d-%d s", lo, hi, minS, maxS)
			logged = true
		}
		now := time.Now()
		seen := map[uint16]bool{}
		sumCap, sumF := 0.0, 0.0
		for _, cc := range live {
			seen[cc.ID] = true
			s := st[cc.ID]
			if s == nil {
				f := pick(rng, lo, hi)
				s = &jitterState{cur: f, target: f}
				st[cc.ID] = s
			}
			if now.After(s.next) {
				s.target = pick(rng, lo, hi)
				s.next = now.Add(time.Duration(minS+rng.Intn(maxS-minS+1)) * time.Second)
			}
			// glide toward the target (max 4% of capacity per 5 s): no jumps
			d := s.target - s.cur
			if d > 0.04 {
				d = 0.04
			} else if d < -0.04 {
				d = -0.04
			}
			s.cur += d
			sumCap += float64(cc.BaseKbps)
			sumF += float64(cc.BaseKbps) * s.cur
		}
		// Normalise: the shares become uneven but their SUM stays the real
		// total, so the shapers keep the full bond. Under full load a path
		// carries about 92% x share / capacity. The share is capped at
		// capacity x max_percent / 92, so no path ever carries more than
		// max_percent (e.g. 95%) of what it can carry.
		shape := m.cfg.ShapeUpPercent
		if shape <= 0 || shape > 100 {
			shape = 100
		}
		k := 1.0
		if sumF > 0 {
			k = sumCap / sumF
		}
		for _, cc := range live {
			s := st[cc.ID]
			adv := float64(cc.BaseKbps) * s.cur * k
			if ceil := float64(cc.BaseKbps) * float64(hi) / float64(shape); adv > ceil {
				adv = ceil
			}
			kbps := int(adv)
			if kbps < 100 {
				kbps = 100
			}
			m.cl.SetPathKbps(cc.ID, kbps)
		}
		for id := range st {
			if !seen[id] {
				delete(st, id)
			}
		}
	}
}

func pick(rng *rand.Rand, lo, hi int) float64 {
	return float64(lo+rng.Intn(hi-lo+1)) / 100
}

func clampPct(p int) int {
	if p < 30 {
		return 30 // never starve a path: it would look broken
	}
	if p > 100 {
		return 100
	}
	return p
}
