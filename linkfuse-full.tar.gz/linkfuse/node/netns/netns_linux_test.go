//go:build linux

package netns

import (
	"net"
	"os"
	"testing"
)

// يتحقّق أن رقم setns صحيح وأن Do يدخل namespace ويعود منه، بإنشاء سوكيت بداخله.
// نستخدم namespace الحالي (/proc/self/ns/net) كهدف: الدخول إليه صالح وبلا تغيير فعلي،
// فينجح setns (errno 0) ويُثبت صحّة رقم النظام وآلية الحفظ والاستعادة.
func TestSetnsWorks(t *testing.T) {
	if os.Getuid() != 0 {
		t.Skip("يحتاج root")
	}
	cur := "/proc/self/ns/net"

	ran := false
	err := Do(cur, func() error {
		ran = true
		// ننشئ سوكيت UDP بداخله لنتأكّد أن التنفيذ داخل الـ namespace سليم.
		c, e := net.ListenPacket("udp", "127.0.0.1:0")
		if e != nil {
			return e
		}
		return c.Close()
	})
	if err != nil {
		t.Fatalf("Do فشل (رقم setns خاطئ؟): %v", err)
	}
	if !ran {
		t.Fatal("دالة Do لم تُنفَّذ")
	}
}

func TestDoRestoresNamespace(t *testing.T) {
	if os.Getuid() != 0 {
		t.Skip("يحتاج root")
	}
	before, err := os.Readlink("/proc/self/ns/net")
	if err != nil {
		t.Skip("تعذّر قراءة namespace الحالي")
	}
	_ = Do("/proc/self/ns/net", func() error { return nil })
	after, _ := os.Readlink("/proc/self/ns/net")
	if before != after {
		t.Fatalf("لم يُستعَد namespace: قبل=%s بعد=%s", before, after)
	}
}
