package manager

import (
	"math/rand"
	"testing"
)

func TestJitterRange(t *testing.T) {
	rng := rand.New(rand.NewSource(1))
	lo, hi := clampPct(70), clampPct(100)
	seen := map[int]bool{}
	for i := 0; i < 2000; i++ {
		f := pick(rng, lo, hi)
		if f < 0.70 || f > 1.0 {
			t.Fatalf("factor out of range: %v", f)
		}
		seen[int(f*100)] = true
	}
	if len(seen) < 25 {
		t.Fatalf("not random enough: %d distinct values", len(seen))
	}
	if clampPct(10) != 30 || clampPct(150) != 100 {
		t.Fatal("clamp")
	}
}
