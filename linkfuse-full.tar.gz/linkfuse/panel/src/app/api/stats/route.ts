import { nodeFetch } from "@/lib/api";
export const dynamic = "force-dynamic";
export async function GET() {
  try {
    const r = await nodeFetch("/api/stats");
    const body = await r.text();
    return new Response(body, { status: r.status, headers: { "Content-Type": "application/json" } });
  } catch (e: any) {
    return Response.json({ error: `تعذّر الوصول للعقدة: ${e.message}` }, { status: 502 });
  }
}
