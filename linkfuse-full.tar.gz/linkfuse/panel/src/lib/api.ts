// مساعدات جانب الخادم للاتصال بواجهتَي العقدة والـ VPS. الرموز تبقى في الخادم
// (متغيّرات بيئة)، فلا تصل إلى المتصفّح.

export const NODE_API = process.env.NODE_API || "http://127.0.0.1:8088";
export const NODE_TOKEN = process.env.NODE_TOKEN || "";
export const VPS_API = process.env.VPS_API || "";
export const VPS_TOKEN = process.env.VPS_TOKEN || "";
export const QUOTA_GB = Number(process.env.QUOTA_GB || "0");

function authHeaders(token: string): HeadersInit {
  return token ? { Authorization: `Bearer ${token}` } : {};
}

export async function nodeFetch(path: string, init?: RequestInit): Promise<Response> {
  return fetch(`${NODE_API}${path}`, {
    ...init,
    headers: { ...authHeaders(NODE_TOKEN), "Content-Type": "application/json", ...(init?.headers || {}) },
    cache: "no-store",
  });
}

export async function vpsFetch(path: string, init?: RequestInit): Promise<Response> {
  if (!VPS_API) throw new Error("VPS_API غير مُعدّ");
  return fetch(`${VPS_API}${path}`, {
    ...init,
    headers: { ...authHeaders(VPS_TOKEN), ...(init?.headers || {}) },
    cache: "no-store",
  });
}
